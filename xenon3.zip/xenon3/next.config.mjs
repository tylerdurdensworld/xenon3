/** @type {import('next').NextConfig} */
const nextConfig = {
  // Fully client-rendered game: static export so the arena can be hosted anywhere.
  output: 'export',
  reactStrictMode: true,
  trailingSlash: true,
  // Relative asset URLs: the export must work from any base path
  // (user.github.io/<repo>/, a bare domain, or a local subfolder alike).
  assetPrefix: './',
  webpack: (config) => {
    // Load .glsl / .vert / .frag shader sources as plain strings (webpack 5 built-in).
    config.module.rules.push({ test: /\.(glsl|vert|frag)$/, type: 'asset/source' });
    return config;
  },
};

export default nextConfig;
