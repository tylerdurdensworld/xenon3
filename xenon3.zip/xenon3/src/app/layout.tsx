import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'XENON3 — WebQuid Utility Arena',
  description:
    'Holographic neon 3D Tic-Tac-Toe over trustless WebRTC. Spend WebQuid-mined WQD on quantum power-ups. Every move cryptographically signed.',
  // PWA installability: own Xenon3 branding, distinct from the WebQuid miner.
  manifest: 'manifest.webmanifest',
  applicationName: 'Xenon3',
  appleWebApp: {
    capable: true,
    title: 'Xenon3',
    // Blends the iOS status bar into the void background.
    statusBarStyle: 'black-translucent',
  },
  icons: {
    icon: [
      { url: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
      { url: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
    ],
    apple: [{ url: 'icons/apple-touch-icon.png', sizes: '180x180', type: 'image/png' }],
  },
};

export const viewport: Viewport = {
  themeColor: '#05060f',
  width: 'device-width',
  initialScale: 1,
  // viewport-fit=cover lets the arena paint under notches; safe-area insets
  // are then applied deliberately in the HUD via env() padding.
  viewportFit: 'cover',
  // Game board: pinch-zoom would fight the R3F canvas gestures.
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: React.ReactNode }): React.JSX.Element {
  return (
    <html lang="en" className="dark">
      <head>
        {/* Display typefaces; system fallbacks keep the UI intact if the CDN is unreachable. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@400;500;600&family=JetBrains+Mono:wght@400;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
