// ─────────────────────────────────────────────────────────────────────────────
// Xenon3 global store — the "WQD Engine".
// One Zustand store owns: wallet session, the signed hash-chained WQD ledger,
// power-up inventory (derived from ledger burns), match state incl. Quantum
// Superposition, the signed-message sequencing layer (anti-cheat), and chat.
// All peer input is validated here before it touches game state.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import { create } from 'zustand';
import type { Hex } from 'viem';
import {
  DILATION_MS,
  EMPTY_CELL,
  POWER_UP_COST,
  QUANTUM_LOCK_COST,
  TIMEOUT_TOLERANCE_MS,
  TURN_SECONDS,
  canAfford,
  emptyBoard,
  opponentOf,
  type CellState,
  type ChatMessage,
  type FxImpulse,
  type FxKind,
  type Mark,
  type MatchPhase,
  type PlayerInfo,
  type PowerUpKind,
  type WinResult,
} from '../types';
import {
  commitSecret,
  hashPayload,
  randomBytes32,
  recoverPayloadSigner,
  signPayload,
} from '../lib/crypto';
import {
  LEDGER_GENESIS,
  buildBurnEvent,
  buildCreditEvent,
  emptyInventory,
  validateLedger,
  type Inventory,
  type LedgerEvent,
} from '../lib/ledger';
import {
  persistCredits,
  readPlatformCredits,
  loadStoredCredits,
  verifyCredit,
} from '../lib/webquid';
import { buildBalanceEvent, rebaseLedger } from '../lib/ledger';
import { WqdWatcher, type WatcherPhase, type WatcherSnapshot } from '../lib/wqdWatcher';
import { WQD_BASE, signBalanceProof } from '../lib/wqdchain';
import {
  PROTOCOL_VERSION,
  QUICKMATCH_CODE,
  handshakeMatchId,
  sanitizeChat,
  type BuyPayload,
  type ChatPayload,
  type EntanglePayload,
  type Envelope,
  type HelloPayload,
  type MsgType,
  type ObservePayload,
  type PowerUpPayload,
  type RevealPayload,
  type StateSyncPayload,
  type TimeoutPayload,
  type PingPayload,
  type CheatFlagPayload,
  type DepositPayload,
  type BalancePayload,
  type MovePayload,
  envelopeBody,
} from '../lib/protocol';
import {
  applyQuantumHack,
  collapseQuantum,
  evaluateWinner,
  isCellPlayable,
  isOwnQuantum,
  isOwnUnshieldedMark,
  isPeerQuantum,
  lockQuantum,
  quantumHackTarget,
} from '../lib/game';
import {
  connectInjected,
  connectWebquid,
  importWebquidWallet,
  type GameSigner,
  type WebquidIdentitySource,
} from '../lib/wallet';
import { TokenBucket } from '../lib/rateLimit';

export type NetStatus = 'offline' | 'hosting' | 'joining' | 'connected';
export type Role = 'host' | 'guest';
/** 'holding' = we own the queue node waiting for a rival; 'dialing' = knocking on it. */
export type QueueStatus = 'idle' | 'holding' | 'dialing';
export type MatchmakingMode = 'private' | 'quick';

/** Unsigned control frame — informational only, never gates game state. */
export interface NetControlFrame {
  queueBusy?: boolean;
  /** Host refused the handshake because both sides present the SAME wallet. */
  sameWallet?: boolean;
}

export interface NetApi {
  hostRoom: (code: string) => void;
  joinRoom: (code: string) => void;
  quickMatch: () => void;
  leave: () => void;
  sendRaw: (env: Envelope) => void;
  /** Optional: send an unsigned advisory control frame (never trusted). */
  sendControl?: (frame: NetControlFrame) => void;
}

interface CheatState {
  flagged: boolean;
  reason: string | null;
  /** 'peer' = the remote player cheated; 'self' = the peer accused us. */
  by: 'peer' | 'self' | null;
}

// Outbound chat: 5 messages burst, 1 per second sustained.
const chatOutBucket = new TokenBucket(5, 1);
// Inbound chat flood defense: 8 burst, 1.5 per second.
const chatInBucket = new TokenBucket(8, 1.5);
// Inbound global flood defense: 60 envelopes per 10 seconds.
const globalInBucket = new TokenBucket(60, 6);

// Read-only WebQuid mainnet full-node watcher — one per wallet identity.
let watcher: WqdWatcher | null = null;
let watcherFor = '';
// Phantom-claim scan runs once per distinct ledger state (memoized audits make
// repeats cheap): stamps the ledger so we don't rescan after every block.
let phantomCheckedFor: string | null = null;

// Mirror throttling: onStatus fires per block; batch mirror credits.
let mirrorInFlight = false;
let lastMirrorAt = 0;
const MIRROR_THROTTLE_MS = 30_000;

// Serialize ALL local ledger mutations (mirror credits, deposit credits): two
// watcher callbacks in the same tick must never overwrite each other's append.
let ledgerQueue: Promise<unknown> = Promise.resolve();
const enqueueLedgerOp = <T>(op: () => Promise<T>): Promise<T> => {
  const run = ledgerQueue.then(op, op);
  ledgerQueue = run.catch(() => undefined);
  return run;
};

const ledgerKey = (address: string) => `xenon3:ledger:${address.toLowerCase()}`;

function loadLedger(address: string): LedgerEvent[] {
  try {
    const raw = window.localStorage.getItem(ledgerKey(address));
    return raw ? (JSON.parse(raw) as LedgerEvent[]) : [];
  } catch {
    return [];
  }
}

function persistLedger(address: string, events: LedgerEvent[]): void {
  try {
    window.localStorage.setItem(ledgerKey(address), JSON.stringify(events));
  } catch {
    // Storage full/unavailable — the session ledger still lives in memory.
  }
}

/** Snapshot both peers agree on; used by PING desync detection. */
export const computeStateHash = (board: CellState[], turn: Mark, winner: WinResult | null): Hex =>
  hashPayload({ board, turn, winner });

export interface GameStore {
  // ── Wallet ──────────────────────────────────────────────────────────────
  signer: GameSigner | null;
  walletStatus: 'idle' | 'connecting' | 'connected' | 'error';
  walletError: string | null;
  address: string | null;
  /** Where the WebQuid identity came from (null for injected wallets). */
  walletSource: WebquidIdentitySource | null;

  // ── WQD ledger (local player) ───────────────────────────────────────────
  ledger: LedgerEvent[];
  selfBalance: number;
  selfInventory: Inventory;
  lastSyncCount: number;

  // ── On-chain bridge (WebQuid mainnet full-node watcher) ──────────────────
  watcherPeers: number;
  /** Watcher link lifecycle (starting/sweeping/linked/broker-error). */
  watcherPhase: WatcherPhase;
  /** Last fatal signaling-broker error type, null when healthy. */
  watcherError: string | null;
  /** Our claimed PeerJS identity (diagnostics). */
  watcherIdentity: string | null;
  /** Cumulative outbound dial attempts. */
  watcherDialed: number;
  /** Dials that reached an open channel. */
  watcherAnswered: number;
  /** Inbound connections received on our claimed slot. */
  watcherInbound: number;
  /** Last few watcher events for the on-screen diagnostics panel. */
  watcherDiag: string[];
  /** Verified chain height (our own full-node sync tip). */
  networkHeight: number;
  /** Tallest height advertised by peers (sync target). */
  bestKnownHeight: number;
  /** Replayed on-chain balance of the connected wallet (WQD, trustless). */
  chainBalance: number;

  // ── WQD ledger (remote player, replicated + validated) ──────────────────
  remoteLedger: LedgerEvent[];
  remoteBalance: number;
  remoteInventory: Inventory;

  // Per-match activation counts (signed POWERUP messages), reset each match.
  selfUses: Inventory;
  remoteUses: Inventory;

  // ── Networking ──────────────────────────────────────────────────────────
  netApi: NetApi | null;
  netStatus: NetStatus;
  netError: string | null;
  roomCode: string | null;
  role: Role | null;
  matchId: string | null;
  myNonce: Hex | null;
  /** Quick Match queue state (independent of the in-match protocol). */
  queueStatus: QueueStatus;
  queueMessage: string | null;
  matchmakingMode: MatchmakingMode | null;

  // ── Match ───────────────────────────────────────────────────────────────
  phase: MatchPhase;
  self: PlayerInfo | null;
  peer: PlayerInfo | null;
  board: CellState[];
  turn: Mark;
  winner: WinResult | null;
  placedSeqCounter: number;
  deadlines: Record<Mark, number>;
  dilationUntil: Record<Mark, number>;
  selectedPowerUp: PowerUpKind | null;
  secrets: Record<number, Hex>;
  pendingSalts: Record<number, Hex>;
  rematchRequested: boolean;

  // ── Anti-cheat sequencing ───────────────────────────────────────────────
  outSeq: number;
  inSeq: number;
  outPrev: Hex;
  inPrev: Hex;
  /** Last dispatched envelope — enables byte-identical retransmission on retries. */
  lastSentEnvelope: Envelope | null;
  inboundBuffer: Record<number, Envelope>;
  cheat: CheatState;

  // ── Chat ────────────────────────────────────────────────────────────────
  chat: ChatMessage[];
  chatOpen: boolean;
  unread: number;
  chatLimitedAt: number | null;

  // ── FX / audio bridge ───────────────────────────────────────────────────
  fx: FxImpulse;
  /** Sound on/off — persisted on-device, drives the synth engine's master gain. */
  muted: boolean;
  /** Mobile armory tray — lifted here so the chat tab can clear it. */
  armoryOpen: boolean;

  // ── Actions ─────────────────────────────────────────────────────────────
  connectWallet: (mode: 'webquid' | 'injected') => Promise<void>;
  /** Paste-in import of the player's real WebQuid wallet key. */
  importWalletKey: (rawKey: string) => Promise<boolean>;
  syncWebquid: () => Promise<void>;
  /** Mirror newly observed on-chain balance as in-game credit (coins never move). */
  mirrorBalance: () => Promise<boolean>;
  setNetApi: (api: NetApi | null) => void;
  setNetStatus: (status: NetStatus, error?: string | null) => void;
  setQueueStatus: (status: QueueStatus, message?: string | null) => void;
  /** Busy-signal recovery: unwind a half-started handshake, KEEP queue state. */
  resetQueueForRetry: () => void;
  beginHandshake: (code: string, role: Role) => void;
  dispatch: (type: MsgType, payload: unknown) => Promise<Envelope | null>;
  applyRemote: (env: Envelope) => Promise<void>;
  buyPowerUp: (kind: PowerUpKind) => Promise<boolean>;
  selectPowerUp: (kind: PowerUpKind | null) => void;
  handleCellClick: (index: number) => Promise<void>;
  activateHack: () => Promise<void>;
  activateDilation: () => Promise<void>;
  lockQuantumCell: (index: number) => Promise<void>;
  tick: () => void;
  sendChat: (text: string) => Promise<boolean>;
  setChatOpen: (open: boolean) => void;
  requestRematch: () => Promise<void>;
  leaveMatch: () => Promise<void>;
  flagCheat: (reason: string, by: 'peer' | 'self') => void;
  emitFx: (kind: FxKind, cell?: number) => void;
  toggleMuted: () => void;
  setArmoryOpen: (open: boolean) => void;
}

export const useGameStore = create<GameStore>()((set, get) => {
  // ── Internal helpers (closures, not part of the public API) ──────────────

  const recomputeSelfView = async (): Promise<void> => {
    const { ledger, address, selfUses } = get();
    if (!address) return;
    const view = await validateLedger(ledger, address, selfUses);
    if (!view.ok) {
      // Local ledger failed self-validation — defensive reset, never play on a corrupt book.
      console.error('[xenon3] local ledger invalid:', view.error);
      set({ ledger: [], selfBalance: 0, selfInventory: emptyInventory() });
      persistLedger(address, []);
      return;
    }
    set({ selfBalance: view.balance, selfInventory: view.inventory });
  };

  const recomputeRemoteView = async (): Promise<boolean> => {
    const { remoteLedger, peer, remoteUses } = get();
    if (!peer) return false;
    const view = await validateLedger(remoteLedger, peer.address, remoteUses);
    if (!view.ok) {
      get().flagCheat(`ledger validation failed: ${view.error}`, 'peer');
      return false;
    }
    set({ remoteBalance: view.balance, remoteInventory: view.inventory });
    return true;
  };

  const persistSelfLedger = (): void => {
    const { address, ledger } = get();
    if (address) persistLedger(address, ledger);
  };

  /**
   * Chain-truth oracle for the peer's mirror credits: once our full node has
   * replayed the claimed height, the claimed balance must not exceed what the
   * chain itself computes. Both sides run this against the same verified
   * chain, so both reach the same verdict.
   */
  const auditRemoteBalanceClaims = (): void => {
    if (!watcher || get().cheat.flagged) return;
    for (const e of get().remoteLedger) {
      if (e.reason !== 'WQD_BALANCE' || !e.balance) continue;
      const computed = watcher.balanceOfAt(e.balance.wqdAddress, e.balance.height);
      if (computed === null) continue; // not synced that far yet — re-checked next tick
      if (e.balance.balance > Math.round(computed * WQD_BASE)) {
        get().flagCheat(
          `balance overclaim: ${e.balance.balance / WQD_BASE} WQD claimed at height ${e.balance.height}, chain proves ${computed}`,
          'peer',
        );
        return;
      }
    }
  };

  // ── On-chain watcher (module singleton, one per wallet) ───────────────────
  const startWatcher = (signer: GameSigner): void => {
    if (!signer.wqdAddress) return; // injected wallets have no wqd1 identity
    if (watcher && watcherFor === signer.wqdAddress) return;
    try { watcher?.stop(); } catch { /* noop */ }
    watcherFor = signer.wqdAddress;
    watcher = new WqdWatcher(signer.wqdAddress, {
      onStatus: (snap: WatcherSnapshot) => {
        set({
          watcherPeers: snap.peers,
          watcherPhase: snap.phase,
          watcherError: snap.lastError,
          watcherIdentity: snap.identity,
          watcherDialed: snap.dialed,
          watcherAnswered: snap.answered,
          watcherInbound: snap.inbound,
          watcherDiag: snap.diag,
          networkHeight: snap.tipHeight,
          bestKnownHeight: snap.bestKnown,
          chainBalance: snap.watchBalance,
        });
        // New verified chain state: mirror any balance growth, and re-audit
        // the peer's claims now that we may have replayed further.
        void get().mirrorBalance();
        auditRemoteBalanceClaims();
      },
    });
    watcher.start();
  };

  /**
   * Self-healing mirror audit: historical builds could sign balance claims that
   * overshoot the replayed chain (their own watcher was mis-replaying). Those
   * claims persist in the local ledger and would make the OPPONENT flag us as a
   * cheater. When any claim provably exceeds the chain at its own height, the
   * whole mirror history is re-anchored to the current replayed truth — one
   * fresh claim, all credits/burns preserved — and the phantom credit vanishes.
   */
  const reconcileMirrorClaims = async (): Promise<void> => {
    const s = get();
    if (!watcher || !s.address || !s.signer?.wqdAddress || !s.signer.wqdKey) return;
    const mirrorEvents = s.ledger.filter((e) => e.reason === 'WQD_BALANCE' && e.balance);
    if (mirrorEvents.length === 0) return;
    const stamp = `${s.ledger.length}:${s.ledger[s.ledger.length - 1]?.hash ?? ''}`;
    if (phantomCheckedFor === stamp) return;
    let phantom = false;
    for (const e of mirrorEvents) {
      const p = e.balance;
      if (!p) continue;
      const truth = watcher.balanceOfAt(p.wqdAddress, p.height);
      if (truth === null) continue; // not replayed that far yet — next tick
      if (p.balance > Math.round(truth * WQD_BASE)) {
        phantom = true;
        break;
      }
    }
    if (!phantom) {
      phantomCheckedFor = stamp;
      return;
    }
    const wqdAddress = s.signer.wqdAddress;
    const height = get().networkHeight;
    const chainBase = Math.round(watcher.balanceOf(wqdAddress) * WQD_BASE);
    if (chainBase <= 0 || height <= 0) return; // no truth yet — retry next tick
    const { pubkey, signature } = signBalanceProof(s.signer.wqdKey, wqdAddress, height, chainBase);
    const anchorClaim = buildBalanceEvent({
      events: [],
      owner: s.address,
      proof: { wqdAddress, height, balance: chainBase, pubkey, signature },
      amount: chainBase / WQD_BASE,
    });
    const next = await rebaseLedger({
      events: s.ledger,
      owner: s.address,
      signer: s.signer,
      anchorClaim,
    });
    const view = await validateLedger(next, s.address, s.selfUses);
    if (!view.ok) {
      console.error('[xenon3] mirror rebase rejected:', view.error);
      phantomCheckedFor = stamp; // don't hot-loop a book we can't repair
      return;
    }
    set({ ledger: next, selfBalance: view.balance, selfInventory: view.inventory });
    persistSelfLedger();
    phantomCheckedFor = null; // re-scan the repaired book once
    console.warn('[xenon3] balance claims disagreed with chain truth — ledger re-anchored to the replayed balance');
  };

  const advanceTurn = (next: Mark): void => {
    // A pending Time Dilation freeze survives the turn transition: the victim's
    // new deadline absorbs whatever freeze time is still outstanding.
    const frozenRemainder = Math.max(0, get().dilationUntil[next] - Date.now());
    set({
      turn: next,
      deadlines: { ...get().deadlines, [next]: Date.now() + TURN_SECONDS * 1000 + frozenRemainder },
    });
  };

  const finishIfWinner = (): boolean => {
    const result = evaluateWinner(get().board);
    if (result) {
      set({ winner: result, phase: 'FINISHED', selectedPowerUp: null });
      // Outcome is subjective: the loser must hear DEFEAT, not the fanfare.
      const me = get().self;
      const outcome: FxKind =
        result.winner === 'DRAW' ? 'stalemate' : me && result.winner === me.mark ? 'win' : 'defeat';
      get().emitFx(outcome, result.line?.[0] ?? -1);
      return true;
    }
    return false;
  };

  const bumpPlacedSeq = (): number => get().placedSeqCounter + 1;

  /** Guard: is the given mark currently frozen by Time Dilation? */
  const isFrozen = (mark: Mark): boolean => get().dilationUntil[mark] > Date.now();

  /** Append a peer-signed burn to the replicated ledger and re-validate everything. */
  const appendRemoteBurn = async (burn: LedgerEvent, expectReason: string): Promise<boolean> => {
    const { remoteLedger } = get();
    if (burn.kind !== 'BURN' || burn.reason !== expectReason) {
      get().flagCheat(`unexpected burn reason '${burn.reason}'`, 'peer');
      return false;
    }
    set({ remoteLedger: [...remoteLedger, burn] });
    return recomputeRemoteView();
  };

  const resetMatchState = (startingTurn: Mark): void => {
    set({
      board: emptyBoard(),
      turn: startingTurn,
      winner: null,
      phase: 'ACTIVE',
      placedSeqCounter: 0,
      deadlines: {
        X: startingTurn === 'X' ? Date.now() + TURN_SECONDS * 1000 : 0,
        O: startingTurn === 'O' ? Date.now() + TURN_SECONDS * 1000 : 0,
      },
      dilationUntil: { X: 0, O: 0 },
      selectedPowerUp: null,
      secrets: {},
      pendingSalts: {},
      rematchRequested: false,
      selfUses: emptyInventory(),
      remoteUses: emptyInventory(),
      chat: [],
      unread: 0,
    });
  };

  const resetToLobby = (): void => {
    set({
      phase: 'IDLE',
      roomCode: null,
      role: null,
      matchId: null,
      myNonce: null,
      self: null,
      peer: null,
      board: emptyBoard(),
      winner: null,
      placedSeqCounter: 0,
      deadlines: { X: 0, O: 0 },
      dilationUntil: { X: 0, O: 0 },
      selectedPowerUp: null,
      secrets: {},
      pendingSalts: {},
      rematchRequested: false,
      selfUses: emptyInventory(),
      remoteUses: emptyInventory(),
      remoteLedger: [],
      remoteBalance: 0,
      remoteInventory: emptyInventory(),
      outSeq: 0,
      inSeq: -1,
      outPrev: LEDGER_GENESIS,
      inPrev: LEDGER_GENESIS,
      inboundBuffer: {},
      chat: [],
      unread: 0,
      cheat: { flagged: false, reason: null, by: null },
      netError: null,
      queueStatus: 'idle',
      queueMessage: null,
      matchmakingMode: null,
    });
  };

  // ── Public actions ─────────────────────────────────────────────────────────

  return {
    signer: null,
    walletStatus: 'idle',
    walletError: null,
    address: null,
    walletSource: null,

    ledger: [],
    selfBalance: 0,
    selfInventory: emptyInventory(),
    lastSyncCount: 0,

    watcherPeers: 0,
    watcherPhase: 'starting',
    watcherError: null,
    watcherIdentity: null,
    watcherDialed: 0,
    watcherAnswered: 0,
    watcherInbound: 0,
    watcherDiag: [],
    networkHeight: 0,
    bestKnownHeight: 0,
    chainBalance: 0,

    remoteLedger: [],
    remoteBalance: 0,
    remoteInventory: emptyInventory(),
    selfUses: emptyInventory(),
    remoteUses: emptyInventory(),

    netApi: null,
    netStatus: 'offline',
    netError: null,
    roomCode: null,
    role: null,
    matchId: null,
    myNonce: null,
    queueStatus: 'idle',
    queueMessage: null,
    matchmakingMode: null,

    phase: 'IDLE',
    self: null,
    peer: null,
    board: emptyBoard(),
    turn: 'X',
    winner: null,
    placedSeqCounter: 0,
    deadlines: { X: 0, O: 0 },
    dilationUntil: { X: 0, O: 0 },
    selectedPowerUp: null,
    secrets: {},
    pendingSalts: {},
    rematchRequested: false,

    outSeq: 0,
    inSeq: -1,
    outPrev: LEDGER_GENESIS,
    inPrev: LEDGER_GENESIS,
    lastSentEnvelope: null,
    inboundBuffer: {},
    cheat: { flagged: false, reason: null, by: null },

    chat: [],
    chatOpen: false,
    unread: 0,
    chatLimitedAt: null,

    fx: { nonce: 0, kind: 'place', cell: -1 },
    muted:
      typeof window !== 'undefined' &&
      (() => {
        try {
          return window.localStorage.getItem('xenon3:muted') === '1';
        } catch {
          return false;
        }
      })(),
    armoryOpen: false,

    // ── Wallet ────────────────────────────────────────────────────────────
    connectWallet: async (mode) => {
      set({ walletStatus: 'connecting', walletError: null });
      try {
        let signer: GameSigner;
        let source: WebquidIdentitySource | null = null;
        if (mode === 'injected') {
          signer = await connectInjected();
        } else {
          const connection = await connectWebquid();
          if (!connection) {
            // No genuine wallet on this device — refuse to fabricate one.
            set({
              walletStatus: 'error',
              walletError:
                'no WebQuid wallet found on this device — export your key from the WebQuid terminal and import it below',
            });
            return;
          }
          signer = connection.signer;
          source = connection.source;
        }
        const ledger = loadLedger(signer.address);
        set({ signer, address: signer.address, ledger, walletStatus: 'connected', walletSource: source });
        await recomputeSelfView();
        startWatcher(signer);
        // Credits from the mining grid import themselves — no manual sync step.
        void get().syncWebquid();
      } catch (error) {
        set({
          walletStatus: 'error',
          walletError: error instanceof Error ? error.message : 'wallet connection failed',
        });
      }
    },

    // Bring your own WebQuid wallet: validate, persist, reconnect as that identity.
    importWalletKey: async (rawKey) => {
      try {
        const { signer, source } = await importWebquidWallet(rawKey);
        const ledger = loadLedger(signer.address);
        set({
          signer,
          address: signer.address,
          ledger,
          walletStatus: 'connected',
          walletError: null,
          walletSource: source,
        });
        await recomputeSelfView();
        startWatcher(signer);
        // Credits from the mining grid import themselves — no manual sync step.
        void get().syncWebquid();
        return true;
      } catch (error) {
        set({ walletError: error instanceof Error ? error.message : 'key import failed' });
        return false;
      }
    },

    // Pull WebQuid platform attestations (same-origin hand-off). NO faucet:
    // real WQD enters only via issuer credits or proven on-chain deposits.
    syncWebquid: async () => {
      const { address, ledger } = get();
      if (!address) return;
      const known = new Set(ledger.map((e) => e.refId));
      const candidates = readPlatformCredits().filter(
        (c) => !known.has(c.credit.nonce) && c.credit.to.toLowerCase() === address,
      );
      let added = 0;
      const accepted = loadStoredCredits();
      let next = ledger;
      for (const credit of candidates) {
        if (!(await verifyCredit(credit))) continue;
        const event = await buildCreditEvent({ events: next, credit });
        if (!event) continue;
        next = [...next, event];
        accepted.push(credit);
        added += 1;
      }
      if (added > 0) {
        set({ ledger: next, lastSyncCount: added });
        persistSelfLedger();
        persistCredits(accepted);
        await recomputeSelfView();
        get().emitFx('dilation', -1);
      } else {
        set({ lastSyncCount: 0 });
      }
    },

    // Mirror the replayed on-chain balance into spendable in-game credit.
    // The coins NEVER leave the wallet: we sign a claim of the balance our
    // full node independently replayed, and credit only the delta over what
    // was mirrored before (each coin can enter the game exactly once).
    // The opponent's own full node re-checks the claim against the chain.
    mirrorBalance: async () => {
      const { signer, address, networkHeight, bestKnownHeight } = get();
      if (!address || !signer?.wqdAddress || !signer.wqdKey || !watcher) return false;
      // The throttle batches mirror credits while blocks stream past during
      // catch-up — but once we're AT the known tip it must never skip: no
      // further status event may arrive to retry, and the final tip state
      // would stay un-mirrored.
      const caughtUp = bestKnownHeight > 0 && networkHeight >= bestKnownHeight;
      if (mirrorInFlight || (!caughtUp && Date.now() - lastMirrorAt < MIRROR_THROTTLE_MS)) return false;
      mirrorInFlight = true;
      try {
        return await enqueueLedgerOp(async () => {
          // Repair historical over-claims before mirroring anything new.
          await reconcileMirrorClaims();
          const s = get();
          if (!s.address || !s.signer?.wqdAddress || !s.signer.wqdKey || !watcher) return false;
          const wqdAddress = s.signer.wqdAddress;
          const chainBase = Math.round(watcher.balanceOf(wqdAddress) * WQD_BASE);
          const height = get().networkHeight;
          if (chainBase <= 0 || height <= 0) return false;
          let mirrored = 0;
          let lastHeight = -1;
          for (const e of s.ledger) {
            if (e.reason === 'WQD_BALANCE' && e.balance) {
              mirrored = e.balance.balance; // invariant: last claim equals running total
              lastHeight = Math.max(lastHeight, e.balance.height);
            }
          }
          const delta = chainBase - mirrored;
          if (delta <= 0 || height <= lastHeight) return false;
          const refId = `bal:${wqdAddress}:${height}`;
          if (s.ledger.some((e) => e.refId === refId)) return false;
          const { pubkey, signature } = signBalanceProof(s.signer.wqdKey, wqdAddress, height, chainBase);
          const proof = { wqdAddress, height, balance: chainBase, pubkey, signature };
          const event = buildBalanceEvent({ events: s.ledger, owner: s.address, proof, amount: delta / WQD_BASE });
          const next = [...s.ledger, event];
          // Validate BEFORE committing — the mirror must pass the same rules
          // the opponent will apply when replaying our ledger.
          const view = await validateLedger(next, s.address, s.selfUses);
          if (!view.ok) {
            console.error('[xenon3] balance mirror rejected:', view.error);
            return false;
          }
          lastMirrorAt = Date.now();
          set({ ledger: next, selfBalance: view.balance, selfInventory: view.inventory });
          persistSelfLedger();
          get().emitFx('dilation', -1);
          if (get().matchId) await get().dispatch('BALANCE', { event } satisfies BalancePayload);
          return true;
        });
      } finally {
        mirrorInFlight = false;
      }
    },

    setNetApi: (api) => set({ netApi: api }),

    setNetStatus: (status, error = null) => {
      set({ netStatus: status, netError: error });
      if (status === 'offline' && get().phase !== 'IDLE') {
        // Transport died mid-match: abort loudly rather than silently desync.
        set({ phase: get().phase === 'ACTIVE' ? 'ABORTED' : get().phase });
      }
    },

    setQueueStatus: (status, message = null) => set({ queueStatus: status, queueMessage: message }),

    resetQueueForRetry: () => {
      const { queueStatus, queueMessage } = get();
      resetToLobby();
      set({ queueStatus, queueMessage, matchmakingMode: 'quick' });
    },

    beginHandshake: (code, role) => {
      resetToLobby();
      set({
        roomCode: code,
        role,
        phase: 'CONNECTING',
        myNonce: randomBytes32(),
        inSeq: -1,
        outSeq: 0,
        inPrev: LEDGER_GENESIS,
        outPrev: LEDGER_GENESIS,
        matchmakingMode: code === QUICKMATCH_CODE ? 'quick' : 'private',
      });
    },

    // ── Signed envelope factory — THE choke point for every outbound message ──
    dispatch: async (type, payload) => {
      const { signer, address, roomCode, matchId, outSeq, outPrev, netApi } = get();
      if (!signer || !address || !netApi) return null;
      const id =
        type === 'HELLO' ? handshakeMatchId(roomCode ?? '') : matchId ?? handshakeMatchId(roomCode ?? '');
      const body = { v: PROTOCOL_VERSION, matchId: id, seq: outSeq, prevHash: outPrev, type, payload };
      const sig = await signPayload(signer, body);
      const env: Envelope = { ...body, from: address, sig };
      // The next envelope must commit to this one's full hash — tamper-evident chain.
      set({ outSeq: outSeq + 1, outPrev: hashPayload(env), lastSentEnvelope: env });
      netApi.sendRaw(env);
      return env;
    },

    // ── Inbound trust gate: ordering → chain → signature → game rules ────────
    applyRemote: async (env) => {
      const st = get();

      if (!globalInBucket.tryConsume()) {
        st.flagCheat('message flood on the data channel', 'peer');
        return;
      }
      if (env.v !== PROTOCOL_VERSION) return;
      if (env.seq <= st.inSeq) return; // duplicate / replay — silently drop
      if (env.seq > st.inSeq + 1) {
        // Out-of-order (PeerJS is ordered, but defend anyway): buffer and drain later.
        set({ inboundBuffer: { ...get().inboundBuffer, [env.seq]: env } });
        return;
      }

      const process = async (current: Envelope): Promise<boolean> => {
        const s = get();
        if (current.prevHash !== s.inPrev) {
          s.flagCheat('broken inbound hash chain', 'peer');
          return false;
        }
        let recovered: string;
        try {
          recovered = await recoverPayloadSigner(envelopeBody(current), current.sig);
        } catch {
          s.flagCheat('malformed signature', 'peer');
          return false;
        }
        const expectedSigner = s.peer?.address ?? null;
        if (recovered !== current.from.toLowerCase()) {
          s.flagCheat('signature does not match claimed sender', 'peer');
          return false;
        }
        if (expectedSigner && recovered !== expectedSigner) {
          s.flagCheat('message signed by a third party', 'peer');
          return false;
        }
        // Chain anchor advances ONLY after full verification.
        set({ inSeq: current.seq, inPrev: hashPayload(current) });
        await handleVerified(current);
        return true;
      };

      if (!(await process(env))) return;
      // Drain any buffered successors in order.
      let nextSeq = get().inSeq + 1;
      while (get().inboundBuffer[nextSeq]) {
        const buffered = get().inboundBuffer[nextSeq];
        const rest = { ...get().inboundBuffer };
        delete rest[nextSeq];
        set({ inboundBuffer: rest });
        if (!(await process(buffered))) return;
        nextSeq = get().inSeq + 1;
      }
    },

    // ── Armory: burn WQD to stock a consumable ──────────────────────────────
    buyPowerUp: async (kind) => {
      const { signer, address, ledger, selfBalance, matchId, phase } = get();
      if (!signer || !address) return false;
      const cost = POWER_UP_COST[kind];
      if (!canAfford(selfBalance, cost)) {
        get().emitFx('error', -1);
        return false;
      }
      const burn = await buildBurnEvent({
        events: ledger,
        owner: address,
        signer,
        amount: cost,
        reason: `PURCHASE:${kind}`,
        matchId: phase === 'ACTIVE' || phase === 'FINISHED' ? matchId : null,
      });
      set({ ledger: [...ledger, burn] });
      persistSelfLedger();
      await recomputeSelfView();
      if (get().phase === 'ACTIVE' || get().phase === 'FINISHED') {
        await get().dispatch('BUY', { burn } satisfies BuyPayload);
      }
      get().emitFx('shield', -1);
      return true;
    },

    selectPowerUp: (kind) => {
      set({ selectedPowerUp: get().selectedPowerUp === kind ? null : kind });
    },

    // ── Board input router ────────────────────────────────────────────────────
    handleCellClick: async (index) => {
      const s = get();
      if (s.phase !== 'ACTIVE' || !s.self || !s.peer || s.winner) return;
      const me = s.self.mark;
      const cell = s.board[index];

      if (s.selectedPowerUp === 'NEON_SHIELD') {
        if (isOwnUnshieldedMark(s.board, index, me)) await activateShield(index);
        set({ selectedPowerUp: null });
        return;
      }
      if (s.selectedPowerUp === 'QUANTUM_ENTANGLE') {
        if (s.turn === me && !isFrozen(me) && cell.kind === 'empty') await placeEntangle(index);
        set({ selectedPowerUp: null });
        return;
      }
      if (s.selectedPowerUp) {
        // Non-targeted power-ups fire from their buttons; a board click cancels targeting.
        set({ selectedPowerUp: null });
        return;
      }
      if (cell.kind === 'quantum') {
        if (isOwnQuantum(s.board, index, me)) {
          await get().lockQuantumCell(index);
        } else if (isPeerQuantum(s.board, index, me) && s.turn === me && !isFrozen(me)) {
          await observeCell(index);
        }
        return;
      }
      if (cell.kind === 'empty' && s.turn === me && !isFrozen(me)) {
        await placeMove(index);
      }
    },

    activateHack: async () => {
      const s = get();
      if (s.phase !== 'ACTIVE' || !s.self) return;
      if (s.selfInventory.QUANTUM_HACK <= 0) return get().emitFx('error', -1);
      const target = quantumHackTarget(s.board, s.self.mark);
      if (target === null) return get().emitFx('error', -1);
      set({
        board: applyQuantumHack(s.board, s.self.mark, target),
        selfUses: { ...s.selfUses, QUANTUM_HACK: s.selfUses.QUANTUM_HACK + 1 },
      });
      await recomputeSelfView();
      await get().dispatch('POWERUP', { action: 'QUANTUM_HACK' } satisfies PowerUpPayload);
      get().emitFx('hack', target);
      finishIfWinner();
    },

    activateDilation: async () => {
      const s = get();
      if (s.phase !== 'ACTIVE' || !s.self || !s.peer) return;
      if (s.selfInventory.TIME_DILATION <= 0) return get().emitFx('error', -1);
      const victim = s.peer.mark;
      set({
        selfUses: { ...s.selfUses, TIME_DILATION: s.selfUses.TIME_DILATION + 1 },
        deadlines: { ...s.deadlines, [victim]: s.deadlines[victim] + DILATION_MS },
        dilationUntil: { ...s.dilationUntil, [victim]: Date.now() + DILATION_MS },
      });
      await recomputeSelfView();
      await get().dispatch('POWERUP', { action: 'TIME_DILATION' } satisfies PowerUpPayload);
      get().emitFx('dilation', -1);
    },

    lockQuantumCell: async (index) => {
      const s = get();
      if (s.phase !== 'ACTIVE' || !s.self || !s.signer || !s.address) return;
      if (!isOwnQuantum(s.board, index, s.self.mark)) return;
      if (s.selfBalance < QUANTUM_LOCK_COST) return get().emitFx('error', index);
      const secret = s.secrets[index];
      if (!secret) return;
      const burn = await buildBurnEvent({
        events: s.ledger,
        owner: s.address,
        signer: s.signer,
        amount: QUANTUM_LOCK_COST,
        reason: 'QUANTUM_LOCK',
        matchId: s.matchId,
      });
      let board: CellState[];
      try {
        board = lockQuantum(s.board, index, secret);
      } catch {
        return;
      }
      set({ board, ledger: [...s.ledger, burn] });
      persistSelfLedger();
      await recomputeSelfView();
      await get().dispatch('POWERUP', {
        action: 'QUANTUM_LOCK',
        cell: index,
        burn,
        secret,
      } satisfies PowerUpPayload);
      get().emitFx('collapse', index);
      finishIfWinner();
    },

    // ── Turn-clock watchdog (driven by useWebRTC's interval) ─────────────────
    tick: () => {
      const s = get();
      if (s.phase !== 'ACTIVE' || s.winner || !s.self) return;
      const now = Date.now();
      const deadline = s.deadlines[s.turn];
      if (deadline === 0 || now <= deadline) return;
      // Someone's clock expired — forfeit the turn. Both peers run the same rule,
      // and the TIMEOUT envelope lets lagging peers converge within tolerance.
      const forfeiting = s.turn;
      advanceTurn(opponentOf(forfeiting));
      void get().dispatch('TIMEOUT', { forfeiting } satisfies TimeoutPayload);
    },

    sendChat: async (text) => {
      const s = get();
      const clean = sanitizeChat(text);
      if (!clean || !s.address || s.phase === 'IDLE' || s.phase === 'CONNECTING') return false;
      if (!chatOutBucket.tryConsume()) {
        set({ chatLimitedAt: Date.now() });
        return false;
      }
      const seq = s.outSeq;
      await s.dispatch('CHAT', { text: clean } satisfies ChatPayload);
      const message: ChatMessage = {
        id: `${s.matchId ?? s.roomCode}:${seq}`,
        from: s.address,
        self: true,
        text: clean,
        at: Date.now(),
        seq,
      };
      set({ chat: [...get().chat, message] });
      return true;
    },

    setChatOpen: (open) => set({ chatOpen: open, unread: open ? 0 : get().unread }),

    requestRematch: async () => {
      const s = get();
      if (s.phase !== 'FINISHED') return;
      set({ rematchRequested: true });
      await s.dispatch('REMATCH', {});
      // The peer echoes REMATCH on accept; both sides reset exactly once because
      // the handler ignores REMATCH unless the local phase is FINISHED.
    },

    leaveMatch: async () => {
      const s = get();
      try {
        if (s.netStatus === 'connected') await s.dispatch('BYE', {});
      } catch {
        // best effort — the peer will see the drop anyway
      }
      s.netApi?.leave();
      resetToLobby();
      set({ netStatus: 'offline' });
    },

    flagCheat: (reason, by) => {
      console.warn('[xenon3] cheat flagged:', reason, 'by:', by);
      set({ cheat: { flagged: true, reason, by }, phase: 'ABORTED' });
      if (by === 'peer') {
        void get()
          .dispatch('CHEAT_FLAG', { reason } satisfies CheatFlagPayload)
          .catch(() => undefined);
      }
    },

    emitFx: (kind, cell = -1) => set({ fx: { nonce: Date.now() + Math.random(), kind, cell } }),

    toggleMuted: () => {
      const muted = !get().muted;
      try {
        window.localStorage.setItem('xenon3:muted', muted ? '1' : '0');
      } catch {
        /* storage unavailable — session-local toggle still works */
      }
      set({ muted });
    },

    setArmoryOpen: (open) => set({ armoryOpen: open }),
  };

  // ── Local move implementations (closures over set/get) ─────────────────────

  async function placeMove(index: number): Promise<void> {
    const s = get();
    if (!s.self || !isCellPlayable(s.board, index)) return;
    const seq = bumpPlacedSeq();
    const cell: CellState = { kind: 'mark', mark: s.self.mark, shielded: false, placedSeq: seq };
    set({
      board: s.board.map((c, i) => (i === index ? cell : c)),
      placedSeqCounter: seq,
    });
    await get().dispatch('MOVE', { cell: index } satisfies MovePayload);
    get().emitFx('place', index);
    if (!finishIfWinner()) advanceTurn(opponentOf(s.self.mark));
  }

  async function placeEntangle(index: number): Promise<void> {
    const s = get();
    if (!s.self || !s.signer || !s.address || !isCellPlayable(s.board, index)) return;
    if (!canAfford(s.selfBalance, POWER_UP_COST.QUANTUM_ENTANGLE)) return get().emitFx('error', index);
    const burn = await buildBurnEvent({
      events: s.ledger,
      owner: s.address,
      signer: s.signer,
      amount: POWER_UP_COST.QUANTUM_ENTANGLE,
      reason: 'PURCHASE:QUANTUM_ENTANGLE',
      matchId: s.matchId,
    });
    const secret = randomBytes32();
    const commitment = commitSecret(secret);
    const seq = bumpPlacedSeq();
    const cell: CellState = { kind: 'quantum', owner: s.self.mark, commitment, placedSeq: seq };
    set({
      board: s.board.map((c, i) => (i === index ? cell : c)),
      placedSeqCounter: seq,
      ledger: [...s.ledger, burn],
      secrets: { ...s.secrets, [index]: secret },
      selfUses: { ...s.selfUses, QUANTUM_ENTANGLE: s.selfUses.QUANTUM_ENTANGLE + 1 },
    });
    persistSelfLedger();
    await recomputeSelfView();
    await get().dispatch('ENTANGLE', { cell: index, commitment, burn } satisfies EntanglePayload);
    get().emitFx('place', index);
    advanceTurn(opponentOf(s.self.mark));
  }

  async function observeCell(index: number): Promise<void> {
    const s = get();
    if (!s.self) return;
    const salt = randomBytes32();
    set({ pendingSalts: { ...s.pendingSalts, [index]: salt } });
    await get().dispatch('OBSERVE', { cell: index, salt } satisfies ObservePayload);
    get().emitFx('dilation', index);
    advanceTurn(opponentOf(s.self.mark));
  }

  async function activateShield(index: number): Promise<void> {
    const s = get();
    if (!s.self) return;
    if (s.selfInventory.NEON_SHIELD <= 0) return get().emitFx('error', index);
    if (!isOwnUnshieldedMark(s.board, index, s.self.mark)) return get().emitFx('error', index);
    set({
      board: s.board.map((c, i) => (i === index && c.kind === 'mark' ? { ...c, shielded: true } : c)),
      selfUses: { ...s.selfUses, NEON_SHIELD: s.selfUses.NEON_SHIELD + 1 },
    });
    await recomputeSelfView();
    await get().dispatch('POWERUP', { action: 'NEON_SHIELD', cell: index } satisfies PowerUpPayload);
    get().emitFx('shield', index);
  }

  // ── Verified inbound message handlers ──────────────────────────────────────

  async function handleVerified(env: Envelope): Promise<void> {
    const s = get();
    switch (env.type) {
      case 'HELLO':
        await onHello(env as Envelope<HelloPayload>);
        return;
      case 'HELLO_ACK':
        await onHelloAck(env as Envelope<HelloPayload>);
        return;
      default:
        break;
    }

    // Everything below requires an established match and the real matchId.
    if (!s.peer || !s.self || !s.matchId) return;
    if (env.matchId !== s.matchId) return;

    switch (env.type) {
      case 'MOVE': {
        const { cell } = env.payload as MovePayload;
        if (s.phase !== 'ACTIVE' || s.turn !== s.peer.mark || isFrozen(s.peer.mark)) return;
        if (!isCellPlayable(s.board, cell)) return flagCheatLocal(`illegal move on cell ${cell}`);
        const seq = bumpPlacedSeq();
        set({
          board: get().board.map((c, i) =>
            i === cell ? ({ kind: 'mark', mark: s.peer!.mark, shielded: false, placedSeq: seq } as CellState) : c,
          ),
          placedSeqCounter: seq,
        });
        get().emitFx('place', cell);
        if (!finishIfWinner()) advanceTurn(s.self.mark);
        return;
      }
      case 'ENTANGLE': {
        const p = env.payload as EntanglePayload;
        if (s.phase !== 'ACTIVE' || s.turn !== s.peer.mark || isFrozen(s.peer.mark)) return;
        if (!isCellPlayable(s.board, p.cell)) return flagCheatLocal('entangle on occupied cell');
        if (!(await appendRemoteBurn(p.burn, 'PURCHASE:QUANTUM_ENTANGLE'))) return;
        const uses = { ...get().remoteUses, QUANTUM_ENTANGLE: get().remoteUses.QUANTUM_ENTANGLE + 1 };
        set({ remoteUses: uses });
        if (!(await recomputeRemoteView())) return;
        const seq = bumpPlacedSeq();
        set({
          board: get().board.map((c, i) =>
            i === p.cell
              ? ({ kind: 'quantum', owner: s.peer!.mark, commitment: p.commitment, placedSeq: seq } as CellState)
              : c,
          ),
          placedSeqCounter: seq,
        });
        get().emitFx('place', p.cell);
        advanceTurn(s.self.mark);
        return;
      }
      case 'OBSERVE': {
        const p = env.payload as ObservePayload;
        if (s.phase !== 'ACTIVE' || s.turn !== s.peer.mark || isFrozen(s.peer.mark)) return;
        const cell = s.board[p.cell];
        if (!cell || cell.kind !== 'quantum' || cell.owner !== s.self.mark) {
          return flagCheatLocal('observe of a non-existent superposition');
        }
        const secret = s.secrets[p.cell];
        if (!secret) return flagCheatLocal('observe of unknown commitment');
        try {
          set({ board: collapseQuantum(s.board, p.cell, secret, p.salt) });
        } catch (error) {
          return flagCheatLocal(error instanceof Error ? error.message : 'collapse failed');
        }
        get().emitFx('collapse', p.cell);
        await get().dispatch('REVEAL', { cell: p.cell, secret } satisfies RevealPayload);
        if (!finishIfWinner()) advanceTurn(s.self.mark);
        return;
      }
      case 'REVEAL': {
        const p = env.payload as RevealPayload;
        const salt = s.pendingSalts[p.cell];
        if (!salt) return flagCheatLocal('unsolicited quantum reveal');
        const cell = s.board[p.cell];
        if (!cell || cell.kind !== 'quantum' || cell.owner !== s.peer.mark) {
          return flagCheatLocal('reveal for a non-existent superposition');
        }
        try {
          set({ board: collapseQuantum(s.board, p.cell, p.secret, salt) });
        } catch (error) {
          return flagCheatLocal(error instanceof Error ? error.message : 'reveal mismatch');
        }
        const rest = { ...get().pendingSalts };
        delete rest[p.cell];
        set({ pendingSalts: rest });
        get().emitFx('collapse', p.cell);
        finishIfWinner();
        return;
      }
      case 'POWERUP': {
        const p = env.payload as PowerUpPayload;
        if (s.phase !== 'ACTIVE') return;
        if (p.action === 'QUANTUM_HACK') {
          const uses = { ...get().remoteUses, QUANTUM_HACK: get().remoteUses.QUANTUM_HACK + 1 };
          set({ remoteUses: uses });
          if (!(await recomputeRemoteView())) return;
          const target = quantumHackTarget(get().board, s.peer.mark);
          if (target === null) return flagCheatLocal('quantum hack with no legal target');
          set({ board: applyQuantumHack(get().board, s.peer.mark, target) });
          get().emitFx('hack', target);
          finishIfWinner();
          return;
        }
        if (p.action === 'NEON_SHIELD') {
          if (typeof p.cell !== 'number') return flagCheatLocal('shield without target');
          const uses = { ...get().remoteUses, NEON_SHIELD: get().remoteUses.NEON_SHIELD + 1 };
          set({ remoteUses: uses });
          if (!(await recomputeRemoteView())) return;
          if (!isOwnUnshieldedMark(get().board, p.cell, s.peer.mark)) {
            return flagCheatLocal('illegal shield target');
          }
          set({
            board: get().board.map((c, i) =>
              i === p.cell && c.kind === 'mark' ? { ...c, shielded: true } : c,
            ),
          });
          get().emitFx('shield', p.cell);
          return;
        }
        if (p.action === 'TIME_DILATION') {
          const uses = { ...get().remoteUses, TIME_DILATION: get().remoteUses.TIME_DILATION + 1 };
          set({ remoteUses: uses });
          if (!(await recomputeRemoteView())) return;
          const victim = s.self.mark;
          set({
            deadlines: { ...get().deadlines, [victim]: get().deadlines[victim] + DILATION_MS },
            dilationUntil: { ...get().dilationUntil, [victim]: Date.now() + DILATION_MS },
          });
          get().emitFx('dilation', -1);
          return;
        }
        if (p.action === 'QUANTUM_LOCK') {
          if (typeof p.cell !== 'number' || !p.burn || !p.secret) {
            return flagCheatLocal('malformed quantum lock');
          }
          if (!(await appendRemoteBurn(p.burn, 'QUANTUM_LOCK'))) return;
          try {
            set({ board: lockQuantum(get().board, p.cell, p.secret) });
          } catch (error) {
            return flagCheatLocal(error instanceof Error ? error.message : 'lock mismatch');
          }
          get().emitFx('collapse', p.cell);
          finishIfWinner();
          return;
        }
        return;
      }
      case 'BUY': {
        const p = env.payload as BuyPayload;
        if (!p.burn.reason.startsWith('PURCHASE:')) return flagCheatLocal('bad buy reason');
        set({ remoteLedger: [...get().remoteLedger, p.burn] });
        await recomputeRemoteView();
        return;
      }
      case 'DEPOSIT': {
        const p = env.payload as DepositPayload;
        if (p.event.reason !== 'WQD_DEPOSIT' || !p.event.deposit) {
          return flagCheatLocal('bad deposit event');
        }
        // recomputeRemoteView re-verifies the full proof (ECDSA + merkle +
        // PoW + confirmations) and flags the peer if it doesn't hold.
        set({ remoteLedger: [...get().remoteLedger, p.event] });
        await recomputeRemoteView();
        return;
      }
      case 'BALANCE': {
        const p = env.payload as BalancePayload;
        if (p.event.reason !== 'WQD_BALANCE' || !p.event.balance) {
          return flagCheatLocal('bad balance event');
        }
        // recomputeRemoteView re-verifies the signature + delta math;
        // auditRemoteBalanceClaims then checks the claim against OUR own
        // replayed chain state (async — flags when our sync reaches it).
        set({ remoteLedger: [...get().remoteLedger, p.event] });
        if (!(await recomputeRemoteView())) return;
        auditRemoteBalanceClaims();
        return;
      }
      case 'CHAT': {
        const p = env.payload as ChatPayload;
        if (!chatInBucket.tryConsume()) return; // flood defense: drop silently
        const text = sanitizeChat(typeof p.text === 'string' ? p.text : '');
        if (!text) return;
        const message: ChatMessage = {
          id: `${s.matchId}:${env.seq}`,
          from: env.from,
          self: false,
          text,
          at: Date.now(),
          seq: env.seq,
        };
        set({
          chat: [...get().chat, message],
          unread: get().chatOpen ? get().unread : get().unread + 1,
        });
        get().emitFx('chat', -1);
        return;
      }
      case 'TIMEOUT': {
        const p = env.payload as TimeoutPayload;
        if (s.phase !== 'ACTIVE') return;
        if (p.forfeiting !== get().turn) return; // already advanced — idempotent drop
        if (Date.now() < get().deadlines[p.forfeiting] - TIMEOUT_TOLERANCE_MS) return; // skew: ignore
        advanceTurn(opponentOf(p.forfeiting));
        return;
      }
      case 'REMATCH': {
        if (s.phase !== 'FINISHED') return;
        const starter = s.winner && s.winner.winner !== 'DRAW' ? opponentOf(s.winner.winner) : 'X';
        resetMatchState(starter);
        void get().dispatch('REMATCH', {}); // echo back so the initiator resets too
        return;
      }
      case 'SYNC_REQUEST': {
        if (s.role !== 'host') return; // host is the recovery authority
        await sendStateSync();
        return;
      }
      case 'STATE_SYNC': {
        if (s.role !== 'guest') return; // guests adopt; hosts never do
        const p = env.payload as StateSyncPayload;
        if (!Array.isArray(p.board) || p.board.length !== 9) return flagCheatLocal('bad sync board');
        if (p.placedSeq < get().placedSeqCounter) return flagCheatLocal('host rolled back state');
        set({
          board: p.board,
          turn: p.turn,
          winner: p.winner,
          phase: p.phase,
          deadlines: p.deadlines,
          dilationUntil: p.dilationUntil,
          placedSeqCounter: p.placedSeq,
        });
        return;
      }
      case 'PING': {
        const p = env.payload as PingPayload;
        const mine = computeStateHash(get().board, get().turn, get().winner);
        if (p.stateHash === mine) return;
        if (get().role === 'host') await sendStateSync();
        else await get().dispatch('SYNC_REQUEST', {});
        return;
      }
      case 'CHEAT_FLAG': {
        const p = env.payload as CheatFlagPayload;
        set({ cheat: { flagged: true, reason: p.reason ?? 'unspecified', by: 'self' }, phase: 'ABORTED' });
        return;
      }
      case 'BYE': {
        set({ phase: 'ABORTED', netError: 'opponent severed the link' });
        return;
      }
      default:
        return;
    }
  }

  function flagCheatLocal(reason: string): void {
    get().flagCheat(reason, 'peer');
  }

  async function sendStateSync(): Promise<void> {
    const s = get();
    await s.dispatch('STATE_SYNC', {
      board: s.board,
      turn: s.turn,
      winner: s.winner,
      phase: s.phase,
      deadlines: s.deadlines,
      dilationUntil: s.dilationUntil,
      placedSeq: s.placedSeqCounter,
    } satisfies StateSyncPayload);
  }

  async function onHello(env: Envelope<HelloPayload>): Promise<void> {
    const s = get();
    if (s.role !== 'host' || !s.address || !s.myNonce || !s.roomCode) return;
    if (env.matchId !== handshakeMatchId(s.roomCode)) return;
    if (s.peer) {
      // Duplicate HELLO (guest retry): retransmit the ORIGINAL ACK envelope —
      // a fresh seq would open a gap in the guest's inbound hash chain.
      if (s.peer.address === env.payload.address?.toLowerCase()) {
        const last = get().lastSentEnvelope;
        if (last && last.type === 'HELLO_ACK') get().netApi?.sendRaw(last);
      }
      return;
    }
    const guest = env.payload.address?.toLowerCase();
    if (!guest || !/^0x[0-9a-f]{40}$/.test(guest)) return;
    if (guest === s.address) {
      // Two tabs sharing one wallet (localStorage is per-origin): a ledger
      // cannot play against itself. Tell the guest WHY instead of going
      // silent — the fix is a tab-scoped sparring key on one side.
      get().netApi?.sendControl?.({ sameWallet: true });
      return;
    }
    const view = await validateLedger(env.payload.ledger ?? [], guest, emptyInventory());
    if (!view.ok) return flagCheatLocal(`handshake ledger invalid: ${view.error}`);
    const matchId = hashPayload({
      host: s.address,
      guest,
      hostNonce: s.myNonce,
      guestNonce: env.payload.nonce,
    });
    set({
      peer: { address: guest, mark: 'O' },
      self: { address: s.address, mark: 'X' },
      matchId,
      remoteLedger: env.payload.ledger ?? [],
      remoteBalance: view.balance,
      remoteInventory: view.inventory,
      netStatus: 'connected',
    });
    resetMatchState('X'); // host is X and opens the match
    get().emitFx('linked', -1); // handshake complete — channel locked
    auditRemoteBalanceClaims(); // audit any WQD_BALANCE claims in the guest's book
    await get().dispatch('HELLO_ACK', {
      address: s.address,
      nonce: s.myNonce,
      ledger: get().ledger,
    } satisfies HelloPayload);
  }

  async function onHelloAck(env: Envelope<HelloPayload>): Promise<void> {
    const s = get();
    if (s.role !== 'guest' || s.peer || !s.address || !s.myNonce) return;
    const host = env.payload.address?.toLowerCase();
    if (!host || !/^0x[0-9a-f]{40}$/.test(host) || host === s.address) return;
    const view = await validateLedger(env.payload.ledger ?? [], host, emptyInventory());
    if (!view.ok) return flagCheatLocal(`handshake ledger invalid: ${view.error}`);
    const matchId = hashPayload({
      host,
      guest: s.address,
      hostNonce: env.payload.nonce,
      guestNonce: s.myNonce,
    });
    if (env.matchId !== matchId) return flagCheatLocal('handshake matchId mismatch');
    set({
      peer: { address: host, mark: 'X' },
      self: { address: s.address, mark: 'O' },
      matchId,
      remoteLedger: env.payload.ledger ?? [],
      remoteBalance: view.balance,
      remoteInventory: view.inventory,
      netStatus: 'connected',
    });
    resetMatchState('X');
    get().emitFx('linked', -1); // handshake complete — channel locked
    auditRemoteBalanceClaims(); // audit any WQD_BALANCE claims in the host's book
  }
});

// ── Selectors ────────────────────────────────────────────────────────────────

export const selectIsMyTurn = (s: GameStore): boolean =>
  s.phase === 'ACTIVE' && !!s.self && s.turn === s.self.mark && s.dilationUntil[s.self.mark] <= Date.now();

export const selectCanAfford = (kind: PowerUpKind) => (s: GameStore): boolean =>
  canAfford(s.selfBalance, POWER_UP_COST[kind]);

export const EMPTY_CELL_SINGLETON = EMPTY_CELL;
