// ─────────────────────────────────────────────────────────────────────────────
// useWebRTC — serverless P2P transport over PeerJS (WebRTC DataChannel).
//
// PRIVATE MATCH:
//   • HOST registers a deterministic peer id  xenon3-<ROOMCODE>  — that IS the
//     room. Guests dial it directly. The public PeerJS cloud brokers signaling;
//     set NEXT_PUBLIC_PEER_* env vars to point at your own PeerServer/relay.
//
// QUICK MATCH (serverless global queue, no backend):
//   • One well-known rendezvous id  xenon3-quickmatch-v1  acts as the queue
//     node. Whoever registers it first HOLDS the queue; later arrivals dial it.
//   • Holder accepts the first challenger (store phase is IDLE) and the pair
//     runs the standard signed HELLO handshake against the synthetic
//     QUICKMATCH_CODE room. While busy, the holder answers {queueBusy:true}
//     control frames so seekers back off and retry with jitter.
//   • If the node vanishes mid-dial (holder closed the tab), the seeker flips
//     and claims the node itself — the queue self-heals without any server.
//
// COMMON:
//   • After the channel opens, a signed HELLO/HELLO_ACK handshake exchanges
//     WQD ledger snapshots and derives the matchId from both nonces.
//   • Every envelope is validated by the store (seq, hash chain, signature,
//     game rules). The channel is reliable+ordered; the store still buffers
//     out-of-order frames defensively.
//   • A 10s PING carries a state hash; mismatches trigger host-authoritative
//     STATE_SYNC recovery. A 250ms local interval drives turn-clock timeouts.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import { useEffect, useRef } from 'react';
import Peer, { type DataConnection } from 'peerjs';
import { computeStateHash, useGameStore, type NetApi } from '../store/useGameStore';
import {
  QUICKMATCH_CODE,
  handshakeMatchId,
  type Envelope,
  type HelloPayload,
  type PingPayload,
} from '../lib/protocol';

const roomPeerId = (code: string): string => `xenon3-${code}`;

/** The one well-known rendezvous point for the global Quick Match queue. */
const QUEUE_PEER_ID = 'xenon3-quickmatch-v1';

/** Queue etiquette: how many times a seeker retries a busy node before giving
 *  up. Sized to outlive the holder's 12s handshake watchdog with margin. */
const QUEUE_MAX_ATTEMPTS = 16;
const QUEUE_RETRY_MS = 2_500;
/** How often the guest retransmits its signed HELLO until the ACK lands. */
const HELLO_MAX_ATTEMPTS = 6;
const HELLO_RETRY_MS = 2_000;
/** A dialed channel that never opens (NAT/firewall) gives up after this. */
const DIAL_TIMEOUT_MS = 12_000;
/** Host-side handshake bound: no valid HELLO within this window → the ghost
 *  challenger is evicted and the queue node goes back to HOLDING. Without it
 *  a dead dial locks the node in CONNECTING forever (the BUSY-loop bug). */
const HELLO_TIMEOUT_MS = 12_000;
/** Transient ICE blips heal themselves — sever only after this grace window. */
const ICE_GRACE_MS = 6_000;
/** Safety bound on holder→seeker→holder flips when the node keeps flapping. */
const MAX_NODE_CLAIMS = 3;

/** PeerJS error types that mean "the signaling relay/socket is sick". */
const isRelayError = (type: string): boolean =>
  type === 'network' ||
  type === 'server-error' ||
  type === 'socket-error' ||
  type === 'socket-closed';

/** PeerJS broker config — public cloud by default, self-hostable via env. */
function peerOptions(): Record<string, unknown> {
  // ICE: explicit multi-STUN + TWO independent TURN providers. Passing our
  // own `config` REPLACES the library defaults, so every relay is repeated
  // here verbatim. The metered.ca Open Relay set is the same one the WQD
  // watcher syncs through — field-proven on the exact networks where the
  // PeerJS free TURN (UDP 3478 only, frequently dead/blocked) never opens a
  // channel: TURN over TCP 443 and TLS 443 looks like plain web traffic and
  // survives carrier-grade NAT + restrictive firewalls. Without a working
  // relay, two players behind symmetric NAT can signal but never open a
  // channel — the holder sees the dial, the HELLO never arrives, and the
  // handshake watchdog rolls the queue node back to HOLDING in a loop.
  const config = {
    iceServers: [
      { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
      { urls: ['stun:stun.cloudflare.com:3478', 'stun:stun.relay.metered.ca:80'] },
      {
        urls: ['turn:us-0.turn.peerjs.com:3478', 'turn:eu-0.turn.peerjs.com:3478'],
        username: 'peerjs',
        credential: 'peerjsp',
      },
      {
        urls: 'turn:standard.relay.metered.ca:80',
        username: 'openrelayproject',
        credential: 'openrelayproject',
      },
      {
        urls: 'turn:standard.relay.metered.ca:443',
        username: 'openrelayproject',
        credential: 'openrelayproject',
      },
      {
        urls: 'turns:standard.relay.metered.ca:443?transport=tcp',
        username: 'openrelayproject',
        credential: 'openrelayproject',
      },
    ],
    iceCandidatePoolSize: 4,
  };
  const host = process.env.NEXT_PUBLIC_PEER_HOST;
  if (!host) return { debug: 0, config };
  return {
    host,
    port: Number(process.env.NEXT_PUBLIC_PEER_PORT ?? 443),
    path: process.env.NEXT_PUBLIC_PEER_PATH ?? '/',
    secure: (process.env.NEXT_PUBLIC_PEER_SECURE ?? 'true') === 'true',
    debug: 0,
    config,
  };
}

const isEnvelope = (value: unknown): value is Envelope => {
  if (typeof value !== 'object' || value === null) return false;
  const env = value as Record<string, unknown>;
  return (
    typeof env.v === 'number' &&
    typeof env.matchId === 'string' &&
    typeof env.seq === 'number' &&
    typeof env.prevHash === 'string' &&
    typeof env.type === 'string' &&
    typeof env.from === 'string' &&
    typeof env.sig === 'string'
  );
};

/** Control frames are unsigned JSON (never trusted for game state). */
interface QueueControlFrame {
  queueBusy?: boolean;
  /** Host saw our HELLO arrive from its OWN wallet address (two tabs, one key). */
  sameWallet?: boolean;
}

const isControlFrame = (value: unknown): value is QueueControlFrame => {
  if (typeof value !== 'object' || value === null) return false;
  return 'queueBusy' in value || 'sameWallet' in value;
};

export function useWebRTC(): void {
  const peerRef = useRef<Peer | null>(null);
  const connRef = useRef<DataConnection | null>(null);

  useEffect(() => {
    const store = useGameStore;

    // ── Queue bookkeeping. Effect-local mutable slots (NOT React refs: hooks
    // are illegal inside useEffect; these never need to trigger renders). ──
    const helloRetryRef = { current: null as number | null };
    const queueTimerRef = { current: null as number | null };
    const queueModeRef = { current: 'idle' as 'idle' | 'holder' | 'seeker' };
    const nodeClaimsRef = { current: 0 };
    const holdWatchdogRef = { current: null as number | null };

    const clearHoldWatchdog = (): void => {
      if (holdWatchdogRef.current !== null) {
        window.clearTimeout(holdWatchdogRef.current);
        holdWatchdogRef.current = null;
      }
    };

    const clearHelloRetry = (): void => {
      if (helloRetryRef.current !== null) {
        window.clearInterval(helloRetryRef.current);
        helloRetryRef.current = null;
      }
    };

    const clearQueueTimer = (): void => {
      if (queueTimerRef.current !== null) {
        window.clearTimeout(queueTimerRef.current);
        queueTimerRef.current = null;
      }
    };

    /** Channels WE closed on purpose (busy-backoff, teardown) must not trip
     *  the drop detector when their 'close' event lands later. */
    const intentionalClose = new WeakSet<DataConnection>();

    /** Abort a dialed channel that never opens instead of hanging forever. */
    const armDialTimeout = (conn: DataConnection, onTimeout: () => void): void => {
      const timer = window.setTimeout(() => {
        if (conn.open) return;
        intentionalClose.add(conn);
        try {
          conn.close();
        } catch {
          // already dead
        }
        onTimeout();
      }, DIAL_TIMEOUT_MS);
      conn.on('open', () => window.clearTimeout(timer));
    };

    const teardown = (): void => {
      clearHelloRetry();
      clearQueueTimer();
      clearRelink();
      clearHoldWatchdog();
      queueModeRef.current = 'idle';
      try {
        if (connRef.current) intentionalClose.add(connRef.current);
        connRef.current?.close();
      } catch {
        // channel already dead
      }
      try {
        peerRef.current?.destroy();
      } catch {
        // peer already destroyed
      }
      connRef.current = null;
      peerRef.current = null;
    };

    /** Map PeerJS error types to player-readable, fail-safe UI states. */
    const reportPeerError = (context: 'host' | 'guest' | 'queue', error: unknown): void => {
      const type = (error as { type?: string }).type ?? '';
      if (type === 'unavailable-id' && context === 'host') {
        store.getState().setNetStatus('offline', 'room code already taken — roll a new one');
      } else if (type === 'peer-unavailable' && context === 'guest') {
        store.getState().setNetStatus('offline', 'room not found — check the code');
      } else if (isRelayError(type)) {
        store.getState().setNetStatus('offline', 'signaling relay unreachable');
      } else if (type === 'browser-incompatible') {
        store.getState().setNetStatus('offline', 'this browser lacks WebRTC support');
      }
      console.warn(`[xenon3] ${context} peer error:`, type, error);
    };

    /**
     * Relay-hiccup policy. Two hard rules learned from the field:
     *  1. NEVER kill a live match over a broker error — once paired, the data
     *     channel is direct P2P and the signaling relay is irrelevant.
     *  2. Otherwise, tear down IMMEDIATELY so a half-dead peer cannot keep a
     *     zombie registration at the broker (that ghost was busy-rejecting
     *     every challenger), then auto-relink a few times before giving up.
     */
    const relink = { attempts: 0, timer: null as number | null, active: false };
    const RELINK_MAX = 4;

    const clearRelink = (): void => {
      if (relink.timer !== null) {
        window.clearTimeout(relink.timer);
        relink.timer = null;
      }
    };

    const handlePeerError = (
      context: 'host' | 'guest' | 'queue',
      error: unknown,
      relinkAction: () => void,
    ): void => {
      const type = (error as { type?: string }).type ?? '';
      console.warn(`[xenon3] ${context} peer error:`, type, error);
      const s = store.getState();
      if (s.phase === 'ACTIVE' || s.phase === 'FINISHED') return; // rule 1
      if (isRelayError(type)) {
        teardown(); // rule 2 — release the id, no zombies
        if (relink.attempts < RELINK_MAX) {
          relink.attempts += 1;
          s.setQueueStatus(
            'dialing',
            `SIGNALING RELAY FLAKY — RELINK ${relink.attempts}/${RELINK_MAX}…`,
          );
          s.setNetStatus('joining');
          clearRelink();
          relink.timer = window.setTimeout(
            () => {
              relink.timer = null;
              relink.active = true;
              try {
                relinkAction();
              } finally {
                relink.active = false;
              }
            },
            3_500 + Math.floor(Math.random() * 900),
          );
          return;
        }
      }
      // Unrecoverable: back to the lobby with a readable banner — never leave
      // the player stranded on a waiting card over a dead wire.
      s.setQueueStatus('idle');
      void s.leaveMatch().then(() => reportPeerError(context, error));
    };

    /**
     * Attach the trust gate to a fresh DataConnection.
     * Non-envelope JSON control frames (queueBusy) are routed to `onControl`;
     * everything else must pass the store's signed-envelope gauntlet.
     */
    const wireConnection = (
      conn: DataConnection,
      onControl?: (frame: QueueControlFrame) => void,
    ): void => {
      connRef.current = conn;

      conn.on('data', (raw) => {
        let parsed: unknown = raw;
        if (typeof raw === 'string') {
          try {
            parsed = JSON.parse(raw);
          } catch {
            return; // non-JSON frame — not our protocol, ignore
          }
        }
        if (isControlFrame(parsed)) {
          onControl?.(parsed);
          return;
        }
        if (!isEnvelope(parsed)) return;
        void store.getState().applyRemote(parsed);
      });

      conn.on('close', () => {
        if (intentionalClose.has(conn)) return;
        if (connRef.current !== conn) return; // superseded channel — not ours anymore
        const s = store.getState();
        if (s.phase === 'ACTIVE') {
          s.setNetStatus('offline', 'link lost');
          useGameStore.setState({ phase: 'ABORTED', netError: 'opponent disconnected' });
        } else if (s.phase === 'CONNECTING') {
          clearHelloRetry();
          // Queue holder special case: a challenger died mid-handshake. The
          // node stays ours — roll back to HOLDING instead of leaving the
          // queue entirely (and instead of the old forever-CONNECTING lock).
          if (queueModeRef.current === 'holder' && s.role === 'host') {
            s.resetQueueForRetry();
            s.setQueueStatus('holding', 'HOLDING QUEUE NODE — first challenger gets the link');
            s.setNetStatus('hosting');
            return;
          }
          // A channel dying mid-handshake used to leave the lobby spinning
          // "joining…" forever. Fail fast, reset clean.
          s.setQueueStatus('idle');
          void s
            .leaveMatch()
            .then(() =>
              store
                .getState()
                .setNetStatus('offline', 'link dropped before the handshake — try again'),
            );
        }
      });

      // WiFi/NAT blips fire 'disconnected' and often heal within seconds — only
      // sever the match if the link is still dead after the grace window.
      let iceState = 'new';
      conn.on('iceStateChanged', (state) => {
        iceState = state;
        if (state !== 'disconnected' && state !== 'failed') return;
        window.setTimeout(() => {
          const s = store.getState();
          if (s.phase !== 'ACTIVE') return;
          if (connRef.current !== conn) return; // superseded channel
          if (iceState === 'connected' || iceState === 'completed') return; // healed
          if (intentionalClose.has(conn)) return;
          s.setNetStatus('offline', 'link lost');
          useGameStore.setState({ phase: 'ABORTED', netError: 'opponent disconnected' });
        }, ICE_GRACE_MS);
      });

      conn.on('error', (error) => {
        console.warn('[xenon3] data channel error:', error);
        store.getState().setNetStatus('offline', 'data channel fault');
      });
    };

    /** Politely refuse a second challenger while a match/handshake is live. */
    const rejectAsBusy = (conn: DataConnection): void => {
      conn.on('open', () => {
        try {
          conn.send(JSON.stringify({ queueBusy: true } satisfies QueueControlFrame));
        } catch {
          // channel died before we could answer — nothing more to do
        }
        // Give the frame a beat to flush before tearing down.
        window.setTimeout(() => {
          try {
            conn.close();
          } catch {
            // already closed
          }
        }, 500);
      });
    };

    /**
     * Guest-side HELLO loop. Retries retransmit the SAME signed envelope —
     * minting a fresh seq would open a gap in the host's inbound hash chain.
     */
    const startGuestHello = (): void => {
      clearHelloRetry();
      let attempts = 0;
      let helloEnv: Envelope | null = null;

      const sendHello = (): void => {
        const s = store.getState();
        if (s.phase !== 'CONNECTING' || s.peer) return; // handshake already done
        if (helloEnv) {
          api.sendRaw(helloEnv);
          return;
        }
        void s
          .dispatch('HELLO', {
            address: s.address ?? '',
            nonce: s.myNonce ?? ('0x' as never),
            ledger: s.ledger,
          } satisfies HelloPayload)
          .then((env) => {
            helloEnv = env;
          })
          .catch((error) => console.warn('[xenon3] failed to send HELLO:', error));
      };

      sendHello();
      helloRetryRef.current = window.setInterval(() => {
        attempts += 1;
        const s = store.getState();
        if (s.phase !== 'CONNECTING' || s.peer) {
          clearHelloRetry();
          return;
        }
        if (attempts > HELLO_MAX_ATTEMPTS) {
          clearHelloRetry();
          s.setQueueStatus('idle');
          s.setNetStatus('offline', 'host is not answering — try again');
          return;
        }
        sendHello();
      }, HELLO_RETRY_MS);
    };

    /** Guest-side handling for the host's same-wallet refusal. */
    const onSameWallet = (): void => {
      clearHelloRetry();
      const s = store.getState();
      s.setQueueStatus('idle');
      // leaveMatch returns the guest to the lobby; otherwise it would sit on
      // the waiting card in CONNECTING with the refusal only as a footnote.
      void s
        .leaveMatch()
        .then(() =>
          store
            .getState()
            .setNetStatus('offline', 'same wallet on both sides — give one tab a sparring key'),
        );
    };

    /** Seeker side of Quick Match: dial the queue node, back off when busy. */
    const dialQueue = (attempt: number): void => {
      queueModeRef.current = 'seeker';
      store.getState().setQueueStatus(
        'dialing',
        attempt === 0
          ? 'QUEUE NODE FOUND — REQUESTING MATCH…'
          : `NODE BUSY — RETRY ${attempt}/${QUEUE_MAX_ATTEMPTS}`,
      );
      store.getState().setNetStatus('joining');

      const peer = new Peer(peerOptions());
      peerRef.current = peer;

      peer.on('open', () => {
        const conn = peer.connect(QUEUE_PEER_ID, { reliable: true });

        // Busy node or dead dial → unwind our half-started handshake and retry.
        const retryLater = (reason: 'busy' | 'timeout'): void => {
          clearHelloRetry();
          intentionalClose.add(conn);
          try {
            conn.close();
          } catch {
            // already closing
          }
          try {
            peer.destroy();
          } catch {
            // already destroyed
          }
          if (peerRef.current === peer) peerRef.current = null;
          if (connRef.current === conn) connRef.current = null;
          store.getState().resetQueueForRetry();
          if (attempt >= QUEUE_MAX_ATTEMPTS) {
            store.getState().setQueueStatus('idle');
            store
              .getState()
              .setNetStatus(
                'offline',
                reason === 'timeout'
                  ? 'queue node unreachable — host a private room instead'
                  : 'queue is full — host a private room instead',
              );
            return;
          }
          // Deterministic backoff + jitter so a crowd of seekers de-synchronizes.
          const jitter = Math.floor(Math.random() * 700);
          queueTimerRef.current = window.setTimeout(
            () => dialQueue(attempt + 1),
            QUEUE_RETRY_MS + jitter,
          );
        };

        wireConnection(conn, (frame) => {
          if (frame.sameWallet) {
            onSameWallet();
            return;
          }
          if (!frame.queueBusy) return;
          retryLater('busy');
        });
        armDialTimeout(conn, () => retryLater('timeout'));
        conn.on('open', () => {
          // Channel up → run the exact same signed handshake as a private guest.
          store.getState().beginHandshake(QUICKMATCH_CODE, 'guest');
          startGuestHello();
        });
      });

      peer.on('error', (error) => {
        const type = (error as { type?: string }).type ?? '';
        if (type === 'peer-unavailable') {
          // Queue node vanished between our lookup and our dial: the holder
          // left. Claim the node ourselves — the queue must self-heal.
          try {
            peer.destroy();
          } catch {
            // already destroyed
          }
          if (peerRef.current === peer) peerRef.current = null;
          if (nodeClaimsRef.current >= MAX_NODE_CLAIMS) {
            store.getState().setQueueStatus('idle');
            store.getState().setNetStatus('offline', 'queue unstable — try again in a moment');
            return;
          }
          nodeClaimsRef.current += 1;
          queueTimerRef.current = window.setTimeout(() => api.quickMatch(), 800);
          return;
        }
        handlePeerError('queue', error, () => dialQueue(attempt));
      });
    };

    const api: NetApi = {
      hostRoom: (code) => {
        teardown();
        if (!relink.active) relink.attempts = 0; // fresh user intent
        store.getState().beginHandshake(code, 'host');
        store.getState().setNetStatus('hosting');
        const peer = new Peer(roomPeerId(code), peerOptions());
        peerRef.current = peer;

        peer.on('open', () => {
          // Room registered — waiting for a challenger to dial in.
        });

        peer.on('connection', (conn) => {
          // Anti-hijack: once a handshake is in progress or a match is live,
          // any second dialer gets a polite busy refusal instead of the wire.
          if (store.getState().phase !== 'CONNECTING' || store.getState().peer) {
            rejectAsBusy(conn);
            return;
          }
          // Attach the data listener IMMEDIATELY — the guest's HELLO can arrive
          // in the same tick as 'open'; wiring inside 'open' risks losing it.
          wireConnection(conn, (frame) => {
            if (frame.queueBusy) return; // guests never send this; ignore
          });
        });

        peer.on('error', (error) => handlePeerError('host', error, () => api.hostRoom(code)));
      },

      joinRoom: (code) => {
        teardown();
        if (!relink.active) relink.attempts = 0;
        store.getState().beginHandshake(code, 'guest');
        store.getState().setNetStatus('joining');
        const peer = new Peer(peerOptions());
        peerRef.current = peer;

        peer.on('open', () => {
          const conn = peer.connect(roomPeerId(code), { reliable: true });
          wireConnection(conn, (frame) => {
            if (frame.sameWallet) {
              onSameWallet();
              return;
            }
            if (!frame.queueBusy) return;
            // Host refused us: the room is already playing someone else.
            clearHelloRetry();
            intentionalClose.add(conn);
            store.getState().setQueueStatus('idle');
            store.getState().setNetStatus('offline', 'room is already in a match');
          });
          // A dial that never opens (symmetric NAT, office firewall) used to
          // spin forever — fail with an actionable message instead.
          armDialTimeout(conn, () => {
            clearHelloRetry();
            store.getState().setQueueStatus('idle');
            void store
              .getState()
              .leaveMatch()
              .then(() =>
                store
                  .getState()
                  .setNetStatus(
                    'offline',
                    'host unreachable — the room is gone or a firewall blocked the P2P link',
                  ),
              );
          });
          conn.on('open', () => {
            startGuestHello();
          });
        });

        peer.on('error', (error) => handlePeerError('guest', error, () => api.joinRoom(code)));
      },

      quickMatch: () => {
        teardown();
        if (!relink.active) relink.attempts = 0;
        nodeClaimsRef.current = 0;
        store.getState().setQueueStatus('holding', 'CLAIMING THE QUEUE NODE…');
        store.getState().setNetStatus('hosting');

        // Attempt to BECOME the queue node. If another player already holds
        // it, PeerJS fires 'unavailable-id' and we flip to seeker mode.
        const peer = new Peer(QUEUE_PEER_ID, peerOptions());
        peerRef.current = peer;

        peer.on('open', () => {
          queueModeRef.current = 'holder';
          store
            .getState()
            .setQueueStatus('holding', 'HOLDING QUEUE NODE — first challenger gets the link');
        });

        peer.on('connection', (conn) => {
          // Accept only while we're idle in the lobby; mid-match challengers
          // get the busy frame so they keep hunting.
          if (store.getState().phase !== 'IDLE') {
            rejectAsBusy(conn);
            return;
          }
          store.getState().setQueueStatus('idle', null);
          store.getState().beginHandshake(QUICKMATCH_CODE, 'host');
          store.getState().setNetStatus('hosting');
          wireConnection(conn);
          // Handshake watchdog: if this challenger ghosts us before the HELLO
          // completes, roll back to HOLDING. Without this, one dead dial parks
          // the node in CONNECTING forever and every seeker reads BUSY — the
          // exact queue lock seen in the field.
          clearHoldWatchdog();
          holdWatchdogRef.current = window.setTimeout(() => {
            holdWatchdogRef.current = null;
            if (queueModeRef.current !== 'holder') return;
            if (connRef.current !== conn) return; // a newer challenger superseded it
            const s = store.getState();
            if (s.phase !== 'CONNECTING' || s.role !== 'host' || s.peer) return; // handshake landed
            console.warn('[xenon3] queue handshake timed out — node back to HOLDING');
            intentionalClose.add(conn);
            try {
              conn.close();
            } catch {
              // already dead
            }
            if (connRef.current === conn) connRef.current = null;
            s.resetQueueForRetry();
            s.setQueueStatus('holding', 'HOLDING QUEUE NODE — first challenger gets the link');
            s.setNetStatus('hosting');
          }, HELLO_TIMEOUT_MS);
        });

        peer.on('error', (error) => {
          const type = (error as { type?: string }).type ?? '';
          if (type === 'unavailable-id' && queueModeRef.current === 'idle') {
            // Node is held by someone else → become a seeker and dial it.
            try {
              peer.destroy();
            } catch {
              // already destroyed
            }
            if (peerRef.current === peer) peerRef.current = null;
            dialQueue(0);
            return;
          }
          handlePeerError('queue', error, () => api.quickMatch());
        });
      },

      leave: () => {
        teardown();
        store.getState().setQueueStatus('idle');
        store.getState().setNetStatus('offline');
      },

      sendRaw: (env) => {
        const conn = connRef.current;
        if (conn && conn.open) {
          conn.send(JSON.stringify(env));
        }
      },

      sendControl: (frame) => {
        const conn = connRef.current;
        if (conn && conn.open) {
          try {
            conn.send(JSON.stringify(frame));
          } catch {
            // channel racing a close — advisory frame, safe to drop
          }
        }
      },
    };

    store.getState().setNetApi(api);

    // Turn-clock watchdog.
    const tickTimer = window.setInterval(() => store.getState().tick(), 250);

    // Desync detector: host-authoritative recovery via STATE_SYNC.
    const pingTimer = window.setInterval(() => {
      const s = store.getState();
      if (s.netStatus !== 'connected' || (s.phase !== 'ACTIVE' && s.phase !== 'FINISHED')) return;
      void s.dispatch('PING', {
        stateHash: computeStateHash(s.board, s.turn, s.winner),
      } satisfies PingPayload);
    }, 10_000);

    // A sleeping phone can't answer challengers — release the queue node so
    // it never zombie-holds the global rendezvous key while the owner is away.
    const onHidden = (): void => {
      if (document.visibilityState !== 'hidden') return;
      const s = store.getState();
      if (queueModeRef.current === 'holder' && s.phase === 'IDLE') {
        teardown();
        s.setQueueStatus('idle');
        s.setNetStatus('offline', 'queue released while the tab slept — re-enter when back');
      }
    };
    document.addEventListener('visibilitychange', onHidden);

    const onUnload = (): void => teardown();
    window.addEventListener('beforeunload', onUnload);

    return () => {
      window.clearInterval(tickTimer);
      window.clearInterval(pingTimer);
      document.removeEventListener('visibilitychange', onHidden);
      window.removeEventListener('beforeunload', onUnload);
      teardown();
      store.getState().setNetApi(null);
    };
    // handshakeMatchId is referenced for protocol documentation; no reactive deps needed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  void handshakeMatchId;
}
