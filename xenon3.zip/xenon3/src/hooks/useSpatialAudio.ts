// ─────────────────────────────────────────────────────────────────────────────
// useSpatialAudio — procedural WebAudio synth engine (zero asset files).
// Every FX cue is synthesized: oscillators + filtered noise, positioned with a
// StereoPannerNode derived from the board cell. The AudioContext is unlocked on
// the first user gesture, satisfying browser autoplay policies.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import { useEffect } from 'react';
import { useGameStore } from '../store/useGameStore';
import { CELL_COL, CELL_ROW, type FxKind } from '../types';

interface ToneSpec {
  from: number;
  to?: number;
  duration: number;
  type: OscillatorType;
  gain: number;
  delay?: number;
}

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private muted = false;

  /** Must be called from a user gesture at least once. Idempotent: safe to
   *  re-call on every gesture and on tab-visible, because mobile browsers
   *  SUSPEND the context whenever the tab goes to the background (the
   *  two-tabs-on-one-phone duel flow) — without a re-resume, every sound
   *  dies silently after the first tab switch. */
  unlock(): void {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const Ctor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      this.ctx = new Ctor();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.35;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
  }

  /** Master mute — gain 0 keeps the graph alive so un-mute is instant. */
  setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.master) this.master.gain.value = muted ? 0 : 0.35;
  }

  private panFor(cell: number): number {
    if (cell < 0) return 0;
    return (CELL_COL(cell) - 1) * 0.65; // left / center / right
  }

  private output(cell: number): AudioNode | null {
    if (!this.ctx || !this.master) return null;
    if (typeof this.ctx.createStereoPanner === 'function') {
      const panner = this.ctx.createStereoPanner();
      panner.pan.value = this.panFor(cell);
      panner.connect(this.master);
      return panner;
    }
    return this.master;
  }

  private tone(spec: ToneSpec, cell: number): void {
    if (!this.ctx) return;
    const out = this.output(cell);
    if (!out) return;
    const t0 = this.ctx.currentTime + (spec.delay ?? 0);
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = spec.type;
    osc.frequency.setValueAtTime(spec.from, t0);
    if (spec.to !== undefined) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(1, spec.to), t0 + spec.duration);
    }
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(spec.gain, t0 + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + spec.duration);
    osc.connect(gain).connect(out);
    osc.start(t0);
    osc.stop(t0 + spec.duration + 0.05);
  }

  private noise(duration: number, filterFrom: number, filterTo: number, gainValue: number, cell: number): void {
    if (!this.ctx) return;
    const out = this.output(cell);
    if (!out) return;
    const t0 = this.ctx.currentTime;
    const length = Math.max(1, Math.floor(this.ctx.sampleRate * duration));
    const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i += 1) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / length);
    }
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(filterFrom, t0);
    filter.frequency.exponentialRampToValueAtTime(Math.max(20, filterTo), t0 + duration);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainValue, t0);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + duration);
    source.connect(filter).connect(gain).connect(out);
    source.start(t0);
  }

  play(kind: FxKind, cell: number): void {
    if (this.muted || !this.ctx || this.ctx.state !== 'running') return;
    switch (kind) {
      case 'linked':
        // Link established: two rising handshake blips locked into a bright
        // perfect-fifth chime with a short shimmer — a "channel locked" cue,
        // deliberately shorter and drier than the victory fanfare.
        this.noise(0.05, 6400, 2800, 0.1, cell);
        this.tone({ from: 587.33, duration: 0.1, type: 'sine', gain: 0.42 }, cell);
        this.tone({ from: 880, duration: 0.12, type: 'sine', gain: 0.42, delay: 0.09 }, cell);
        this.tone({ from: 1174.66, duration: 0.34, type: 'triangle', gain: 0.36, delay: 0.18 }, cell);
        this.tone({ from: 1760, duration: 0.4, type: 'sine', gain: 0.2, delay: 0.26 }, cell);
        break;
      case 'place':
        this.tone({ from: 720, to: 1440, duration: 0.12, type: 'sine', gain: 0.5 }, cell);
        this.noise(0.06, 5200, 1800, 0.12, cell);
        break;
      case 'explode':
        this.noise(0.5, 3600, 90, 0.7, cell);
        this.tone({ from: 220, to: 42, duration: 0.5, type: 'triangle', gain: 0.6 }, cell);
        break;
      case 'shield':
        this.tone({ from: 330, duration: 0.18, type: 'triangle', gain: 0.4 }, cell);
        this.tone({ from: 495, duration: 0.22, type: 'triangle', gain: 0.32, delay: 0.04 }, cell);
        break;
      case 'hack':
        // Breach cue: a static tear, four bit-crush stutters, a slicing zap,
        // a detuned digital wail and a corrupted sub drop — a hijack, not a zap.
        this.noise(0.16, 8200, 1400, 0.26, cell);
        [0, 0.05, 0.1, 0.15].forEach((delay, i) =>
          this.tone({ from: i % 2 === 0 ? 2400 : 1700, duration: 0.03, type: 'square', gain: 0.16, delay }, cell),
        );
        this.tone({ from: 1400, to: 160, duration: 0.18, type: 'sawtooth', gain: 0.34, delay: 0.06 }, cell);
        this.tone({ from: 466.16, to: 233.08, duration: 0.3, type: 'square', gain: 0.18, delay: 0.16 }, cell);
        this.tone({ from: 96, to: 36, duration: 0.42, type: 'sine', gain: 0.46, delay: 0.2 }, cell);
        break;
      case 'dilation':
        this.tone({ from: 96, to: 42, duration: 0.55, type: 'sine', gain: 0.55 }, cell);
        break;
      case 'collapse':
        this.tone({ from: 980, to: 240, duration: 0.3, type: 'sine', gain: 0.5 }, cell);
        this.noise(0.2, 6800, 2400, 0.14, cell);
        break;
      case 'win':
        // Victory fanfare: rising major arpeggio over a warm sub root, with a
        // bright shimmer tail — lands right as the burst cinematic fires.
        this.tone({ from: 130.81, duration: 1.5, type: 'triangle', gain: 0.3 }, cell);
        [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98].forEach((freq, i) =>
          this.tone({ from: freq, duration: i >= 4 ? 0.55 : 0.24, type: 'triangle', gain: 0.4, delay: i * 0.1 }, cell),
        );
        [261.63, 329.63, 392.0].forEach((freq, i) =>
          this.tone({ from: freq, duration: 0.5, type: 'sine', gain: 0.2, delay: 0.5 + i * 0.02 }, cell),
        );
        this.noise(1.1, 7200, 900, 0.22, cell);
        break;
      case 'defeat':
        // Defeat dirge: collapsing saw, a detuned minor drone and a deep thud —
        // the audible opposite of the fanfare.
        this.tone({ from: 220, to: 55, duration: 1.3, type: 'sawtooth', gain: 0.34 }, cell);
        this.tone({ from: 233.08, to: 58.27, duration: 1.4, type: 'sawtooth', gain: 0.26, delay: 0.05 }, cell);
        this.tone({ from: 98, to: 41.2, duration: 1.6, type: 'sine', gain: 0.5, delay: 0.08 }, cell);
        this.tone({ from: 65.41, to: 32.7, duration: 1.8, type: 'triangle', gain: 0.4, delay: 0.35 }, cell);
        this.noise(1.0, 900, 45, 0.5, cell);
        break;
      case 'stalemate':
        // Neutral suspended ping — two soft fifths, no resolution either way.
        this.tone({ from: 440, duration: 0.35, type: 'sine', gain: 0.3 }, cell);
        this.tone({ from: 554.37, duration: 0.4, type: 'sine', gain: 0.22, delay: 0.12 }, cell);
        this.tone({ from: 659.25, duration: 0.5, type: 'triangle', gain: 0.18, delay: 0.24 }, cell);
        break;
      case 'chat':
        this.tone({ from: 1560, duration: 0.035, type: 'square', gain: 0.12 }, -1);
        break;
      case 'error':
        this.tone({ from: 160, duration: 0.08, type: 'square', gain: 0.28 }, -1);
        this.tone({ from: 140, duration: 0.09, type: 'square', gain: 0.28, delay: 0.1 }, -1);
        break;
      default:
        break;
    }
  }
}

// Module-level singleton — one engine per tab, shared by every subscriber.
const engine = new AudioEngine();

/** Subscribe once at the app root: every store FX impulse becomes a sound. */
export function useSpatialAudio(): void {
  useEffect(() => {
    engine.setMuted(useGameStore.getState().muted);
    // NOT { once: true }: the context must be re-resumed after every tab
    // backgrounding, so every later gesture re-arms it.
    const unlock = (): void => engine.unlock();
    const onVisible = (): void => {
      if (document.visibilityState === 'visible') engine.unlock();
    };
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    document.addEventListener('visibilitychange', onVisible);

    let lastNonce = 0;
    const unsubscribe = useGameStore.subscribe((state) => {
      engine.setMuted(state.muted);
      if (state.fx.nonce !== lastNonce) {
        lastNonce = state.fx.nonce;
        engine.play(state.fx.kind, state.fx.cell);
      }
    });

    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
      document.removeEventListener('visibilitychange', onVisible);
      unsubscribe();
    };
  }, []);
}
