// ─────────────────────────────────────────────────────────────────────────────
// Xenon3 wire protocol. Every message is a signed envelope in a per-player
// hash chain: seq increments monotonically and prevHash commits to the previous
// envelope, giving replay protection, loss detection and ordering proofs.
// ─────────────────────────────────────────────────────────────────────────────

import type { Hex } from 'viem';
import type { CellState, Mark, MatchPhase, WinResult } from '../types';
import type { LedgerEvent } from './ledger';

export const PROTOCOL_VERSION = 1;

/**
 * Synthetic room code for Quick Match pairings. Both queue peers run the normal
 * signed HELLO handshake against this constant, so private and quick matches
 * share one verified code path; the real matchId is still derived from nonces.
 */
export const QUICKMATCH_CODE = 'QUICKMATCH';

/** matchId used during the handshake, before the real matchId is derived. */
export const handshakeMatchId = (roomCode: string): string => `handshake:${roomCode}`;

export type MsgType =
  | 'HELLO'
  | 'HELLO_ACK'
  | 'MOVE'
  | 'ENTANGLE'
  | 'OBSERVE'
  | 'REVEAL'
  | 'POWERUP'
  | 'BUY'
  | 'DEPOSIT'
  | 'BALANCE'
  | 'CHAT'
  | 'TIMEOUT'
  | 'REMATCH'
  | 'SYNC_REQUEST'
  | 'STATE_SYNC'
  | 'PING'
  | 'CHEAT_FLAG'
  | 'BYE';

export interface Envelope<T = unknown> {
  v: number;
  matchId: string;
  seq: number;
  prevHash: Hex;
  type: MsgType;
  payload: T;
  from: string;
  sig: Hex;
}

/** The exact body covered by the EIP-191 signature. */
export const envelopeBody = (env: Envelope) => ({
  v: env.v,
  matchId: env.matchId,
  seq: env.seq,
  prevHash: env.prevHash,
  type: env.type,
  payload: env.payload,
});

// ── Payloads ─────────────────────────────────────────────────────────────────

export interface HelloPayload {
  address: string;
  nonce: Hex;
  ledger: LedgerEvent[];
}

export interface MovePayload {
  cell: number;
}

export interface EntanglePayload {
  cell: number;
  commitment: Hex;
  burn: LedgerEvent;
}

export interface ObservePayload {
  cell: number;
  salt: Hex;
}

export interface RevealPayload {
  cell: number;
  secret: Hex;
}

export type PowerUpAction = 'QUANTUM_HACK' | 'NEON_SHIELD' | 'TIME_DILATION' | 'QUANTUM_LOCK';

export interface PowerUpPayload {
  action: PowerUpAction;
  cell?: number;
  /** Present on QUANTUM_LOCK (the 3 WQD decoherence burn). */
  burn?: LedgerEvent;
  /** Present on QUANTUM_LOCK so the peer can verify the commitment. */
  secret?: Hex;
}

export interface BuyPayload {
  burn: LedgerEvent;
}

export interface DepositPayload {
  /** A CREDIT event carrying a self-verifying on-chain deposit proof. */
  event: LedgerEvent;
}

export interface BalancePayload {
  /** A CREDIT event carrying a wallet-signed on-chain balance claim (delta). */
  event: LedgerEvent;
}

export interface ChatPayload {
  text: string;
}

export interface TimeoutPayload {
  forfeiting: Mark;
}

export interface PingPayload {
  stateHash: Hex;
}

export interface StateSyncPayload {
  board: CellState[];
  turn: Mark;
  winner: WinResult | null;
  phase: MatchPhase;
  deadlines: Record<Mark, number>;
  dilationUntil: Record<Mark, number>;
  placedSeq: number;
}

export interface CheatFlagPayload {
  reason: string;
}

// ── Chat hygiene ─────────────────────────────────────────────────────────────

export const CHAT_MAX_LENGTH = 280;

/** Strip ASCII control characters (React escapes HTML by default — no XSS surface). */
export function sanitizeChat(text: string): string {
  // eslint-disable-next-line no-control-regex
  return text.replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, CHAT_MAX_LENGTH);
}
