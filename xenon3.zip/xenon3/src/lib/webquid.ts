// ─────────────────────────────────────────────────────────────────────────────
// WebQuid (WQD) bridge.
// Two legitimate credit paths, no faucet, no free credits:
//   1. Same-origin issuer attestations the WebQuid platform writes to
//      localStorage (ecosystem hand-off when both apps share an origin).
//   2. On-chain deposits: the player burns WQD to the chain's zero address and
//      the deposit bridge (wqdWatcher.ts) proves it to both peers.
// WQD is strictly an in-game credit: no purchase, no cash-out, no wagering.
// ─────────────────────────────────────────────────────────────────────────────

import { privateKeyToAccount } from 'viem/accounts';
import type { Hex } from 'viem';
import { recoverPayloadSigner } from './crypto';

/**
 * Issuer address for same-origin attestations. Currently the public demo
 * (Hardhat/Anvil #0) key — replace with the platform's production issuer when
 * the WebQuid terminal starts writing attestations for real.
 */
const DEMO_ISSUER_KEY: Hex =
  '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';

export const WEBQUID_ISSUER_ADDRESS = privateKeyToAccount(DEMO_ISSUER_KEY).address.toLowerCase();

export interface WqdCredit {
  type: 'WQD_CREDIT';
  to: string;
  amount: number;
  nonce: string;
  issuedAt: number;
  source: 'WEBQUID_MINING' | 'DEMO_FAUCET';
}

export interface SignedCredit {
  credit: WqdCredit;
  signature: Hex;
  signer: string;
}

const CREDITS_KEY = 'xenon3:credits';
/** Key the main WebQuid mining app writes to (same-origin ecosystem hand-off). */
const PLATFORM_KEY = 'webquid:wqd_credits';

const storageAvailable = (): boolean =>
  typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';

export function loadStoredCredits(): SignedCredit[] {
  if (!storageAvailable()) return [];
  try {
    const raw = window.localStorage.getItem(CREDITS_KEY);
    return raw ? (JSON.parse(raw) as SignedCredit[]) : [];
  } catch {
    return [];
  }
}

export function persistCredits(credits: SignedCredit[]): void {
  if (!storageAvailable()) return;
  window.localStorage.setItem(CREDITS_KEY, JSON.stringify(credits));
}

/** Verify an issuer signature over a credit attestation. */
export async function verifyCredit(signed: SignedCredit): Promise<boolean> {
  try {
    if (signed.credit.type !== 'WQD_CREDIT') return false;
    if (!Number.isInteger(signed.credit.amount) || signed.credit.amount <= 0) return false;
    const signer = await recoverPayloadSigner(signed.credit, signed.signature);
    return signer === WEBQUID_ISSUER_ADDRESS && signer === signed.signer.toLowerCase();
  } catch {
    return false;
  }
}

/** Pull attestations the main WebQuid platform wrote into same-origin localStorage. */
export function readPlatformCredits(): SignedCredit[] {
  if (!storageAvailable()) return [];
  try {
    const raw = window.localStorage.getItem(PLATFORM_KEY);
    return raw ? (JSON.parse(raw) as SignedCredit[]) : [];
  } catch {
    return [];
  }
}

// There is NO faucet. WQD enters the game only through (a) same-origin issuer
// attestations written by the WebQuid platform, or (b) on-chain deposits burned
// to the zero sink and proven via the deposit bridge (see wqdWatcher.ts).

// ── WebQuid identity: ONLY real, pre-existing wallets ────────────────────────
//
// Xenon3 NEVER mints a wallet. Resolution order on "WEBQUID WALLET":
//   1. A key the player previously imported into Xenon3 (xenon3:wqd_key).
//   2. A key the WebQuid platform itself left on THIS origin (same browser,
//      same domain — the ecosystem hand-off). Several well-known slots are
//      probed because platform versions have used different names.
// If neither exists, connection is refused and the UI explains where to get a
// wallet (the WebQuid terminal) and how to import its key.
// Keys NEVER leave the device; they sit in localStorage and sign locally.

/** Slot holding the player's own imported WebQuid identity key. */
const IMPORTED_KEY = 'xenon3:wqd_key';

/** Well-known slots the WebQuid platform may store its session wallet under. */
const PLATFORM_WALLET_KEYS = [
  'webquid:wallet_key',
  'webquid:private_key',
  'webquid:session_key',
  'webquid:burner_key',
  'wqd:wallet_key',
];

const PRIVATE_KEY_PATTERN = /^0x[0-9a-fA-F]{64}$/;

export type WebquidIdentitySource = 'imported' | 'platform' | 'sparring';

// ── Tab-scoped sparring identity ─────────────────────────────────────────────
//
// localStorage is shared by every tab on this origin, so two tabs always load
// the SAME wallet — and a ledger cannot play a match against itself. For
// local duels (and testing) one tab can adopt a SPARRING key: a random key
// that lives only in this tab's sessionStorage, never touches localStorage,
// never leaves the device, and vanishes when the tab closes. It starts with
// 0 WQD like any fresh wallet — the faucet rules are unchanged.

const TAB_SPARRING_KEY = 'xenon3:tab_key';

/** Create (or rotate) this tab's sparring key. Returns null when storage is blocked. */
export function createTabSparringKey(): Hex | null {
  if (!storageAvailable()) return null;
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  const key = `0x${[...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')}` as Hex;
  try {
    window.sessionStorage.setItem(TAB_SPARRING_KEY, key);
  } catch {
    return null;
  }
  return key;
}

/** This tab's sparring key, if one was created. */
export function loadTabSparringKey(): Hex | null {
  if (!storageAvailable()) return null;
  try {
    const raw = window.sessionStorage.getItem(TAB_SPARRING_KEY);
    return raw && isPrivateKey(raw) ? normalizeKey(raw) : null;
  } catch {
    return null;
  }
}

/** Drop the sparring key — the tab falls back to the shared wallet. */
export function clearTabSparringKey(): void {
  try {
    window.sessionStorage.removeItem(TAB_SPARRING_KEY);
  } catch {
    // storage blocked — nothing to clear
  }
}

const isPrivateKey = (value: unknown): value is Hex =>
  typeof value === 'string' && PRIVATE_KEY_PATTERN.test(value.trim());

/** Normalize any valid key to lowercase 0x-hex (viem accepts any case). */
const normalizeKey = (raw: string): Hex => raw.trim().toLowerCase() as Hex;

/** Extract a key from raw hex or a JSON blob with a key-ish field. */
function extractKey(raw: string): Hex | null {
  const trimmed = raw.trim();
  if (isPrivateKey(trimmed)) return normalizeKey(trimmed);
  if (trimmed.startsWith('{') || trimmed.startsWith('"')) {
    try {
      const parsed = JSON.parse(trimmed) as unknown;
      if (isPrivateKey(parsed)) return normalizeKey(parsed);
      if (typeof parsed === 'object' && parsed !== null) {
        for (const field of ['privateKey', 'key', 'secret', 'walletKey']) {
          const candidate = (parsed as Record<string, unknown>)[field];
          if (isPrivateKey(candidate)) return normalizeKey(candidate);
        }
      }
    } catch {
      // not JSON — fall through
    }
  }
  return null;
}

/** The key the player previously imported into Xenon3, if any. */
export function loadImportedKey(): Hex | null {
  if (!storageAvailable()) return null;
  const raw = window.localStorage.getItem(IMPORTED_KEY);
  return raw && isPrivateKey(raw) ? normalizeKey(raw) : null;
}

/** Probe the platform's well-known slots for an existing WebQuid wallet. */
export function findPlatformWalletKey(): Hex | null {
  if (!storageAvailable()) return null;
  for (const slot of PLATFORM_WALLET_KEYS) {
    const raw = window.localStorage.getItem(slot);
    if (!raw) continue;
    const found = extractKey(raw);
    if (found) return found;
  }
  return null;
}

export function persistImportedKey(key: Hex): void {
  if (storageAvailable()) window.localStorage.setItem(IMPORTED_KEY, key);
}

export function clearImportedKey(): void {
  if (storageAvailable()) window.localStorage.removeItem(IMPORTED_KEY);
}

/** Validate + normalize a user-pasted key; throws a friendly error otherwise.
 *  The 0x prefix is optional — wallets and terminals often copy bare hex. */
export function normalizePrivateKey(raw: string): Hex {
  const trimmed = raw.trim();
  const prefixed =
    trimmed.startsWith('0x') || trimmed.startsWith('0X') ? trimmed : `0x${trimmed}`;
  if (!isPrivateKey(prefixed)) {
    throw new Error('invalid key — expected 64 hex characters (the 0x prefix is optional)');
  }
  return normalizeKey(prefixed);
}

// ── Runtime configuration ────────────────────────────────────────────────────
// The WebQuid terminal address lives in `public/webquid.config.json` so it can
// be changed WITHOUT rebuilding the app — edit the JSON file and reload.

export const DEFAULT_TERMINAL_URL = 'https://tylerdurdensworld.github.io/Webquid/';

let cachedTerminalUrl: string | null = null;

/** Fetch the terminal URL from webquid.config.json, falling back to the default. */
export async function loadTerminalUrl(): Promise<string> {
  if (cachedTerminalUrl) return cachedTerminalUrl;
  try {
    const response = await fetch('webquid.config.json', { cache: 'no-store' });
    if (response.ok) {
      const data = (await response.json()) as { terminalUrl?: unknown };
      if (
        typeof data.terminalUrl === 'string' &&
        /^https?:\/\/\S+$/.test(data.terminalUrl.trim())
      ) {
        cachedTerminalUrl = data.terminalUrl.trim();
      }
    }
  } catch {
    // missing or malformed config — fall through to the default
  }
  return cachedTerminalUrl ?? DEFAULT_TERMINAL_URL;
}

/** Resolve the player's WebQuid identity — or null when no real wallet exists. */
export function resolveWebquidIdentity(): { key: Hex; source: WebquidIdentitySource } | null {
  // A sparring key is an explicit per-tab choice, so it wins over the shared
  // wallet — that's the whole point of local two-tab duels.
  const sparring = loadTabSparringKey();
  if (sparring) return { key: sparring, source: 'sparring' };
  const imported = loadImportedKey();
  if (imported) return { key: imported, source: 'imported' };
  const platform = findPlatformWalletKey();
  if (platform) return { key: platform, source: 'platform' };
  return null;
}
