// ─────────────────────────────────────────────────────────────────────────────
// WQD off-chain ledger — a hash-chained, fully signed, tamper-evident log.
// CREDIT events carry an issuer-signed WebQuid attestation; BURN events are
// signed by the player's wallet and chained to the previous event hash, so a
// peer can replay the entire log and prove every WQD was legitimately held.
// ─────────────────────────────────────────────────────────────────────────────

import type { Hex } from 'viem';
import type { PowerUpKind } from '../types';
import { POWER_UP_COST } from '../types';
import { hashPayload, randomBytes32, recoverPayloadSigner, signPayload, type MessageSigner } from './crypto';
import { verifyCredit, type SignedCredit } from './webquid';
import {
  WQD_BASE,
  ethAddressFromPubkey,
  verifyBalanceProof,
  verifyDepositProof,
  type BalanceProof,
  type DepositProof,
} from './wqdchain';

export const LEDGER_GENESIS: Hex = `0x${'00'.repeat(32)}` as Hex;

export interface LedgerEvent {
  index: number;
  kind: 'CREDIT' | 'BURN';
  amount: number;
  /** 'WEBQUID_SYNC' | 'DEMO_FAUCET' | `PURCHASE:${PowerUpKind}` | 'QUANTUM_LOCK' */
  reason: string;
  /** Credit nonce or random burn id — replay protection across the log. */
  refId: string;
  matchId: string | null;
  prevHash: Hex;
  hash: Hex;
  at: number;
  signer: string;
  signature: Hex;
  /** Embedded issuer attestation — only present on CREDIT events. */
  credit?: SignedCredit;
  /** Embedded on-chain burn proof — only present on CREDIT (WQD_DEPOSIT) events. */
  deposit?: DepositProof;
  /** Embedded signed balance claim — only present on CREDIT (WQD_BALANCE) events. */
  balance?: BalanceProof;
}

export type Inventory = Record<PowerUpKind, number>;

export interface LedgerView {
  balance: number;
  inventory: Inventory;
  ok: boolean;
  error: string | null;
}

export const emptyInventory = (): Inventory => ({
  QUANTUM_HACK: 0,
  NEON_SHIELD: 0,
  TIME_DILATION: 0,
  QUANTUM_ENTANGLE: 0,
});

/** Fields bound by a player's burn signature (everything except hash/signature/credit blob). */
const burnBody = (e: LedgerEvent) => ({
  index: e.index,
  kind: e.kind,
  amount: e.amount,
  reason: e.reason,
  refId: e.refId,
  matchId: e.matchId,
  prevHash: e.prevHash,
  at: e.at,
});

/** Event hash covers the full record, binding the signature and any credit blob. */
export const eventHash = (event: Omit<LedgerEvent, 'hash'>): Hex => hashPayload(event);

const fail = (error: string): LedgerView => ({
  balance: 0,
  inventory: emptyInventory(),
  ok: false,
  error,
});

/**
 * Recompute the full chain. Any tampering, overspend, forged issuer or broken
 * link fails loudly — this runs on BOTH peers for BOTH players' ledgers.
 * `uses` is the per-match count of activated consumables (transmitted as signed
 * protocol messages), subtracted from purchased inventory during derivation.
 */
export async function validateLedger(
  events: LedgerEvent[],
  owner: string,
  uses: Inventory,
): Promise<LedgerView> {
  const inventory = emptyInventory();
  let balance = 0;
  let prev: Hex = LEDGER_GENESIS;
  const seenRefs = new Set<string>();
  const ownerLc = owner.toLowerCase();
  // Running mirror state: WQD_BALANCE events are DELTAS over the claimed
  // on-chain balance, so each coin can be mirrored exactly once and the claim
  // height must move strictly forward.
  let mirrorTotal = 0;
  let lastMirrorHeight = -1;

  for (let i = 0; i < events.length; i += 1) {
    const e = events[i];
    if (e.index !== i) return fail(`ledger index gap at ${i}`);
    if (e.prevHash !== prev) return fail(`broken hash chain at event ${i}`);
    const { hash, ...rest } = e;
    if (hash !== eventHash(rest)) return fail(`hash mismatch at event ${i}`);
    if (typeof e.amount !== 'number' || !Number.isFinite(e.amount) || e.amount <= 0) {
      return fail(`bad amount at event ${i}`);
    }
    // WQD precision matches the chain: integer base units (1e8 per WQD).
    const scaled = e.amount * WQD_BASE;
    if (Math.abs(Math.round(scaled) - scaled) > 1e-3) {
      return fail(`sub-unit amount at event ${i}`);
    }
    if (seenRefs.has(e.refId)) return fail(`replay of refId at event ${i}`);
    seenRefs.add(e.refId);

    if (e.kind === 'CREDIT') {
      if (e.balance) {
        // Balance mirror: a wallet-signed claim of the on-chain balance at a
        // height; the credit is the DELTA over previously mirrored claims.
        // The chain-truth half (does the claim match the replayed balance?)
        // is enforced asynchronously by each peer's full-node watcher.
        const p = e.balance;
        if (e.reason !== 'WQD_BALANCE') return fail(`balance event ${i} bad reason`);
        if (!verifyBalanceProof(p)) return fail(`balance event ${i}: forged balance proof`);
        if (ethAddressFromPubkey(p.pubkey) !== ownerLc) {
          return fail(`balance ${i} belongs to another wallet`);
        }
        if (e.refId !== `bal:${p.wqdAddress}:${p.height}`) return fail(`balance ${i} refId mismatch`);
        if (p.height <= lastMirrorHeight) return fail(`balance ${i} height not increasing`);
        if (Math.round(e.amount * WQD_BASE) !== p.balance - mirrorTotal) {
          return fail(`balance ${i} is not the claim delta`);
        }
        mirrorTotal = p.balance;
        lastMirrorHeight = p.height;
      } else if (e.deposit) {
        // On-chain deposit: a sender-signed burn to the zero sink, proven by
        // block inclusion + PoW + a confirmation chain. Fully deterministic.
        if (e.reason !== 'WQD_DEPOSIT') return fail(`deposit event ${i} bad reason`);
        const verdict = verifyDepositProof(e.deposit);
        if (!verdict.ok) return fail(`deposit event ${i}: ${verdict.error}`);
        if (ethAddressFromPubkey(e.deposit.tx.pubkey) !== ownerLc) {
          return fail(`deposit ${i} belongs to another wallet`);
        }
        if (e.refId !== e.deposit.txid) return fail(`deposit ${i} refId/txid mismatch`);
        if (Math.round(e.amount * WQD_BASE) !== e.deposit.tx.amount) {
          return fail(`deposit ${i} amount mismatch`);
        }
      } else {
        if (!e.credit) return fail(`credit event ${i} missing attestation`);
        if (!(await verifyCredit(e.credit))) return fail(`forged issuer at event ${i}`);
        if (e.credit.credit.to !== ownerLc) return fail(`credit ${i} belongs to another wallet`);
        if (e.credit.credit.nonce !== e.refId) return fail(`credit ${i} nonce/refId mismatch`);
        if (e.credit.credit.amount !== e.amount) return fail(`credit ${i} amount mismatch`);
      }
      balance += e.amount;
    } else {
      try {
        const signer = await recoverPayloadSigner(burnBody(e), e.signature);
        if (signer !== ownerLc || e.signer.toLowerCase() !== ownerLc) {
          return fail(`burn ${i} not signed by ledger owner`);
        }
      } catch {
        return fail(`burn ${i} has a malformed signature`);
      }
      balance -= e.amount;
      // epsilon: sums of tenth-WQD floats can land a hair below zero
      if (balance < -1e-9) return fail(`overspend at event ${i}`);
      if (e.reason.startsWith('PURCHASE:')) {
        const kind = e.reason.slice('PURCHASE:'.length) as PowerUpKind;
        if (!(kind in POWER_UP_COST)) return fail(`unknown power-up at event ${i}`);
        if (e.amount !== POWER_UP_COST[kind]) return fail(`wrong price paid at event ${i}`);
        inventory[kind] += 1;
      }
    }
    prev = e.hash;
  }

  // Fold in declared per-match activations; inventory must never go negative.
  (Object.keys(uses) as PowerUpKind[]).forEach((kind) => {
    inventory[kind] -= uses[kind];
  });
  for (const kind of Object.keys(inventory) as PowerUpKind[]) {
    if (inventory[kind] < 0) return fail(`inventory underflow on ${kind}`);
  }

  return { balance, inventory, ok: true, error: null };
}

/** Append a signed BURN to the local log. Throws when the spend is unaffordable. */
export async function buildBurnEvent(params: {
  events: LedgerEvent[];
  owner: string;
  signer: MessageSigner;
  amount: number;
  reason: string;
  matchId?: string | null;
}): Promise<LedgerEvent> {
  const { events, owner, signer, amount, reason } = params;
  const prevHash = events.length > 0 ? events[events.length - 1].hash : LEDGER_GENESIS;
  const draft: LedgerEvent = {
    index: events.length,
    kind: 'BURN',
    amount,
    reason,
    refId: randomBytes32(),
    matchId: params.matchId ?? null,
    prevHash,
    hash: LEDGER_GENESIS, // placeholder, replaced below
    at: Date.now(),
    signer: owner.toLowerCase(),
    signature: '0x' as Hex,
  };
  const signature = await signPayload(signer, burnBody(draft));
  const signed: LedgerEvent = { ...draft, signature };
  const { hash: _drop, ...rest } = signed;
  return { ...signed, hash: eventHash(rest) };
}

/**
 * Append a CREDIT for a confirmed on-chain deposit. Deterministic: every field
 * derives from the chain data, so any peer can validate it byte-for-byte.
 */
export function buildDepositEvent(params: {
  events: LedgerEvent[];
  owner: string; // eth-style address of the ledger owner
  proof: DepositProof;
}): LedgerEvent {
  const { events, owner, proof } = params;
  const prevHash = events.length > 0 ? events[events.length - 1].hash : LEDGER_GENESIS;
  const draft: Omit<LedgerEvent, 'hash'> = {
    index: events.length,
    kind: 'CREDIT',
    amount: proof.tx.amount / WQD_BASE,
    reason: 'WQD_DEPOSIT',
    refId: proof.txid,
    matchId: null,
    prevHash,
    at: proof.block.timestamp * 1000,
    signer: owner.toLowerCase(),
    signature: `0x${proof.tx.signature}` as Hex, // the sender's on-chain Schnorr proof
    deposit: proof,
  };
  return { ...draft, hash: eventHash(draft) };
}

/**
 * Append a CREDIT mirroring on-chain balance growth. `amount` is the delta
 * (in WQD) between the claimed chain balance and everything mirrored before —
 * the coins themselves never move.
 */
export function buildBalanceEvent(params: {
  events: LedgerEvent[];
  owner: string; // eth-style address of the ledger owner
  proof: BalanceProof;
  /** delta credit in WQD (must equal (proof.balance − mirrored total) / 1e8) */
  amount: number;
}): LedgerEvent {
  const { events, owner, proof, amount } = params;
  const prevHash = events.length > 0 ? events[events.length - 1].hash : LEDGER_GENESIS;
  const draft: Omit<LedgerEvent, 'hash'> = {
    index: events.length,
    kind: 'CREDIT',
    amount,
    reason: 'WQD_BALANCE',
    refId: `bal:${proof.wqdAddress}:${proof.height}`,
    matchId: null,
    prevHash,
    at: Date.now(),
    signer: owner.toLowerCase(),
    signature: `0x${proof.signature}` as Hex,
    balance: proof,
  };
  return { ...draft, hash: eventHash(draft) };
}

/**
 * Re-anchor a ledger whose mirror claims were inflated by a historical build.
 * Every WQD_BALANCE event is dropped (claims are re-issued from chain truth by
 * the caller's fresh `anchorClaim`, parked at index 0), platform credits and
 * deposits are re-linked unchanged, and burns are re-signed by the owner at
 * their new positions (burn signatures bind index+prevHash). The result passes
 * validateLedger under the same rules the opponent applies.
 */
export async function rebaseLedger(params: {
  events: LedgerEvent[];
  owner: string;
  signer: MessageSigner;
  anchorClaim: LedgerEvent; // built via buildBalanceEvent against an empty log
}): Promise<LedgerEvent[]> {
  const { events, owner, signer, anchorClaim } = params;
  const out: LedgerEvent[] = [anchorClaim];
  for (const e of events) {
    if (e.reason === 'WQD_BALANCE' && e.balance) continue; // stale mirror claim
    if (e.kind === 'CREDIT') {
      const { hash: _stale, ...rest } = e;
      const draft: Omit<LedgerEvent, 'hash'> = {
        ...rest,
        index: out.length,
        prevHash: out[out.length - 1].hash,
      };
      out.push({ ...draft, hash: eventHash(draft) });
    } else {
      out.push(
        await buildBurnEvent({
          events: out,
          owner,
          signer,
          amount: e.amount,
          reason: e.reason,
          matchId: e.matchId,
        }),
      );
    }
  }
  return out;
}

/** Append a CREDIT carrying a verified WebQuid attestation. */
export async function buildCreditEvent(params: {
  events: LedgerEvent[];
  credit: SignedCredit;
}): Promise<LedgerEvent | null> {
  const { events, credit } = params;
  if (!(await verifyCredit(credit))) return null;
  const prevHash = events.length > 0 ? events[events.length - 1].hash : LEDGER_GENESIS;
  const draft: Omit<LedgerEvent, 'hash'> = {
    index: events.length,
    kind: 'CREDIT',
    amount: credit.credit.amount,
    reason: credit.credit.source === 'DEMO_FAUCET' ? 'DEMO_FAUCET' : 'WEBQUID_SYNC',
    refId: credit.credit.nonce,
    matchId: null,
    prevHash,
    at: Date.now(),
    signer: credit.signer,
    signature: credit.signature,
    credit,
  };
  return { ...draft, hash: eventHash(draft) };
}
