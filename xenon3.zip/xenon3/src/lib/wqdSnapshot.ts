// ─────────────────────────────────────────────────────────────────────────────
// wqdSnapshot — IndexedDB persistence for the watcher's verified chain state.
//
// Without it every page load replays the whole mainnet from genesis (thousands
// of ECDSA checks on the main thread — the "desktop feels slow" culprit).
// With it the watcher resumes from its last verified tip and only syncs the
// delta. Blocks are kept COMPLETE (not just a tail) so historical
// balanceOfAt() audits and block serving to peers keep working.
//
// Trust model: this is the player's OWN browser storage — the same trust
// domain as the local ledger. A player editing their snapshot can only fool
// their own mirror; the peer's watcher audits claims against ITS OWN chain
// view, so overclaims still fail remotely. Integrity checks below guard
// against corruption (truncated writes, stale schema), not against the
// device owner — that threat model is unchanged from localStorage.
// ─────────────────────────────────────────────

import type { WqdBlock } from './wqdchain';
import { blockHashPreimage, hashD } from './wqdchain';

export interface WqdSnapshotV1 {
  v: 1;
  savedAt: number;
  height: number;
  tipHash: string;
  /** Every block from height 1 to tip, in order. */
  blocks: WqdBlock[];
  /** Address → base units (decimal string; bigint is structured-clone safe but strings are universal). */
  balances: [string, string][];
  nonces: [string, number][];
}

const DB_NAME = 'xenon3-wqd';
const DB_VERSION = 1;
const STORE = 'chain';
const KEY = 'snapshot:v1';

function openDb(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    let req: IDBOpenDBRequest;
    try {
      req = window.indexedDB.open(DB_NAME, DB_VERSION);
    } catch {
      resolve(null); // private mode / blocked storage — run without persistence
      return;
    }
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve(null);
    req.onblocked = () => resolve(null);
  });
}

/** Persist the snapshot (fire-and-forget safe — never throws). */
export async function saveSnapshot(snap: WqdSnapshotV1): Promise<void> {
  try {
    const db = await openDb();
    if (!db) return;
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(snap, KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
      tx.onabort = () => resolve();
    });
    db.close();
  } catch {
    // quota / serialization — persistence is best-effort, never fatal
  }
}

/** Header recompute — cheap corruption tripwire (sha256 only, no ECDSA). */
const headerHash = (b: WqdBlock): string => hashD(blockHashPreimage(b));

/** Load + integrity-check the snapshot. Any doubt → null (clean resync). */
export async function loadSnapshot(): Promise<WqdSnapshotV1 | null> {
  try {
    const db = await openDb();
    if (!db) return null;
    const raw = await new Promise<unknown>((resolve) => {
      const tx = db.transaction(STORE, 'readonly');
      const req = tx.objectStore(STORE).get(KEY);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    });
    db.close();
    const snap = raw as WqdSnapshotV1 | null;
    if (!snap || snap.v !== 1 || !Array.isArray(snap.blocks)) return null;
    if (!Number.isInteger(snap.height) || snap.height < 1) return null;
    if (snap.blocks.length !== snap.height) return null;

    // Structure: sequential heights, hash-linked, tip matches the header.
    let prevHash = '';
    for (let i = 0; i < snap.blocks.length; i += 1) {
      const b = snap.blocks[i];
      if (!b || b.height !== i + 1) return null;
      if (i > 0 && b.prevHash !== prevHash) return null;
      prevHash = b.hash;
    }
    if (prevHash !== snap.tipHash) return null;

    // Sampled recompute: tip + 31 deterministic mid-chain points. A truncated
    // or torn write trips this instantly; honest snapshots pass in ~1ms.
    const samples = new Set<number>([snap.blocks.length - 1]);
    for (let k = 1; k <= 31; k += 1) {
      samples.add(Math.floor((k * (snap.blocks.length - 1)) / 32));
    }
    for (const idx of samples) {
      const b = snap.blocks[idx];
      if (!b || headerHash(b) !== b.hash) return null;
    }
    return snap;
  } catch {
    return null;
  }
}

/** Drop the snapshot (schema migrations, explicit resets). */
export async function clearSnapshot(): Promise<void> {
  try {
    const db = await openDb();
    if (!db) return;
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
    db.close();
  } catch {
    // best-effort
  }
}
