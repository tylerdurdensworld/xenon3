// ─────────────────────────────────────────────────────────────────────────────
// wqdMqtt — the WebQuid MQTT presence room, ported from the terminal's own
// transport (src/node/mqtt.ts in the published WebQuid source).
//
// Why this exists: the live terminal fleet meets on TWO public MQTT brokers
// (wss://broker.emqx.io:8084/mqtt, wss://broker.hivemq.com:8884/mqtt) — the
// zero-config meeting point that works even where browser-to-browser WebRTC
// cannot pass (carrier NAT, UDP filters). The PeerJS lobby, by contrast, can
// hold frozen background tabs whose signaling identity outlives their JS
// (field diagnostics: a slot answers the WebRTC handshake yet stays silent
// forever). Joining the MQTT room puts the watcher on the SAME transport the
// mining terminals actually use.
//
// Wire model (identical semantics to the terminal):
//   topics   wqd/<chain-id>/lobby     presence announces, every ~15s
//            wqd/<chain-id>/in/<id>   per-peer inbox for engine frames
//   ids      m-<hex12>, announced as {v:1,t:"hi",id,h,th}
//   frames   {v:1,t:"m",from,to,d,n} — d is the wire JSON (hello, challenge,
//            getBlocks, blocks, …), n a dedupe nonce (each frame is fanned
//            out to EVERY ready broker, so receivers dedupe by from:n)
//   links    roster presence IS the link set — dial() is a no-op by design
//
// Trust model (unchanged from the terminal): brokers see only already-signed
// public chain frames; every frame is validated by the receiving node. A
// broker is a liveness dependency, never an integrity one.
// ─────────────────────────────────────────────────────────────────────────────

// ── Mini MQTT 3.1.1 client (QoS0 over WebSocket) ────────────────────────────
// Hand-rolled (~150 lines) so the runtime dependency count stays at zero:
// CONNECT, SUBSCRIBE, PUBLISH QoS0, PINGREQ — everything a presence room needs.

const te = new TextEncoder();
const td = new TextDecoder();

const utf8 = (s: string): Uint8Array => te.encode(s);

/** MQTT UTF-8 string: two-byte length prefix + bytes. */
function str(s: string): Uint8Array {
  const b = utf8(s);
  const out = new Uint8Array(2 + b.length);
  out[0] = b.length >> 8;
  out[1] = b.length & 255;
  out.set(b, 2);
  return out;
}

/** MQTT "remaining length" varint (1-4 bytes). */
function remainingLen(n: number): Uint8Array {
  const out: number[] = [];
  do {
    let d = n % 128;
    n = Math.floor(n / 128);
    if (n > 0) d |= 0x80;
    out.push(d);
  } while (n > 0);
  return Uint8Array.from(out);
}

function concat(...parts: Uint8Array[]): Uint8Array {
  const n = parts.reduce((a, p) => a + p.length, 0);
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

function packet(type: number, flags: number, body: Uint8Array): Uint8Array {
  const rl = remainingLen(body.length);
  const out = new Uint8Array(1 + rl.length + body.length);
  out[0] = (type << 4) | flags;
  out.set(rl, 1);
  out.set(body, 1 + rl.length);
  return out;
}

const PT = {
  CONNECT: 1,
  CONNACK: 2,
  PUBLISH: 3,
  SUBSCRIBE: 8,
  SUBACK: 9,
  PINGREQ: 12,
  DISCONNECT: 14,
} as const;

/** Hard cap on one MQTT packet: anything bigger is rogue — drop the socket. */
const MAX_PACKET_BYTES = 1024 * 1024;

interface DecodedPacket {
  type: number;
  flags: number;
  body: Uint8Array;
}

/** Incremental parser: WebSocket frames may split or join MQTT packets. */
class PacketParser {
  private buf: Uint8Array = new Uint8Array(0);

  push(chunk: Uint8Array): DecodedPacket[] {
    this.buf = concat(this.buf, chunk);
    const out: DecodedPacket[] = [];
    for (;;) {
      if (this.buf.length < 2) break;
      let rl = 0;
      let mult = 1;
      let varintBytes = 0;
      let done = false;
      for (let i = 1; i < this.buf.length && i <= 4; i += 1) {
        const d = this.buf[i];
        rl += (d & 127) * mult;
        mult *= 128;
        varintBytes = i;
        if ((d & 128) === 0) {
          done = true;
          break;
        }
      }
      if (!done) break; // incomplete varint — wait for more bytes
      if (rl > MAX_PACKET_BYTES) throw new Error('mqtt packet exceeds cap');
      const headerLen = 1 + varintBytes;
      if (this.buf.length < headerLen + rl) break; // body not fully here yet
      out.push({ type: this.buf[0] >> 4, flags: this.buf[0] & 15, body: this.buf.subarray(headerLen, headerLen + rl) });
      this.buf = this.buf.subarray(headerLen + rl);
    }
    return out;
  }
}

interface MiniMqttEvents {
  /** CONNACK accepted: the session is live — subscribe now, publish after. */
  onConnect(): void;
  /** Subscriptions confirmed — safe to publish/expect traffic. */
  onReady(): void;
  onMessage(topic: string, payload: Uint8Array): void;
  /** Socket ended (any reason) — the owner decides retry. Fires exactly once. */
  onClose(): void;
}

/**
 * One MQTT-over-WebSocket session. Never throws, never retries by itself
 * (the room owns the reconnect ladder); onClose always fires exactly once
 * per connect attempt. Exported (like the terminal's own client) so tests
 * and tooling can speak the exact same wire protocol.
 */
export class MiniMqttClient {
  readonly url: string;
  private readonly clientId: string;
  private readonly keepAliveSec: number;
  private readonly connectTimeoutMs: number;
  private readonly events: MiniMqttEvents;
  private socket: WebSocket | null = null;
  private parser = new PacketParser();
  private ready = false;
  private closedNotified = false;
  private userStop = false;
  private pingTimer: number | null = null;
  private lastRx = 0;
  private nextPacketId = 1;
  /** packetId → resolve(); SUBACKs we still wait for before "ready". */
  private readonly pendingSubs = new Map<number, () => void>();

  constructor(url: string, clientId: string, events: MiniMqttEvents, keepAliveSec = 30, connectTimeoutMs = 8_000) {
    this.url = url;
    this.clientId = clientId;
    this.keepAliveSec = keepAliveSec;
    this.connectTimeoutMs = connectTimeoutMs;
    this.events = events;
  }

  isReady(): boolean {
    return this.ready;
  }

  connect(): void {
    if (this.userStop) return;
    this.ready = false;
    this.closedNotified = false;
    this.parser = new PacketParser();
    let ws: WebSocket;
    try {
      ws = new WebSocket(this.url, 'mqtt');
      ws.binaryType = 'arraybuffer';
    } catch {
      this.notifyClose();
      return;
    }
    this.socket = ws;
    const connectTimer = window.setTimeout(() => {
      try {
        ws.close();
      } catch {
        /* never opened */
      }
    }, this.connectTimeoutMs);

    ws.addEventListener('open', () => {
      this.lastRx = Date.now();
      const keep = this.keepAliveSec;
      const body = concat(
        str('MQTT'),
        Uint8Array.from([4, 0x02, keep >> 8, keep & 255]), // v3.1.1, clean session
        str(this.clientId),
      );
      try {
        ws.send(packet(PT.CONNECT, 0, body));
      } catch {
        /* closing */
      }
    });
    ws.addEventListener('message', (e: MessageEvent) => {
      if (!(e.data instanceof ArrayBuffer)) return;
      this.lastRx = Date.now();
      let packets: DecodedPacket[];
      try {
        packets = this.parser.push(new Uint8Array(e.data));
      } catch {
        try {
          ws.close();
        } catch {
          /* already gone */
        }
        return;
      }
      for (const p of packets) this.handlePacket(p, ws, connectTimer);
    });
    ws.addEventListener('close', () => {
      window.clearTimeout(connectTimer);
      this.cleanup();
      this.notifyClose();
    });
    ws.addEventListener('error', () => {
      // the close event that follows owns the state transition
    });
  }

  private handlePacket(p: DecodedPacket, ws: WebSocket, connectTimer: number): void {
    switch (p.type) {
      case PT.CONNACK: {
        window.clearTimeout(connectTimer);
        if (p.body.length < 2 || p.body[1] !== 0) {
          try {
            ws.close();
          } catch {
            /* refused */
          }
          return;
        }
        this.armPing();
        this.events.onConnect();
        break;
      }
      case PT.SUBACK: {
        if (p.body.length < 2) return;
        const pid = (p.body[0] << 8) | p.body[1];
        const resolve = this.pendingSubs.get(pid);
        if (resolve) {
          this.pendingSubs.delete(pid);
          resolve();
        }
        break;
      }
      case PT.PUBLISH: {
        // QoS0 only (we subscribe QoS0, so brokers downgrade for us); if a
        // broker still sends QoS1, skip the 2-byte packet id — we never PUBACK,
        // worst case the broker redelivers and the room's dedupe eats it.
        if (p.body.length < 2) return;
        const tlen = (p.body[0] << 8) | p.body[1];
        const qos = (p.flags >> 1) & 3;
        const off = 2 + tlen + (qos > 0 ? 2 : 0);
        if (p.body.length < off) return;
        this.events.onMessage(td.decode(p.body.subarray(2, 2 + tlen)), p.body.subarray(off));
        break;
      }
      default:
        break; // PINGRESP / PUBACK etc. — lastRx already updated, nothing to do
    }
  }

  private armPing(): void {
    if (this.pingTimer !== null) window.clearInterval(this.pingTimer);
    const ms = this.keepAliveSec * 1000;
    this.pingTimer = window.setInterval(() => {
      const ws = this.socket;
      if (!ws) return;
      // Half-open mobile socket detector: no bytes for 1.5 keepalives and we
      // bury it ourselves instead of waiting for the OS to notice.
      if (Date.now() - this.lastRx > ms * 1.5) {
        try {
          ws.close();
        } catch {
          /* already gone */
        }
        return;
      }
      try {
        ws.send(packet(PT.PINGREQ, 0, new Uint8Array(0)));
      } catch {
        /* closing */
      }
    }, ms);
  }

  /** Subscribe and resolve once ALL SUBACKs are in (or the socket dies). */
  subscribeAll(topics: string[]): Promise<void> {
    const ws = this.socket;
    if (!ws) return Promise.resolve();
    const ids: number[] = [];
    const frames: Uint8Array[] = [];
    for (const t of topics) {
      const pid = (this.nextPacketId += 1) & 0xffff || 1;
      ids.push(pid);
      frames.push(packet(PT.SUBSCRIBE, 0x2, concat(Uint8Array.from([pid >> 8, pid & 255]), str(t), Uint8Array.from([0]))));
    }
    const waits = ids.map(
      (pid) =>
        new Promise<void>((resolve) => {
          this.pendingSubs.set(pid, resolve);
        }),
    );
    try {
      for (const f of frames) ws.send(f); // one SUBSCRIBE packet per topic
    } catch {
      /* closing — close event resolves everything */
    }
    return Promise.all(waits).then(() => undefined);
  }

  /** Mark the session usable: called once CONNACK landed and subs acked. */
  markReady(): void {
    if (this.userStop) return;
    this.ready = true;
    this.events.onReady();
  }

  publish(topic: string, payload: Uint8Array): void {
    const ws = this.socket;
    if (!ws || !this.ready) return;
    try {
      ws.send(packet(PT.PUBLISH, 0, concat(str(topic), payload)));
    } catch {
      /* socket racing a close */
    }
  }

  private cleanup(): void {
    if (this.pingTimer !== null) window.clearInterval(this.pingTimer);
    this.pingTimer = null;
    this.socket = null;
    this.ready = false;
    // wake any subscribeAll waiters so nothing dangles across a reconnect
    const pending = [...this.pendingSubs.values()];
    this.pendingSubs.clear();
    for (const resolve of pending) resolve();
  }

  private notifyClose(): void {
    if (this.closedNotified) return;
    this.closedNotified = true;
    this.events.onClose();
  }

  stop(): void {
    this.userStop = true;
    const ws = this.socket;
    try {
      if (ws && this.ready) ws.send(packet(PT.DISCONNECT, 0, new Uint8Array(0)));
    } catch {
      /* closing */
    }
    try {
      ws?.close();
    } catch {
      /* already gone */
    }
    this.cleanup();
  }
}

// ── Presence room over the public brokers ────────────────────────────────────

/** Engine frames are small JSON strings; 768KB leaves absurd headroom. */
const MAX_PAYLOAD_BYTES = 768 * 1024;
/** Inbound dedupe window (the same frame arrives via several brokers). */
const DEDUPE_CAP = 512;
const ID_RE = /^m-[0-9a-f]{12}$/;

const ANNOUNCE_MS = 15_000; // presence cadence (jittered ±25%)
const ROSTER_TTL_MS = 45_000; // silent peers are forgotten after this
const SWEEP_MS = 5_000;
const MAX_LINKS = 24;
const ROSTER_CAP = 256;
const RECONNECT_LADDER_MS = [3_000, 8_000, 20_000, 60_000, 120_000];

interface RosterEntry {
  lastSeen: number;
  linked: boolean;
}

interface BrokerConn {
  client: MiniMqttClient;
  ready: boolean;
  step: number;
  timer: number | null;
}

export interface MqttRoomEvents {
  /** A roster member surfaced as a link (or re-surfaced after tombstoning). */
  onOpen(id: string): void;
  /** A linked peer went silent past the roster TTL. */
  onClose(id: string): void;
  /** An engine frame (wire JSON string) from a linked peer. */
  onMessage(id: string, data: string): void;
  /** Advisory tip metadata from a presence announce. */
  onPeerTip(id: string, height: number, tipHashPrefix: string | null): void;
  /** Human-readable room event for the on-screen diagnostics panel. */
  onDiag(msg: string): void;
}

const randomMqttId = (): string =>
  `m-${[...crypto.getRandomValues(new Uint8Array(6))].map((b) => b.toString(16).padStart(2, '0')).join('')}`;

/**
 * The zero-config meeting point: subscribe the same lobby + our inbox on
 * every configured broker, announce presence on a jittered cadence, and
 * surface roster members as links. Faithful to the terminal's transport so
 * the two interoperate frame-for-frame.
 */
export class MqttRoom {
  readonly selfId: string = randomMqttId();
  private readonly urls: readonly string[];
  private readonly lobbyTopic: string;
  private readonly inboxPrefix: string;
  private readonly events: MqttRoomEvents;
  private brokers: BrokerConn[] = [];
  private readonly roster = new Map<string, RosterEntry>();
  private readonly seen = new Set<string>();
  private readonly seenQueue: string[] = [];
  private announceTimer: number | null = null;
  private sweepTimer: number | null = null;
  private announcedTip: { height: number; hash: string } | null = null;
  private stopped = false;
  /** Broker short-name → ready state, for one concise diagnostics line. */
  private readonly readyLog = new Map<string, boolean>();

  constructor(urls: readonly string[], chainId: string, events: MqttRoomEvents) {
    this.urls = urls;
    this.lobbyTopic = `wqd/${chainId}/lobby`;
    this.inboxPrefix = `wqd/${chainId}/in/`;
    this.events = events;
  }

  /** Fresh tip for presence announces — peers behind us re-sync off it. */
  setAnnouncedTip(tip: { height: number; hash: string }): void {
    this.announcedTip = tip;
  }

  start(): void {
    if (this.stopped || this.brokers.length > 0 || this.urls.length === 0) return;
    for (const url of this.urls) {
      const broker: BrokerConn = {
        client: this.makeClient(url, () => broker),
        ready: false,
        step: 0,
        timer: null,
      };
      this.brokers.push(broker);
      broker.client.connect();
    }
    this.scheduleAnnounce();
    this.sweepTimer = window.setInterval(() => this.sweep(), SWEEP_MS);
  }

  stop(): void {
    this.stopped = true;
    if (this.announceTimer !== null) window.clearTimeout(this.announceTimer);
    if (this.sweepTimer !== null) window.clearInterval(this.sweepTimer);
    this.announceTimer = null;
    this.sweepTimer = null;
    for (const b of this.brokers) {
      if (b.timer !== null) window.clearTimeout(b.timer);
      b.client.stop();
    }
    this.brokers = [];
    this.roster.clear();
  }

  /** Number of brokers currently ready (diag + send fan-out). */
  readyCount(): number {
    return this.brokers.filter((b) => b.ready).length;
  }

  isLinked(id: string): boolean {
    return this.roster.get(id)?.linked === true;
  }

  /** Fan a frame out to EVERY ready broker — QoS0 queues nothing, and one
   *  shared broker is all two nodes can ever count on. Same nonce on every
   *  copy: the receiver's dedupe collapses them to exactly one delivery. */
  send(peerId: string, data: string): void {
    if (!this.roster.get(peerId)?.linked) return;
    const ready = this.brokers.filter((b) => b.ready);
    if (ready.length === 0) return;
    const nonce = [...crypto.getRandomValues(new Uint8Array(6))].map((x) => x.toString(16).padStart(2, '0')).join('');
    const payload = utf8(JSON.stringify({ v: 1, t: 'm', from: this.selfId, to: peerId, d: data, n: nonce }));
    for (const b of ready) b.client.publish(`${this.inboxPrefix}${peerId}`, payload);
  }

  private makeClient(url: string, getBroker: () => BrokerConn): MiniMqttClient {
    const clientId = `wqd-${this.selfId}-${Math.floor(Math.random() * 1e6)}`;
    return new MiniMqttClient(url, clientId, {
      onConnect: () => {
        const b = getBroker();
        void b.client
          .subscribeAll([this.lobbyTopic, `${this.inboxPrefix}${this.selfId}`])
          .then(() => b.client.markReady());
      },
      onReady: () => {
        if (this.stopped) return;
        const b = getBroker();
        b.ready = true;
        b.step = 0;
        const host = /^\wss?:\/\/([^/:]+)/.exec(url)?.[1] ?? url;
        if (!this.readyLog.get(host)) {
          this.readyLog.set(host, true);
          this.events.onDiag(`mqtt room joined via ${host} — id ${this.selfId}`);
        }
        this.announceOn(b);
      },
      onMessage: (topic, payload) => this.handleMqtt(topic, payload),
      onClose: () => {
        const b = getBroker();
        b.ready = false;
        this.scheduleReconnect(b);
      },
    });
  }

  private scheduleReconnect(b: BrokerConn): void {
    if (this.stopped || b.timer !== null) return;
    const wait = RECONNECT_LADDER_MS[Math.min(b.step, RECONNECT_LADDER_MS.length - 1)];
    b.step += 1;
    b.timer = window.setTimeout(() => {
      b.timer = null;
      if (this.stopped) return;
      b.client = this.makeClient(b.client.url, () => b);
      b.client.connect();
    }, wait);
  }

  private scheduleAnnounce(): void {
    if (this.stopped) return;
    // jittered cadence: many tabs booting together must not thump the public
    // brokers in lockstep
    const jitter = 0.75 + Math.random() * 0.5;
    this.announceTimer = window.setTimeout(() => {
      this.announceTimer = null;
      for (const b of this.brokers) if (b.ready) this.announceOn(b);
      this.scheduleAnnounce();
    }, ANNOUNCE_MS * jitter);
  }

  private announceOn(b: BrokerConn): void {
    const m: Record<string, unknown> = { v: 1, t: 'hi', id: this.selfId };
    const tip = this.announcedTip;
    if (tip && Number.isInteger(tip.height) && tip.height >= 0) {
      m.h = tip.height;
      if (/^[0-9a-f]{64}$/.test(tip.hash)) m.th = tip.hash.slice(0, 12);
    }
    b.client.publish(this.lobbyTopic, utf8(JSON.stringify(m)));
  }

  private handleMqtt(topic: string, payload: Uint8Array): void {
    if (this.stopped) return;
    if (payload.length > MAX_PAYLOAD_BYTES) return;
    let m: Record<string, unknown>;
    try {
      m = JSON.parse(td.decode(payload)) as Record<string, unknown>;
    } catch {
      return;
    }
    if (!m || typeof m !== 'object' || m.v !== 1) return;
    if (topic === this.lobbyTopic) {
      // presence announce: {v:1,t:"hi",id,h?,th?}
      if (m.t !== 'hi' || typeof m.id !== 'string' || !ID_RE.test(m.id)) return;
      if (m.id === this.selfId) return; // brokers echo our own announce
      this.learn(m.id);
      const h = m.h;
      const height = typeof h === 'number' && Number.isInteger(h) && h >= 0 && h <= Number.MAX_SAFE_INTEGER ? h : null;
      const th = typeof m.th === 'string' && /^[0-9a-f]{1,64}$/.test(m.th) ? m.th : null;
      if (height !== null) this.events.onPeerTip(m.id, height, th);
      return;
    }
    if (topic === `${this.inboxPrefix}${this.selfId}`) {
      if (m.t !== 'm') return;
      const from = m.from;
      const to = m.to;
      const data = m.d;
      const nonce = m.n;
      if (typeof from !== 'string' || !ID_RE.test(from)) return;
      if (to !== this.selfId) return;
      if (typeof data !== 'string' || typeof nonce !== 'string' || nonce.length > 24) return;
      // the same frame reaches us once per broker — deliver it once
      const key = `${from}:${nonce}`;
      if (this.seen.has(key)) return;
      this.seen.add(key);
      this.seenQueue.push(key);
      if (this.seenQueue.length > DEDUPE_CAP) {
        const old = this.seenQueue.shift();
        if (old) this.seen.delete(old);
      }
      // Implicit presence: a well-formed frame from a valid id proves the
      // sender is in the room — learn it BEFORE the linked-check, or a
      // handshake frame that outruns the sender's first announce would be
      // lost and the link would die half-open. The watcher sends its hello
      // synchronously inside onOpen (mirroring the terminal's handleOpen),
      // so the link springs up exactly when the first frame arrives.
      this.learn(from);
      if (this.roster.get(from)?.linked === true) this.events.onMessage(from, data);
      return;
    }
  }

  /** Roster add/refresh: surface as a link while under the cap. */
  private learn(id: string): void {
    let entry = this.roster.get(id);
    if (!entry) {
      if (this.roster.size >= ROSTER_CAP) return;
      entry = { lastSeen: 0, linked: false };
      this.roster.set(id, entry);
    }
    entry.lastSeen = Date.now();
    if (entry.linked) return;
    let linkedCount = 0;
    for (const e of this.roster.values()) if (e.linked) linkedCount += 1;
    if (linkedCount >= MAX_LINKS) return;
    entry.linked = true;
    this.events.onOpen(id);
  }

  /** Roster drop: report the link's death, then promote a waiting member. */
  private unlearn(id: string): void {
    const entry = this.roster.get(id);
    if (!entry) return;
    this.roster.delete(id);
    if (!entry.linked) return;
    this.events.onClose(id);
    for (const [nextId, next] of this.roster) {
      if (next.linked) continue;
      let linkedCount = 0;
      for (const e of this.roster.values()) if (e.linked) linkedCount += 1;
      if (linkedCount >= MAX_LINKS) break;
      next.linked = true;
      this.events.onOpen(nextId);
    }
  }

  /** Presence tombstone sweep: silent peers are forgotten, links reported. */
  private sweep(): void {
    if (this.stopped) return;
    const now = Date.now();
    for (const [id, entry] of [...this.roster]) {
      if (now - entry.lastSeen > ROSTER_TTL_MS) this.unlearn(id);
    }
  }
}

/** Resolve the broker list: defaults + the ?mqtt= URL override (comma-
 *  separated), disabled entirely by ?nomqtt=1 — the terminal's own debug
 *  hatches, mirrored so either side can be isolated during a rescue. */
export function mqttUrlsFromRuntime(defaults: readonly string[]): string[] {
  const urls = [...defaults];
  if (typeof window !== 'undefined') {
    const params = new URLSearchParams(window.location.search);
    if (params.has('nomqtt')) return [];
    const extra = params.get('mqtt');
    if (extra) {
      const override = extra
        .split(',')
        .map((u) => u.trim())
        .filter((u) => /^wss?:\/\//.test(u));
      // An explicit override REPLACES the defaults: a test/rescue session
      // must not leak onto the public brokers.
      if (override.length > 0) return override;
    }
  }
  return urls;
}
