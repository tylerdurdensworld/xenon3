// ─────────────────────────────────────────────────────────────────────────────
// wqdWatcher — a read-only FULL NODE for the WebQuid mainnet P2P network.
//
// Why a full node: the terminal keeps its chain state in its own origin's
// IndexedDB, which no other site may read. So the game joins the same PeerJS
// network (namespace wqd-mainnet1), completes the hello/challenge handshake,
// and independently verifies the chain from the pinned genesis block:
//   • hash + PoW + merkle root + coinbase schedule on every block
//   • difficulty retarget sequence (every 8 blocks, 480s window, ×4 clamp)
//   • median-time-past timestamps, prevHash linkage back to genesis
//   • every transfer's ECDSA signature, nonce sequence, and balance sufficiency
// From that replayed state it derives trustless balances — so a player's real
// WQD shows up in-game WITHOUT the coins ever leaving their wallet.
// The opponent's client runs the same node, so both sides compute identical
// balances — no trust, no custodian, no transfers.
// ─────────────────────────────────────────────────────────────────────────────

import Peer, { type DataConnection } from 'peerjs';
import {
  WQD_BASE,
  WQD_CHAIN_ID,
  WQD_CHALLENGE_PREFIX,
  WQD_GENESIS_HASH,
  WQD_MIN_TX_FEE,
  WQD_PEER_NAMESPACE,
  WQD_P2P_VERSION,
  WQD_RETARGET_INTERVAL,
  hashD,
  blockCoinbase,
  blockTransfers,
  synthGenesis,
  verifyChainBlock,
  type WqdBlock,
} from './wqdchain';
import { MqttRoom, mqttUrlsFromRuntime } from './wqdMqtt';
import { loadSnapshot, saveSnapshot } from './wqdSnapshot';

/**
 * Link lifecycle, surfaced to the UI so a stuck "LINKING…" is diagnosable:
 *   starting     — no PeerJS identity yet (claiming a rendezvous slot)
 *   sweeping     — identity live, dialing the slot ring, no verified peer yet
 *   linked       — at least one verified mainnet peer
 *   broker-error — the PeerJS signaling cloud is unreachable/fatally failing;
 *                  the watcher keeps retrying with backoff, no silent death
 */
export type WatcherPhase = 'starting' | 'sweeping' | 'linked' | 'broker-error';

export interface WatcherSnapshot {
  peers: number;
  /** Verified chain height (full-node sync tip). */
  tipHeight: number;
  /** Tallest height advertised by verified peers (sync target). */
  bestKnown: number;
  tipTarget: string | null;
  /** The watched wallet's replayed on-chain balance, in WQD. */
  watchBalance: number;
  phase: WatcherPhase;
  /** PeerJS error type of the last fatal broker failure, if any. */
  lastError: string | null;
  // ── Diagnostics (rendered on-screen; phone users have no devtools) ──────
  /** Our claimed PeerJS identity, once live. */
  identity: string | null;
  /** Outbound dial attempts made (cumulative). */
  dialed: number;
  /** Outbound dials that reached an open channel. */
  answered: number;
  /** Inbound connections received (peers dialing our claimed slot). */
  inbound: number;
  /** Last few watcher events, oldest → newest. */
  diag: string[];
}

export interface WatcherCallbacks {
  onStatus: (snapshot: WatcherSnapshot) => void;
}

const PEER_HOST = '0.peerjs.com';
// Same ICE config as the terminal: public STUN + the openrelayproject TURN
// relays, without which browser-to-browser WebRTC dies behind most NATs.
const ICE_SERVERS = [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun.relay.metered.ca:80'] },
  { urls: 'turn:standard.relay.metered.ca:80', username: 'openrelayproject', credential: 'openrelayproject' },
  { urls: 'turn:standard.relay.metered.ca:443', username: 'openrelayproject', credential: 'openrelayproject' },
  { urls: 'turns:standard.relay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' },
];
const SLOT_COUNT = 64; // miner nodes claim any of the 64 rendezvous slots
const MIN_PEERS = 2;
const SYNC_BATCH = 16; // peers clamp getBlocks counts to 16 (protocol constant Ke)
const SYNC_STALL_MS = 8_000;
/** An unanswered getBlocks is retried through the NEXT verified peer… */
const SYNC_REQUEST_TIMEOUT_MS = 6_000;
/** …and a chronically silent peer is dropped so the ring replaces it. */
const SYNC_TIMEOUT_DROP = 3;
const MAX_ORPHANS = 512;
/** PeerJS peer-level errors that mean "the signaling cloud is failing", not
 *  "that one slot id is free/taken". 'peer-unavailable' is deliberately NOT
 *  here — it fires once per unanswered dial and is normal sweep noise. */
const FATAL_BROKER_ERRORS = new Set([
  'browser-incompatible',
  'network',
  'server-error',
  'socket-error',
  'socket-closed',
  'ssl-unavailable',
]);
const BROKER_RETRY_MS = 5_000; // first retry after a broker failure
const BROKER_RETRY_MAX_MS = 30_000; // escalated cap while flapping persists
const FLAP_HEALTHY_MS = 30_000; // a socket alive this long resets the backoff
/**
 * A dial to an OFFLINE slot never fails on the connection object — PeerJS
 * reports it on the peer ('peer-unavailable') and the conn hangs forever.
 * Without a timeout the dead conn stayed in `conns`, and every later sweep
 * skipped that slot: one unlucky first sweep meant "never connects, ever".
 */
const DIAL_TIMEOUT_MS = 8_000;
/**
 * Ring scanning is a TRICKLE, not a burst: ONE slot per tick. The old 8-wide
 * batch sweep fired ~40 signaling messages/second at the broker — on the
 * free PeerJS cloud that flood reliably got our own socket killed 1-2s after
 * every reconnect (field diagnostics showed exactly that rhythm, thousands
 * of dials deep: reconnect → sweep → failure → reconnect → sweep → failure).
 * The trickle covers all 64 slots in ~16s on the first pass, then idles at
 * one dial per 1.2s with a per-slot cooldown — polite enough to let the
 * signaling socket LIVE, and discovery latency stays in seconds.
 */
// Cadence is a floor, not a guarantee: creating an RTCPeerConnection has
// real cost, so under load (slow phones, CI) the effective rate stretches —
// by design the trickle degrades to "slower discovery", never to a storm.
const DIAL_FIRST_PASS_MS = 250; // cadence until every slot was tried once
const DIAL_TRICKLE_MS = 1_200; // steady-state cadence while unverified
const DIAL_TRICKLE_LINKED_MS = 10_000; // gentle keepalive once verified
const DIAL_SLOT_COOLDOWN_MS = 60_000; // per-slot redial cooldown
/**
 * Re-probe cadence for open-but-unverified connections. On a flaky uplink
 * the signaling broker dies every few seconds (4G handovers) and the remote
 * side may tear down its own peer in sympathy — so a channel's useful
 * lifetime can be SHORTER than any polite post-open wait. Probing is cheap
 * and signaling-free (the datachannel is already open), so it starts the
 * instant a channel opens and repeats until the peer proves itself with
 * consensus-valid blocks.
 */
const PROBE_INTERVAL_MS = 3_000;
const PROBE_TICK_MS = 1_000;
/**
 * The terminal fleet meets on TWO public MQTT brokers by default (the
 * zero-config transport that works where WebRTC cannot). The watcher joins
 * the same room — the PeerJS slot ring alone can hold frozen background
 * tabs that answer the WebRTC handshake yet never speak again.
 */
const MQTT_RELAYS = ['wss://broker.emqx.io:8084/mqtt', 'wss://broker.hivemq.com:8884/mqtt'] as const;
/**
 * A PeerJS channel that opened but delivered ZERO inbound bytes within this
 * window belongs to a frozen background tab (the browser's network stack
 * completes the WebRTC handshake while the page's JS sleeps — the remote
 * never sends its hello). Honest peers greet within milliseconds, so the
 * conn is reaped and the slot freed for the trickle's next pass. MQTT links
 * are exempt: presence-announced peers legitimately take one announce
 * cadence (~15s) before they link us back, and their roster TTL already
 * handles death. The __XENON3_REAP_MS global is a test-only knob.
 */
const SILENT_REAP_MS: number =
  typeof window !== 'undefined' &&
  typeof (window as unknown as { __XENON3_REAP_MS?: unknown }).__XENON3_REAP_MS === 'number'
    ? (window as unknown as { __XENON3_REAP_MS: number }).__XENON3_REAP_MS
    : 45_000;
/** Per-link serving rate limit for getBlocks — we are a read-only mirror;
 *  the PoW gate is the requester's problem, a flood cap is ours. */
const SERVE_MIN_INTERVAL_MS = 1_000;
/** Wire agent string — informational only (the terminal gates on chainId,
 *  p2pVersion and genesisHash, never on agent), so brand it honestly. */
const XENON3_AGENT = 'xenon3-watcher/2.0';
const randomSuffix = (): string => Math.random().toString(36).slice(2, 10);

/** Hashcash challenge: find hex s so that D(`${nonce}:${s}`) starts with the
 *  prefix. Solved cooperatively (12ms slices + macrotask yields) exactly like
 *  the terminal — an inline loop would freeze the game UI for a beat on every
 *  new link. ~65k double-SHA-256 at prefix "0000". */
async function solveChallengeAsync(nonce: string): Promise<string | null> {
  let sliceStart = Date.now();
  for (let i = 0; i < 1 << 24; i += 1) {
    const candidate = i.toString(16);
    if (hashD(`${nonce}:${candidate}`).startsWith(WQD_CHALLENGE_PREFIX)) return candidate;
    if (Date.now() - sliceStart >= 12) {
      await new Promise((r) => setTimeout(r, 0));
      sliceStart = Date.now();
    }
  }
  return null;
}

export class WqdWatcher {
  private readonly watchAddress: string;
  private readonly callbacks: WatcherCallbacks;
  private peer: Peer | null = null;
  private readonly conns = new Map<string, DataConnection>();
  private readonly verified = new Set<string>();

  // ── Full-node state ──────────────────────────────────────────────────────
  private readonly chain = new Map<number, WqdBlock>();
  private readonly orphans = new Map<number, WqdBlock>();
  private balances = new Map<string, bigint>(); // base units
  private nonces = new Map<string, number>();
  private syncedHeight = 0;
  private bestKnown = 0;
  private lastProgressAt = 0;
  private syncPeerIdx = 0;
  /** In-flight getBlocks, one per height range — losses are timed out + rotated. */
  private pendingSync: { to: string; from: number; at: number } | null = null;
  /** Consecutive batch-answer timeouts per peer; persistent ghosts get dropped. */
  private syncTimeouts = new Map<string, number>();

  private readonly seenBlocks = new Set<string>();

  private stopped = false;
  private dialTimer: number | null = null;
  private syncTimer: number | null = null;
  private brokerRetryTimer: number | null = null;
  /** Round-robin cursor into the slot ring (random start spreads load). */
  private dialCursor = Math.floor(Math.random() * SLOT_COUNT);
  /** Slots ever dialed — first-pass cadence ends when the ring is covered. */
  private readonly slotsTouched = new Set<number>();
  /** slot → last dial attempt timestamp (per-slot cooldown). */
  private readonly lastDialAt = new Map<number, number>();
  /** Exponential reconnect backoff while the broker keeps flapping. */
  private brokerBackoff = BROKER_RETRY_MS;
  /** When the current/last signaling socket opened (healthy-flap detection). */
  private socketOpenedAt = 0;
  /** Consecutive broker-failure events — drives diag line coalescing. */
  private flapCount = 0;
  private phase: WatcherPhase = 'starting';
  private lastError: string | null = null;

  // ── Diagnostics state (surfaced via WatcherSnapshot for the on-screen panel)
  private identity: string | null = null;
  private dialed = 0;
  private answered = 0;
  private inbound = 0;
  private readonly diagLog: string[] = [];
  /** Per-connection probe timestamps (rate limit for probeConn). */
  private readonly lastProbeAt = new Map<string, number>();
  /** Connections that actually reached 'open' — only these earn close logs. */
  private readonly established = new Set<string>();
  /** Remotes that already produced the "empty chain" diagnostic line. */
  private readonly emptyAnswerLogged = new Set<string>();
  /** True while the signaling broker is known to be down (pauses dialing;
   *  live datachannels and probing continue — they don't need signaling). */
  private brokerDown = false;
  private probeTimer: number | null = null;

  // ── MQTT room (the terminal fleet's default meeting point) ──────────────
  private mqtt: MqttRoom | null = null;
  /** Linked MQTT peer ids (virtual links — the room roster is the link set). */
  private readonly mqttLinks = new Set<string>();
  /** Advisory tip heights from presence announces (applied once verified). */
  private readonly announcedTips = new Map<string, number>();

  // ── v2 handshake state ───────────────────────────────────────────────────
  /** remoteId → last challenge nonce we answered + its cached solution, so a
   *  re-delivered challenge (QoS0 duplicate / grace re-send) is re-answered
   *  for free instead of burning another ~65k hashes. */
  private readonly challengeCache = new Map<string, { nonce: string; solution: string }>();
  /** remoteId → last inbound frame timestamp (frozen-tab reaper). */
  private readonly lastInboundAt = new Map<string, number>();
  /** remoteId → last getBlocks we served (per-link flood cap). */
  private readonly lastServedAt = new Map<string, number>();
  /** Remotes whose hello showed a foreign chain (one-shot mismatch log). */
  private readonly mismatchLogged = new Set<string>();
  /** Rejected-block reasons already shown on the panel (height:error key). */
  private readonly rejectLogged = new Set<string>();
  /** Resume-from-snapshot lifecycle (IndexedDB; see wqdSnapshot.ts). */
  private starting = false;
  private persistBusy = false;
  private lastEmitAt = 0;
  /** balanceOfAt memo — claims reference FINALIZED history, so entries never
   *  stale; without it every audit re-walks the whole chain per status tick. */
  private readonly auditCache = new Map<string, number | null>();
  private readonly onPageHide = (): void => {
    if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
      void this.persist();
    }
  };

  /** Mirror an event to devtools AND the on-screen diagnostics ring buffer. */
  private logDiag(msg: string): void {
    console.info(`[wqdWatcher] ${msg}`);
    const stamp = new Date().toTimeString().slice(0, 8);
    this.diagLog.push(`${stamp} ${msg}`);
    if (this.diagLog.length > 10) this.diagLog.shift();
  }

  /**
   * Broker-flap logging that COALESCES: on a flapping uplink the broker can
   * die every couple of seconds, and naive logging flushed the ring buffer
   * with failure spam before the meaningful lines (answers, probes,
   * verification) could ever be read. Consecutive failures update a single
   * "broker flapping ×N" entry; any non-broker event breaks the run.
   */
  private logFlap(detail: string): void {
    this.flapCount += 1;
    const text = this.flapCount > 1 ? `broker flapping ×${this.flapCount} — ${detail}` : `broker failure — ${detail}`;
    console.info(`[wqdWatcher] ${text}`);
    const stamp = new Date().toTimeString().slice(0, 8);
    const last = this.diagLog[this.diagLog.length - 1];
    if (this.flapCount > 1 && last !== undefined && last.slice(9).startsWith('broker flapping')) {
      this.diagLog[this.diagLog.length - 1] = `${stamp} ${text}`;
    } else {
      this.diagLog.push(`${stamp} ${text}`);
      if (this.diagLog.length > 10) this.diagLog.shift();
    }
  }

  constructor(watchAddress: string, callbacks: WatcherCallbacks) {
    this.watchAddress = watchAddress;
    this.callbacks = callbacks;
    this.chain.set(0, synthGenesis());
  }

  /**
   * Rendezvous works BOTH ways: terminals constantly dial the 64 slot ids, so
   * the watcher CLAIMS a free slot itself (peers then dial us) and also sweeps
   * the remaining slots outbound — exactly how the terminal finds peers.
   */
  start(): void {
    if (this.peer || this.stopped || this.starting) return;
    // Resume from the IndexedDB snapshot BEFORE networking: peers happily
    // re-serve history we already verified, so the chain tables must be
    // populated first or the resume races the sync driver.
    this.starting = true;
    void this.restore()
      .catch(() => undefined)
      .then(() => {
        this.starting = false;
        if (this.stopped || this.peer) return;
        this.lastProgressAt = Date.now();
        this.syncTimer = window.setInterval(() => this.syncTick(), 4_000);
        this.probeTimer = window.setInterval(() => this.probeTick(), PROBE_TICK_MS);
        window.addEventListener('beforeunload', this.onPageHide);
        document.addEventListener('visibilitychange', this.onPageHide);
        this.claimSlot(Math.floor(Math.random() * SLOT_COUNT));
        this.startMqtt();
        if (this.syncedHeight > 0) this.emitStatus(); // panel shows the resumed tip at once
      });
  }

  /**
   * Load the last verified chain state from IndexedDB. On ANY integrity doubt
   * the snapshot is ignored and sync starts from genesis — a clean resync is
   * always safe, a corrupt resume is not.
   */
  private async restore(): Promise<void> {
    const snap = await loadSnapshot();
    if (!snap || snap.height < 1 || this.syncedHeight > 0) return;
    for (const block of snap.blocks) this.chain.set(block.height, block);
    this.balances = new Map(snap.balances.map(([addr, s]) => [addr, BigInt(s)]));
    this.nonces = new Map(snap.nonces);
    this.syncedHeight = snap.height;
    this.bestKnown = Math.max(this.bestKnown, snap.height);
    // Re-seed dedupe with the recent tail — older hashes are unreachable
    // anyway (handleBlock rejects heights at/below the synced tip).
    for (const b of snap.blocks.slice(-64)) this.seenBlocks.add(b.hash);
    this.logDiag(`resumed from local snapshot at #${snap.height} — syncing the delta only`);
  }

  /** Persist the verified chain state (every 64 commits + on page hide). */
  private async persist(): Promise<void> {
    if (this.persistBusy || this.syncedHeight < 1) return;
    this.persistBusy = true;
    try {
      const blocks: WqdBlock[] = [];
      for (let h = 1; h <= this.syncedHeight; h += 1) {
        const b = this.chain.get(h);
        if (!b) return; // gap — never persist a partial history
        blocks.push(b);
      }
      await saveSnapshot({
        v: 1,
        savedAt: Date.now(),
        height: this.syncedHeight,
        tipHash: this.chain.get(this.syncedHeight)?.hash ?? '',
        blocks,
        balances: [...this.balances.entries()].map(([addr, v]) => [addr, v.toString()]),
        nonces: [...this.nonces.entries()],
      });
    } catch {
      // best-effort — persistence never breaks sync
    } finally {
      this.persistBusy = false;
    }
  }

  stop(): void {
    this.stopped = true;
    if (typeof window !== 'undefined') window.removeEventListener('beforeunload', this.onPageHide);
    if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', this.onPageHide);
    void this.persist(); // final best-effort flush of the verified tip
    if (this.dialTimer !== null) { window.clearTimeout(this.dialTimer); this.dialTimer = null; }
    if (this.syncTimer !== null) { window.clearInterval(this.syncTimer); this.syncTimer = null; }
    if (this.probeTimer !== null) { window.clearInterval(this.probeTimer); this.probeTimer = null; }
    if (this.brokerRetryTimer !== null) { window.clearTimeout(this.brokerRetryTimer); this.brokerRetryTimer = null; }
    this.conns.forEach((c) => c.close());
    this.conns.clear();
    this.mqtt?.stop();
    this.mqtt = null;
    this.mqttLinks.clear();
    this.peer?.destroy();
    this.peer = null;
  }

  /**
   * Join the MQTT presence room — the terminal fleet's DEFAULT transport.
   * The PeerJS slot ring is kept in parallel (redundant paths, never a
   * doubled identity: mqtt ids live in their own `m-<hex12>` namespace).
   * Room events are wired straight into the same message pipeline as PeerJS
   * links, so the v2 handshake, sync and serving behave identically.
   */
  private startMqtt(): void {
    if (this.mqtt || this.stopped) return;
    const urls = mqttUrlsFromRuntime(MQTT_RELAYS);
    if (urls.length === 0) return; // ?nomqtt=1 — debug hatch
    const room = new MqttRoom(urls, WQD_CHAIN_ID, {
      onOpen: (id) => this.mqttOpen(id),
      onClose: (id) => this.mqttGone(id),
      onMessage: (id, data) => {
        let parsed: unknown;
        try {
          parsed = JSON.parse(data);
        } catch {
          return; // unparseable — not our protocol, ignore silently
        }
        this.lastInboundAt.set(id, Date.now());
        void this.onMessage(id, null, parsed);
      },
      onPeerTip: (id, height) => {
        // Advisory until the peer verifies — mirrors the terminal's own
        // handlePeerTip. A higher announced tip wakes a stalled sync.
        this.announcedTips.set(id, height);
        if (this.verified.has(id) && height > this.bestKnown) {
          this.bestKnown = height;
          this.requestBatch();
          this.emitStatus();
        }
      },
      onDiag: (msg) => {
        this.logDiag(msg);
        this.emitStatus();
      },
    });
    this.mqtt = room;
    room.start();
  }

  /** A room peer surfaced: greet + probe immediately, exactly like a fresh
   *  PeerJS channel. The hello MUST go out synchronously here — the room
   *  fires onOpen from inside its inbound-frame handler, and the remote's
   *  engine links us the moment OUR hello lands (implicit presence). */
  private mqttOpen(id: string): void {
    if (this.stopped || this.mqttLinks.has(id)) return;
    this.mqttLinks.add(id);
    this.lastInboundAt.set(id, Date.now()); // presence announce is inbound proof of life
    this.logDiag(`mqtt peer present: ${id} — hello + probe sent`);
    this.sendTo(id, {
      type: 'hello',
      hello: this.helloBody(),
    });
    this.probeId(id, true);
    this.emitStatus();
  }

  /** Roster tombstone: the peer went silent past the room TTL. */
  private mqttGone(id: string): void {
    if (!this.mqttLinks.delete(id)) return;
    const wasVerified = this.verified.delete(id);
    this.lastProbeAt.delete(id);
    this.emptyAnswerLogged.delete(id);
    this.challengeCache.delete(id);
    this.announcedTips.delete(id);
    this.lastServedAt.delete(id);
    this.lastInboundAt.delete(id);
    if (wasVerified) {
      this.logDiag(`mqtt peer faded: ${id}${wasVerified ? ' (was verified)' : ''}`);
      if (this.verified.size === 0 && this.phase === 'linked') this.phase = 'sweeping';
      this.emitStatus();
    }
  }

  /**
   * Fatal signaling-cloud failure: surface the exact PeerJS error type and
   * recover — but WITHOUT nuking live data connections. A signaling outage
   * (4G flap, captive portal) does not kill established WebRTC channels:
   * they are peer-to-peer and keep working. So we keep the peer and simply
   * re-attach to the broker via reconnect(); only a truly dead peer (never
   * claimed / already destroyed) falls back to a fresh identity claim.
   * Before this existed the watcher died SILENTLY here — and an earlier fix
   * destroyed the whole peer, killing every live connection with it.
   */
  private brokerFailed(errType: string): void {
    if (this.stopped) return;
    this.brokerDown = true; // pauses dialing until the socket is back
    this.lastError = errType;
    // A socket that lived a while proves the path is healthy — reset the
    // backoff. A socket dying within seconds escalates it (see the timer).
    if (this.socketOpenedAt > 0 && Date.now() - this.socketOpenedAt >= FLAP_HEALTHY_MS) {
      this.brokerBackoff = BROKER_RETRY_MS;
    }
    // A signaling outage does NOT kill established WebRTC datachannels — P2P
    // sync can keep working while the broker flaps. Only paint the red
    // broker-error state when we truly have nothing left to talk to; with a
    // live channel the probe ticker keeps racing the flaps.
    const hasLiveConns = [...this.conns.values()].some((c) => c.open) || this.mqttLinks.size > 0;
    if (this.verified.size === 0 && !hasLiveConns) this.phase = 'broker-error';
    console.warn(`[wqdWatcher] signaling broker failure (${errType}) — reconnecting in ${Math.round(this.brokerBackoff / 1000)}s`);
    this.logFlap(`(${errType}) — retry in ${Math.round(this.brokerBackoff / 1000)}s, live connections kept`);
    this.emitStatus();
    if (this.brokerRetryTimer !== null) window.clearTimeout(this.brokerRetryTimer);
    this.brokerRetryTimer = window.setTimeout(() => {
      this.brokerRetryTimer = null;
      if (this.stopped) return;
      // Escalate for the NEXT failure: rapid-fire reconnect attempts are
      // themselves load the free broker punishes. 5s → 10s → 20s → 30s cap.
      this.brokerBackoff = Math.min(this.brokerBackoff * 2, BROKER_RETRY_MAX_MS);
      if (this.peer) {
        try {
          this.peer.reconnect(); // same identity, live connections survive
          return;
        } catch { /* peer object unusable — fall through to a fresh claim */ }
      }
      this.phase = 'starting';
      this.emitStatus();
      this.claimSlot(Math.floor(Math.random() * SLOT_COUNT));
    }, this.brokerBackoff);
  }

  // ── Public oracle ──────────────────────────────────────────────────────────

  /** Replayed balance of any address at the synced tip (WQD float). */
  balanceOf(address: string): number {
    return Number(this.balances.get(address) ?? 0n) / WQD_BASE;
  }

  /**
   * Replayed balance of an address at an exact height (for auditing a peer's
   * balance claim). Returns null when that height is beyond our synced tip.
   */
  balanceOfAt(address: string, height: number): number | null {
    if (height > this.syncedHeight) return null; // not final yet — caller re-checks
    const cacheKey = `${address}:${height}`;
    const cached = this.auditCache.get(cacheKey);
    if (cached !== undefined) return cached;
    let total = 0n;
    for (let h = 1; h <= height; h += 1) {
      const block = this.chain.get(h);
      if (!block) return null; // history gap — don't cache, don't trust
      const cb = blockCoinbase(block);
      if (cb && cb.toAddress === address) total += BigInt(Number(cb.amount));
      for (const p of block.popTransfers) {
        if (p.address === address) total += BigInt(Number(p.amount));
      }
      for (const tx of blockTransfers(block)) {
        if (tx.fromAddress === address) total -= BigInt(tx.amount) + BigInt(tx.fee);
        if (tx.toAddress === address) total += BigInt(tx.amount);
      }
    }
    const result = Number(total) / WQD_BASE;
    // Finalized history is immutable — the memo can never go stale.
    if (this.auditCache.size > 512) this.auditCache.clear();
    this.auditCache.set(cacheKey, result);
    return result;
  }

  // ── Peer lifecycle ─────────────────────────────────────────────────────────

  private claimSlot(offset: number, tried = 0): void {
    if (this.stopped) return;
    if (tried >= SLOT_COUNT) {
      // Every rendezvous slot is taken by live nodes — we can still function
      // outbound-only (the sweep is what finds miners; claiming a slot merely
      // lets peers also dial US), so fall back to an ephemeral identity.
      console.info('[wqdWatcher] all 64 slots busy — falling back to an ephemeral identity');
      this.startEphemeral();
      return;
    }
    const slot = (offset + tried) % SLOT_COUNT;
    const id = `${WQD_PEER_NAMESPACE}-slot-${slot}`;
    const peer = new Peer(id, {
      host: PEER_HOST,
      port: 443,
      path: '/',
      secure: true,
      debug: 0,
      config: { iceServers: ICE_SERVERS },
    });
    const claimed = () => {
      if (this.stopped) { peer.destroy(); return; }
      this.peer = peer;
      this.identity = id;
      this.phase = 'sweeping';
      this.lastError = null;
      this.brokerDown = false;
      this.socketOpenedAt = Date.now();
      this.brokerBackoff = BROKER_RETRY_MS;
      this.logDiag(`identity claimed: ${id} — scanning the slot ring`);
      peer.on('connection', (conn) => this.wireConn(conn, true));
      this.startTrickle();
      this.emitStatus();
      // Fires again after peer.reconnect() succeeds — the broker is back.
      // Live datachannels survived the flap, so re-probe them (probing is
      // signaling-free) and resume pulling from verified peers. NO sweep
      // here: the trickle resumes on its own cadence, and a reconnect burst
      // is exactly what got sockets killed in the field.
      peer.on('open', () => {
        if (this.peer !== peer) return;
        if (this.phase === 'broker-error' || this.phase === 'starting' || this.brokerDown) {
          this.brokerDown = false;
          this.phase = this.verified.size > 0 ? 'linked' : 'sweeping';
          this.lastError = null;
          this.socketOpenedAt = Date.now();
          this.brokerBackoff = BROKER_RETRY_MS;
          const live = [...this.conns.values()].filter((c) => c.open).length;
          this.flapCount = 0;
          this.logDiag(`broker reconnected — ${live} live connection(s) kept — probing, trickle resumes`);
          this.probeTick(true);
          if (this.bestKnown > this.syncedHeight) this.requestBatch();
          this.emitStatus();
        }
      });
      // A clean socket close surfaces as 'disconnected' with NO 'error' event
      // — without this, a silent flap would never trigger the recovery path.
      peer.on('disconnected', () => {
        if (this.peer === peer) this.brokerFailed('disconnected');
      });
      peer.on('error', (err: { type?: string; message?: string }) => {
        // 'peer-unavailable' fires once per unanswered dial: free that slot so
        // the next sweep REDIALS it (the conn itself just hangs otherwise).
        if (err?.type === 'peer-unavailable') {
          const m = /peer\s+(\S+)\s*$/i.exec(String(err.message ?? ''));
          const stuck = m ? this.conns.get(m[1]) : undefined;
          if (m && stuck && !stuck.open) this.dropDeadDial(m[1], stuck);
          return;
        }
        // A fatal socket/network failure means our identity is dead → re-claim.
        if (err?.type && FATAL_BROKER_ERRORS.has(err.type)) this.brokerFailed(err.type);
      });
    };
    let settled = false;
    peer.on('open', () => { if (!settled) { settled = true; claimed(); } });
    peer.on('error', (err: { type?: string }) => {
      if (settled) return;
      if (err?.type === 'unavailable-id') {
        settled = true;
        try { peer.destroy(); } catch { /* noop */ }
        this.claimSlot(offset, tried + 1); // slot taken by a live node — try the next
        return;
      }
      settled = true;
      try { peer.destroy(); } catch { /* noop */ }
      this.brokerFailed(err?.type ?? 'unknown'); // visible + retried, never silent
    });
  }

  private startEphemeral(): void {
    if (this.peer || this.stopped) return;
    const peer = new Peer(`${WQD_PEER_NAMESPACE}-x-${randomSuffix()}`, {
      host: PEER_HOST,
      port: 443,
      path: '/',
      secure: true,
      debug: 0,
      config: { iceServers: ICE_SERVERS },
    });
    peer.on('open', () => {
      if (this.stopped) { peer.destroy(); return; }
      const firstClaim = this.peer !== peer;
      this.peer = peer;
      this.identity = peer.id;
      this.phase = this.verified.size > 0 ? 'linked' : 'sweeping';
      this.lastError = null;
      this.socketOpenedAt = Date.now();
      this.brokerBackoff = BROKER_RETRY_MS;
      if (firstClaim) {
        this.brokerDown = false;
        this.logDiag(`ephemeral identity: ${peer.id} — scanning the slot ring`);
        peer.on('connection', (conn) => this.wireConn(conn, true));
        peer.on('disconnected', () => {
          if (this.peer === peer) this.brokerFailed('disconnected');
        });
      } else {
        // Same listener as claimSlot's recovery path: broker is back.
        this.brokerDown = false;
        const live = [...this.conns.values()].filter((c) => c.open).length;
        this.flapCount = 0;
        this.logDiag(`broker reconnected — ${live} live connection(s) kept — probing, trickle resumes`);
        this.probeTick(true);
        if (this.bestKnown > this.syncedHeight) this.requestBatch();
      }
      this.startTrickle();
      this.emitStatus();
    });
    peer.on('error', (err: { type?: string; message?: string }) => {
      if (err?.type === 'peer-unavailable') {
        const m = /peer\s+(\S+)\s*$/i.exec(String(err.message ?? ''));
        const stuck = m ? this.conns.get(m[1]) : undefined;
        if (m && stuck && !stuck.open) this.dropDeadDial(m[1], stuck);
        return;
      }
      if (err?.type && FATAL_BROKER_ERRORS.has(err.type)) this.brokerFailed(err.type);
    });
  }

  /**
   * The ring scanner: a self-rearming timer dialing ONE slot per tick,
   * round-robin, forever (until stop). Replaces the burst sweeps that got
   * our own signaling socket killed on the free broker. The first pass over
   * the ring runs at DIAL_FIRST_PASS_MS so a fresh watcher still discovers
   * every live slot within ~16s; afterwards it idles at DIAL_TRICKLE_MS and
   * each slot is retried at most once per DIAL_SLOT_COOLDOWN_MS.
   */
  private startTrickle(): void {
    if (this.dialTimer !== null || this.stopped) return; // already running
    const tick = (): void => {
      if (this.stopped) { this.dialTimer = null; return; }
      this.dialTimer = window.setTimeout(tick, this.trickleDelay());
      this.dialNextSlot();
    };
    this.dialTimer = window.setTimeout(tick, 300); // first dial almost at once
  }

  private trickleDelay(): number {
    if (this.verified.size > 0) return DIAL_TRICKLE_LINKED_MS;
    // −1: our own claimed slot is never dialed.
    return this.slotsTouched.size >= SLOT_COUNT - 1 ? DIAL_TRICKLE_MS : DIAL_FIRST_PASS_MS;
  }

  /** Dial the next dial-worthy ring slot (round-robin), if any. */
  private dialNextSlot(): void {
    if (!this.peer || this.stopped || this.brokerDown) return; // dialing needs the signaling cloud
    if (this.verified.size >= MIN_PEERS + 1) return; // enough verified peers — stay quiet
    for (let step = 0; step < SLOT_COUNT; step += 1) {
      const slot = (this.dialCursor + step) % SLOT_COUNT;
      const remoteId = `${WQD_PEER_NAMESPACE}-slot-${slot}`;
      if (remoteId === this.identity) continue; // our own claimed slot
      if (this.conns.has(remoteId)) continue; // already connected or dialing
      const last = this.lastDialAt.get(slot) ?? 0;
      if (Date.now() - last < DIAL_SLOT_COOLDOWN_MS) continue; // tried recently
      this.dialCursor = (slot + 1) % SLOT_COUNT;
      this.dial(slot);
      return;
    }
    // Every slot is connected or cooling down — nothing to do this tick.
  }

  private emitStatus(): void {
    // During catch-up this fires per committed block — one React re-render
    // each, hundreds per second on a fast link. Throttle to 5 Hz while
    // behind; the moment we reach the known tip every emit goes through.
    const catchingUp = this.syncedHeight < this.bestKnown;
    const now = Date.now();
    if (catchingUp && now - this.lastEmitAt < 200) return;
    this.lastEmitAt = now;
    this.callbacks.onStatus({
      peers: this.verified.size,
      tipHeight: this.syncedHeight,
      bestKnown: this.bestKnown,
      tipTarget: this.chain.get(this.syncedHeight)?.target ?? null,
      watchBalance: this.balanceOf(this.watchAddress),
      phase: this.phase,
      lastError: this.lastError,
      identity: this.identity,
      dialed: this.dialed,
      answered: this.answered,
      inbound: this.inbound,
      diag: [...this.diagLog],
    });
  }

  private dial(slot: number): void {
    if (!this.peer || this.stopped) return;
    const remoteId = `${WQD_PEER_NAMESPACE}-slot-${slot}`;
    if (this.conns.has(remoteId)) return;
    let conn: DataConnection;
    try {
      conn = this.peer.connect(remoteId, { reliable: true });
    } catch {
      return;
    }
    this.dialed += 1;
    this.slotsTouched.add(slot);
    this.lastDialAt.set(slot, Date.now());
    this.wireConn(conn);
    // See DIAL_TIMEOUT_MS: offline slots produce hanging connections that
    // would otherwise blacklist that slot for every future sweep.
    window.setTimeout(() => {
      if (!conn.open) this.dropDeadDial(remoteId, conn);
    }, DIAL_TIMEOUT_MS);
  }

  private wireConn(conn: DataConnection, inbound = false): void {
    const remoteId = conn.peer;
    if (this.conns.has(remoteId)) return;
    this.conns.set(remoteId, conn);
    const greet = (): void => {
      this.established.add(remoteId);
      // The WebRTC handshake itself is network-layer proof of life; the
      // reaper watches for the JS-level hello that must follow quickly.
      this.lastInboundAt.set(remoteId, Date.now());
      if (inbound) {
        this.inbound += 1;
        this.logDiag(`inbound connection from ${remoteId}`);
      } else {
        this.answered += 1;
        if (this.answered === 1) this.logDiag(`first dial answered by ${remoteId}`);
      }
      this.sayHello(conn);
      // Probe IMMEDIATELY, not after a polite wait: on a flaky uplink the
      // signaling broker dies every few seconds and the remote side may tear
      // down its own peer in sympathy, so a channel's useful lifetime can be
      // shorter than any grace period. Blocks are the real proof anyway.
      this.probeConn(conn, true);
      this.emitStatus();
      // Same-device peers can race their own 'connection' event and NEVER
      // send a hello (diagnostics showed answered:4, verified:0). If silence
      // persists, say so on the panel — the probe ticker keeps nudging.
      window.setTimeout(() => {
        if (this.stopped || !conn.open || this.verified.has(remoteId)) return;
        this.logDiag(`no hello from ${remoteId} — probing with getBlocks`);
        this.emitStatus(); // flush the line even if the probe never answers
        this.probeConn(conn, true);
      }, 2_500);
    };
    // Open-race guard: for INBOUND connections 'open' may already have fired
    // before our 'connection' handler ran — attaching a listener then would
    // mean our hello is never sent and the remote never verifies us.
    if (conn.open) greet();
    else conn.on('open', greet);
    conn.on('data', (data) => {
      this.lastInboundAt.set(remoteId, Date.now());
      void this.onMessage(remoteId, conn, data);
    });
    const gone = (log: boolean): void => {
      if (this.conns.get(remoteId) !== conn) return; // already handled
      const wasEstablished = this.established.delete(remoteId);
      const wasVerified = this.verified.delete(remoteId);
      this.conns.delete(remoteId);
      this.lastProbeAt.delete(remoteId);
      this.lastInboundAt.delete(remoteId);
      this.challengeCache.delete(remoteId);
      this.lastServedAt.delete(remoteId);
      this.emptyAnswerLogged.delete(remoteId);
      // Only channels that actually opened earn a log line — dead dials to
      // offline slots close silently, or the ring buffer becomes pure noise.
      if (log && wasEstablished) {
        this.logDiag(`connection lost: ${remoteId}${wasVerified ? ' (was verified)' : ''}`);
      }
      if (wasVerified && this.verified.size === 0 && this.phase === 'linked') {
        this.phase = 'sweeping';
      }
      if (wasEstablished) this.emitStatus();
    };
    conn.on('close', () => gone(true));
    conn.on('error', () => gone(true));
  }

  /**
   * Ask an open-but-unverified link for blocks above our synced tip.
   * This is the implicit-verification engine: hellos can be lost to the
   * same-device 'connection' race and signaling flaps, but a peer answering
   * with consensus-valid blocks proves honesty with DATA. Cheap and
   * signaling-free, so the probe ticker repeats it until verification.
   * Works over BOTH transports (PeerJS channel or MQTT inbox).
   */
  private probeId(remoteId: string, force = false): void {
    if (this.stopped || !this.linkOpen(remoteId) || this.verified.has(remoteId)) return;
    const now = Date.now();
    if (!force && now - (this.lastProbeAt.get(remoteId) ?? 0) < PROBE_INTERVAL_MS) return;
    this.lastProbeAt.set(remoteId, now);
    this.sendTo(remoteId, { type: 'getBlocks', from: this.syncedHeight + 1, count: SYNC_BATCH });
  }

  private probeConn(conn: DataConnection, force = false): void {
    this.probeId(conn.peer, force);
  }

  /** Periodic: re-probe every open unverified link (flap recovery), and reap
   *  PeerJS channels that have been TOTALLY silent since they opened — the
   *  signature of a frozen background tab (WebRTC completes at the network
   *  layer while the page's JS sleeps). Reaping frees the slot so the
   *  trickle's per-slot cooldown governs a polite retry instead of the dead
   *  channel occupying the ring forever. MQTT links are exempt (see
   *  SILENT_REAP_MS). */
  private probeTick(force = false): void {
    if (this.stopped) return;
    this.conns.forEach((conn) => {
      this.probeConn(conn, force);
      if (!conn.open || this.verified.has(conn.peer)) return;
      const lastSeen = this.lastInboundAt.get(conn.peer) ?? 0;
      if (lastSeen > 0 && Date.now() - lastSeen > SILENT_REAP_MS) {
        this.logDiag(`reaping silent connection to ${conn.peer} (no handshake — likely a frozen tab)`);
        this.established.delete(conn.peer);
        this.conns.delete(conn.peer);
        this.lastProbeAt.delete(conn.peer);
        this.lastInboundAt.delete(conn.peer);
        try {
          conn.close();
        } catch {
          /* already gone */
        }
        this.emitStatus();
      }
    });
    this.mqttLinks.forEach((id) => this.probeId(id, force));
  }

  /** Forget a dial that will never answer, so the next sweep retries it. */
  private dropDeadDial(remoteId: string, conn: DataConnection): void {
    if (this.conns.get(remoteId) !== conn) return;
    try { conn.close(); } catch { /* noop */ }
    this.conns.delete(remoteId);
  }

  // ── Transport-neutral link plumbing ────────────────────────────────────────
  // PeerJS links are real DataConnections; MQTT links are room-roster members
  // addressed through inbox topics. Both are keyed by remote id (namespaces
  // never collide: `wqd-mainnet1-…` vs `m-<hex12>`).

  /** Route one wire message to a remote over whichever transport owns it. */
  private sendTo(remoteId: string, msg: Record<string, unknown>): boolean {
    if (remoteId.startsWith('m-')) {
      if (!this.mqtt || !this.mqttLinks.has(remoteId)) return false;
      this.mqtt.send(remoteId, JSON.stringify(msg));
      return true;
    }
    const conn = this.conns.get(remoteId);
    if (!conn || !conn.open) return false;
    try {
      conn.send(msg);
      return true;
    } catch {
      return false; // channel died between the open check and the send
    }
  }

  /** Is the link to this remote currently usable (any transport)? */
  private linkOpen(remoteId: string): boolean {
    if (remoteId.startsWith('m-')) return this.mqttLinks.has(remoteId);
    return this.conns.get(remoteId)?.open === true;
  }

  /** The v2 hello body — fields the terminal gates on (chainId, p2pVersion,
   *  genesisHash) come from the pinned consensus constants; nodeId is null
   *  because a read-only watcher never collects PoP attestations. */
  private helloBody(): Record<string, unknown> {
    return {
      chainId: WQD_CHAIN_ID,
      p2pVersion: WQD_P2P_VERSION,
      agent: XENON3_AGENT,
      genesisHash: WQD_GENESIS_HASH,
      height: this.syncedHeight,
      tipHash: this.chain.get(this.syncedHeight)?.hash ?? '0'.repeat(64),
      serverTime: Math.floor(Date.now() / 1000),
      nodeId: null,
    };
  }

  private sayHello(conn: DataConnection): void {
    try {
      conn.send({ type: 'hello', hello: this.helloBody() });
    } catch {
      /* channel racing a close */
    }
  }

  // ── Sync driver ────────────────────────────────────────────────────────────

  /**
   * Ask a verified peer for the next batch above our synced tip. Re-requests
   * round-robin through the verified set so one slow peer can't stall sync.
   * The pool spans both transports — a verified link is a verified link.
   */
  private requestBatch(remoteId?: string): void {
    const from = this.syncedHeight + 1;
    // One request in flight per range: QoS0 MQTT frames and half-dead WebRTC
    // channels BOTH lose messages silently, so the timeout in syncTick owns
    // the retry — we never stack duplicate asks onto the same peer.
    if (
      this.pendingSync &&
      this.pendingSync.from === from &&
      Date.now() - this.pendingSync.at < SYNC_REQUEST_TIMEOUT_MS
    ) {
      return;
    }
    const pool = [
      ...[...this.conns.values()].filter((c) => c.open && this.verified.has(c.peer)).map((c) => c.peer),
      ...[...this.mqttLinks].filter((id) => this.verified.has(id)),
    ];
    if (pool.length === 0) return;
    let target: string;
    if (remoteId && pool.includes(remoteId)) {
      target = remoteId;
    } else {
      this.syncPeerIdx = (this.syncPeerIdx + 1) % pool.length;
      target = pool[this.syncPeerIdx];
    }
    this.pendingSync = { to: target, from, at: Date.now() };
    this.sendTo(target, { type: 'getBlocks', from, count: SYNC_BATCH });
  }

  /** Periodic: time out lost batch requests and rotate to the next peer;
   *  re-request when behind with nothing in flight and progress stalled. */
  private syncTick(): void {
    if (this.stopped) return;
    if (this.bestKnown <= this.syncedHeight) return;
    const now = Date.now();
    if (this.pendingSync) {
      if (now - this.pendingSync.at < SYNC_REQUEST_TIMEOUT_MS) return; // still waiting
      const ghost = this.pendingSync.to;
      this.pendingSync = null;
      const strikes = (this.syncTimeouts.get(ghost) ?? 0) + 1;
      this.syncTimeouts.set(ghost, strikes);
      this.logDiag(`no blocks from ${ghost} within ${SYNC_REQUEST_TIMEOUT_MS / 1000}s — asking another peer`);
      this.emitStatus();
      if (strikes >= SYNC_TIMEOUT_DROP) {
        this.syncTimeouts.delete(ghost);
        this.dropUnresponsive(ghost);
      }
      this.requestBatch(); // immediately try the next verified peer
      return;
    }
    if (now - this.lastProgressAt > SYNC_STALL_MS) this.requestBatch();
  }

  /** A peer that never answers getBlocks is worse than no peer: unverify and
   *  close it so the ring trickle replaces it with a live one (the conn's
   *  own close handler does the full map cleanup; MQTT roster entries fade
   *  on their own and must re-prove themselves). */
  private dropUnresponsive(remoteId: string): void {
    this.logDiag(`dropping unresponsive peer ${remoteId}`);
    const conn = this.conns.get(remoteId);
    try {
      conn?.close();
    } catch {
      /* already gone */
    }
    this.verified.delete(remoteId);
    if (this.verified.size === 0 && this.phase === 'linked') this.phase = 'sweeping';
    this.emitStatus();
  }

  // ── Message handling ───────────────────────────────────────────────────────
  // `conn` is the PeerJS channel for PeerJS remotes, null for MQTT links
  // (MQTT frames arrive as parsed JSON via the room; sends route by remoteId).

  private async onMessage(remoteId: string, conn: DataConnection | null, data: unknown): Promise<void> {
    if (this.stopped || typeof data !== 'object' || data === null) return;
    if (this.mismatchLogged.has(remoteId)) return; // foreign chain — muted
    const msg = data as { type?: string; [k: string]: unknown };
    switch (msg.type) {
      case 'hello': {
        const hello = msg.hello as { chainId?: string; genesisHash?: string; height?: number; p2pVersion?: number } | undefined;
        if (hello?.chainId !== WQD_CHAIN_ID || hello?.genesisHash !== WQD_GENESIS_HASH || hello?.p2pVersion !== WQD_P2P_VERSION) {
          // A foreign-chain or stale-build peer. Log it ONCE with the actual
          // values — if OUR pinned genesis ever drifts from the live network
          // this line is the only place that can surface it.
          this.mismatchLogged.add(remoteId);
          this.logDiag(
            `${remoteId} speaks a different chain (chainId=${hello?.chainId ?? '?'}, genesis=${String(hello?.genesisHash ?? '?').slice(0, 12)}…) — ignoring`,
          );
          this.emitStatus();
          if (conn) {
            try {
              conn.close();
            } catch {
              /* noop */
            }
          }
          return;
        }
        if (!this.verified.has(remoteId)) {
          this.verified.add(remoteId);
          if (this.phase !== 'linked') {
            this.phase = 'linked';
            this.logDiag(`first verified mainnet peer: ${remoteId}`);
          }
          const h = typeof hello.height === 'number' ? hello.height : 0;
          const announced = this.announcedTips.get(remoteId) ?? 0;
          if (Math.max(h, announced) > this.bestKnown) this.bestKnown = Math.max(h, announced);
          this.emitStatus();
          if (this.bestKnown > this.syncedHeight) this.requestBatch(remoteId);
        }
        return;
      }
      case 'challenge': {
        // The terminal's sybil gate: answer its proof-of-work challenge or
        // every data frame we send stays parked. ~65k double-SHA-256 — a
        // fraction of a second for an honest tab. A re-delivered nonce
        // (QoS0 duplicate or the issuer's grace re-send) is re-answered from
        // the cache with identical bytes, zero CPU.
        const nonce = typeof msg.nonce === 'string' ? msg.nonce : null;
        if (!nonce || !/^[0-9a-f]{16}$/.test(nonce)) return;
        const cached = this.challengeCache.get(remoteId);
        if (cached && cached.nonce === nonce) {
          this.sendTo(remoteId, { type: 'challengeResponse', nonce, solution: cached.solution });
          return;
        }
        const solution = await solveChallengeAsync(nonce);
        // The link may have died while we were hashing — answering is waste.
        if (this.stopped || !this.linkOpen(remoteId)) return;
        if (solution) {
          this.challengeCache.set(remoteId, { nonce, solution });
          this.sendTo(remoteId, { type: 'challengeResponse', nonce, solution });
        }
        return;
      }
      case 'ping': {
        // The terminal heartbeats every 30s and drops peers after 3 missed
        // pongs — answering is what keeps a verified link alive at the tip.
        this.sendTo(remoteId, { type: 'pong', t: msg.t });
        return;
      }
      case 'pong':
        return; // we never ping — nothing to track
      case 'getBlocks': {
        this.serveBlocks(remoteId, msg.from, msg.count);
        return;
      }
      case 'block': {
        this.handleBlock(msg.block as WqdBlock, remoteId);
        return;
      }
      case 'blocks': {
        const list = (msg.blocks ?? msg) as WqdBlock[];
        if (!Array.isArray(list)) return;
        // Any answer — even an empty one — proves the peer is alive.
        if (this.pendingSync?.to === remoteId) this.pendingSync = null;
        this.syncTimeouts.delete(remoteId);
        // An EMPTY answer from an unverified peer is diagnostic gold: it
        // means we reached another lonely watcher (synced height 0), not a
        // miner — so the user knows the terminal itself hasn't been found.
        if (list.length === 0 && !this.verified.has(remoteId) && !this.emptyAnswerLogged.has(remoteId)) {
          this.emptyAnswerLogged.add(remoteId);
          this.logDiag(`${remoteId} answered with 0 blocks — a lonely watcher, not a miner; still probing`);
          this.emitStatus(); // nothing else may arrive — flush the panel NOW
        }
        const before = this.syncedHeight;
        for (const b of list) this.handleBlock(b, remoteId);
        // Console milestone per crossed 64-block boundary so a long catch-up
        // is visibly alive in devtools (the UI bar already shows it).
        if (Math.floor(this.syncedHeight / 64) !== Math.floor(before / 64)) {
          this.logDiag(`verified tip #${this.syncedHeight} / #${this.bestKnown} (${this.verified.size} peers)`);
        }
        // Keep pulling while full batches arrive — either because a hello'd
        // peer advertised more (bestKnown), or because this peer is verified
        // at all (implicit sources have no advertised tip; a short/empty
        // batch is what marks their chain end and stops the pull).
        if (list.length >= SYNC_BATCH && (this.bestKnown > this.syncedHeight || this.verified.has(remoteId))) {
          // Yield one macrotask between 16-block units of ECDSA work so the
          // UI thread stays fluid during long catch-ups.
          window.setTimeout(() => this.requestBatch(remoteId), 0);
        }
        return;
      }
      case 'peers': {
        const list = (msg.peers ?? msg.ids) as unknown;
        if (Array.isArray(list) && this.peer) {
          for (const id of list.slice(0, 32)) {
            if (typeof id !== 'string') continue;
            // Only PeerJS-namespace ids are dialable; m-* ids are discovered
            // by room presence, and cross-namespace dialing never works.
            if (!id.startsWith(WQD_PEER_NAMESPACE)) continue;
            if (id === this.peer.id || this.conns.has(id)) continue;
            try { this.wireConn(this.peer.connect(id, { reliable: true })); } catch { /* noop */ }
          }
        }
        return;
      }
      // 'tx', 'pop_attestation': mempool and mining-attendance traffic — a
      // read-only balance mirror derives everything from COMMITTED blocks.
      default:
    }
  }

  /**
   * Serve verified chain blocks to any requesting peer, clamped to the
   * protocol batch of 16 and rate-limited per link. Watchers bootstrap each
   * other this way, and a terminal that is behind can sync from us — the
   * mirror is a good citizen of the mesh. Only blocks that already passed
   * full consensus verification are ever served.
   */
  private serveBlocks(remoteId: string, fromRaw: unknown, countRaw: unknown): void {
    const from = typeof fromRaw === 'number' ? fromRaw : NaN;
    const count = typeof countRaw === 'number' ? countRaw : NaN;
    if (!Number.isInteger(from) || from < 0 || !Number.isInteger(count) || count < 1) return;
    if (!this.linkOpen(remoteId)) return;
    const now = Date.now();
    if (now - (this.lastServedAt.get(remoteId) ?? 0) < SERVE_MIN_INTERVAL_MS) return;
    this.lastServedAt.set(remoteId, now);
    const cap = Math.min(count, SYNC_BATCH);
    const out: WqdBlock[] = [];
    for (let h = from; h < from + cap; h += 1) {
      const b = this.chain.get(h);
      if (!b) break; // stop at first gap — exactly like the terminal
      out.push(b);
    }
    this.sendTo(remoteId, { type: 'blocks', blocks: out });
  }

  // ── Full-node block processing ─────────────────────────────────────────────

  private recentTimestamps(): number[] {
    const out: number[] = [];
    for (let h = Math.max(0, this.syncedHeight - 10); h <= this.syncedHeight; h += 1) {
      const b = this.chain.get(h);
      if (b) out.push(b.timestamp);
    }
    return out;
  }

  /**
   * Verify one block against consensus and commit it when valid.
   * Returns true only when the block extended our chain.
   *
   * IMPLICIT VERIFICATION: a peer's hello is just the FAST path to trust —
   * the blocks themselves are the real proof. On a same-device setup the
   * remote side can race its own 'connection' event and never send a hello
   * at all (answered dials, zero verified — exactly what the diagnostics
   * showed). A peer whose blocks pass full consensus verification from the
   * pinned genesis demonstrably holds the honest chain, so the first
   * committed block upgrades that connection to verified. A fake peer
   * cannot abuse this: it cannot forge a block that survives verification.
   */
  private handleBlock(block: WqdBlock, remoteId?: string): boolean {
    if (this.stopped || !block || typeof block.height !== 'number' || typeof block.hash !== 'string') return false;
    if (this.seenBlocks.has(block.hash)) return false;
    if (block.height <= this.syncedHeight) return false; // already on our chain

    if (block.height > this.syncedHeight + 1) {
      // future block (gossip during catch-up) — stash until the gap closes
      if (this.orphans.size < MAX_ORPHANS) this.orphans.set(block.height, block);
      if (block.height > this.bestKnown) { this.bestKnown = block.height; this.emitStatus(); }
      return false;
    }

    const prev = this.chain.get(this.syncedHeight);
    if (!prev) return false;
    // Simulate transfer effects on scratch copies of the account tables so
    // that (a) intra-block nonce/balance effects are visible to later txs and
    // (b) a failed block leaves state untouched (all-or-nothing).
    const simBalances = new Map(this.balances);
    const simNonces = new Map(this.nonces);
    const verdict = verifyChainBlock(block, {
      prev,
      windowStart: this.chain.get(block.height - WQD_RETARGET_INTERVAL) ?? null,
      recentTimestamps: this.recentTimestamps(),
      applyTransfer: (tx) => {
        if (!Number.isInteger(tx.amount) || tx.amount < 1) return 'bad transfer amount';
        if (!Number.isInteger(tx.fee) || tx.fee < WQD_MIN_TX_FEE) return 'bad transfer fee';
        const expected = simNonces.get(tx.fromAddress) ?? 0;
        if (tx.nonce !== expected) return `nonce mismatch (expected ${expected}, got ${tx.nonce})`;
        const amount = BigInt(tx.amount);
        const fee = BigInt(tx.fee);
        const bal = simBalances.get(tx.fromAddress) ?? 0n;
        if (bal < amount + fee) return 'overspend';
        simBalances.set(tx.fromAddress, bal - amount - fee);
        simBalances.set(tx.toAddress, (simBalances.get(tx.toAddress) ?? 0n) + amount);
        simNonces.set(tx.fromAddress, expected + 1);
        return null;
      },
    });
    if (!verdict.ok) {
      // Invalid per consensus — reject, and SAY IT ON THE PANEL (one-shot per
      // height+reason): a silent rejection is exactly how the #1000 stall
      // went undiagnosed in the field. Every peer re-serves the same block on
      // every probe, so without the one-shot guard the ring buffer is spam.
      console.warn('[wqdWatcher] rejected block', block.height, verdict.error);
      const key = `${block.height}:${verdict.error}`;
      if (remoteId && !this.rejectLogged.has(key)) {
        this.rejectLogged.add(key);
        this.logDiag(`rejected block #${block.height}: ${verdict.error} — consensus divergence, not a network issue`);
        this.emitStatus();
      }
      return false;
    }

    this.seenBlocks.add(block.hash);
    this.balances = simBalances; // commit the block's transfers
    this.nonces = simNonces;
    this.applyBlock(block);
    this.syncedHeight = block.height;
    this.bestKnown = Math.max(this.bestKnown, block.height);
    this.lastProgressAt = Date.now();
    // Advertise the fresh tip in MQTT presence announces — peers behind us
    // see the height within one cadence and re-sync even when nobody mines.
    this.mqtt?.setAnnouncedTip({ height: block.height, hash: block.hash });
    if (block.height % 64 === 0) void this.persist(); // checkpoint cadence

    // A committed block is cryptographic proof the sender holds the honest
    // chain — upgrade hello-less connections (same-device hello race) to
    // verified so the sync driver will keep pulling from them.
    if (remoteId && !this.verified.has(remoteId)) {
      this.verified.add(remoteId);
      if (this.phase !== 'linked') this.phase = 'linked';
      this.logDiag(`peer ${remoteId} verified implicitly via valid chain data`);
    }
    this.emitStatus();

    // drain any orphans that now extend the chain
    for (;;) {
      const next = this.orphans.get(this.syncedHeight + 1);
      if (!next) break;
      this.orphans.delete(next.height);
      this.handleBlock(next, remoteId);
    }
    return true;
  }

  /**
   * Book a verified block: coinbase + PoP rewards land here; transfers were
   * already committed by the simulate-and-commit step in handleBlock.
   */
  private applyBlock(block: WqdBlock): void {
    this.chain.set(block.height, block);

    const bump = (addr: string, delta: bigint): void => {
      this.balances.set(addr, (this.balances.get(addr) ?? 0n) + delta);
    };
    const cb = blockCoinbase(block);
    if (cb) bump(cb.toAddress, BigInt(Number(cb.amount)));
    for (const p of block.popTransfers) bump(p.address, BigInt(Number(p.amount)));

    if (this.seenBlocks.size > 4096) this.seenBlocks.clear(); // cheap to re-see
  }
}
