// ─────────────────────────────────────────────────────────────────────────────
// NeonTube — fragment stage: gas-discharge light tubes for X / O / superposed
// marks. Hot core, fresnel rim halo, dropout flicker, birth flash.
// uQuantum blends cyan↔magenta rapidly for unresolved superpositions.
// ─────────────────────────────────────────────────────────────────────────────

uniform float uTime;
uniform vec3 uColorA;
uniform vec3 uColorB;
uniform float uBirth;     // 0 → just spawned, 1 → settled (drives flash/grow)
uniform float uIntensity; // global brightness scalar
uniform float uQuantum;   // 0 = solid mark, 1 = superposition shimmer
uniform float uSeed;

varying vec3 vNormal;
varying vec3 vViewDir;
varying vec2 vUv;
varying vec3 vLocalPos;

float xenHash(vec3 p) {
  p = fract(p * 0.3183099 + vec3(0.1, 0.17, 0.13));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float xenNoise(vec3 p) {
  vec3 i = floor(p);
  vec3 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float n000 = xenHash(i);
  float n100 = xenHash(i + vec3(1.0, 0.0, 0.0));
  float n010 = xenHash(i + vec3(0.0, 1.0, 0.0));
  float n110 = xenHash(i + vec3(1.0, 1.0, 0.0));
  float n001 = xenHash(i + vec3(0.0, 0.0, 1.0));
  float n101 = xenHash(i + vec3(1.0, 0.0, 1.0));
  float n011 = xenHash(i + vec3(0.0, 1.0, 1.0));
  float n111 = xenHash(i + vec3(1.0, 1.0, 1.0));
  return mix(
    mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y),
    mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y),
    f.z
  );
}

float xenFresnel(vec3 normal, vec3 viewDir, float power) {
  return pow(1.0 - abs(dot(normalize(normal), normalize(viewDir))), power);
}

float xenFlicker(float time, float seed) {
  float n = xenNoise(vec3(time * 6.0, seed, seed * 0.37));
  float dip = step(0.93, n) * 0.55;
  return 1.0 - dip;
}

void main() {
  // Superpositions oscillate identity several times per second.
  float mixT = uQuantum > 0.5 ? 0.5 + 0.5 * sin(uTime * 9.0 + uSeed * 20.0) : 0.0;
  vec3 base = mix(uColorA, uColorB, mixT);

  float fresnel = xenFresnel(vNormal, vViewDir, 2.2);
  float core = 1.0 - fresnel;

  // Birth flash: a 3x overdrive that decays as uBirth approaches 1.
  float flash = (1.0 - uBirth) * 2.0;

  float flicker = xenFlicker(uTime, uSeed);
  // Quantum states are unstable: stronger noise-driven brightness wobble.
  float quantumWobble = uQuantum > 0.5 ? 0.35 * xenNoise(vec3(uTime * 14.0, uSeed, 1.7)) : 0.0;

  vec3 color = base * (core * 1.15 + fresnel * 2.4 + flash + quantumWobble) * uIntensity * flicker;
  float alpha = clamp(core * 0.95 + fresnel * 0.85, 0.0, 1.0);

  gl_FragColor = vec4(color, alpha);
}
