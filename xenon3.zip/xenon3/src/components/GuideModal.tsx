// ─────────────────────────────────────────────────────────────────────────────
// GuideModal — the English "HOW TO PLAY" manual.
// Auto-opens on the player's very first visit (persisted in localStorage) and
// can be re-opened any time from the connect screen's GUIDE button.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React from 'react';
import { motion } from 'framer-motion';

export const GUIDE_SEEN_KEY = 'xenon3:guide_seen';

interface GuideSection {
  step: string;
  title: string;
  accent: string;
  body: React.ReactNode;
}

const SECTIONS: GuideSection[] = [
  {
    step: '01',
    title: 'LINK YOUR WALLET',
    accent: 'text-xenon-cyan',
    body: (
      <>
        Xenon3 never creates wallets. Open the{' '}
        <span className="text-xenon-cyan">WebQuid terminal</span>, copy your key from{' '}
        <span className="text-white">WALLET → Export / Backup</span> and paste it into the import
        box. Your key stays on this device — it only signs your moves locally.
      </>
    ),
  },
  {
    step: '02',
    title: 'START A MATCH',
    accent: 'text-xenon-magenta',
    body: (
      <>
        <span className="text-white">CREATE ROOM</span> and send the 6-letter code to a friend,{' '}
        <span className="text-white">JOIN</span> with their code, or hit{' '}
        <span className="text-white">QUICK MATCH</span> for a random rival. Everything runs
        serverless over WebRTC — no accounts, no game server.
      </>
    ),
  },
  {
    step: '03',
    title: 'WIN THE LINE',
    accent: 'text-xenon-cyan',
    body: (
      <>
        Take turns dropping X and O on the floating 3×3 arena — first to complete a row, column or
        diagonal wins. You have <span className="text-white">30 seconds</span> per turn; run out of
        time and the turn passes to your rival.
      </>
    ),
  },
  {
    step: '04',
    title: 'BURN WQD ON POWER-UPS',
    accent: 'text-xenon-amber',
    body: (
      <>
        Stock charges in the <span className="text-white">ARMORY</span> by burning WQD utility
        credits: <span className="text-white">Quantum Hack 1</span> (override a rival mark),{' '}
        <span className="text-white">Neon Shield 0.5</span> (protect one of yours),{' '}
        <span className="text-white">Time Dilation 1.5</span> (freeze the rival clock),{' '}
        <span className="text-white">Quantum Entangle 0.8</span> (drop a superposition that is both
        X and O until observed). Collapse your own superposition for 0.3 WQD.
      </>
    ),
  },
  {
    step: '05',
    title: 'PROVABLY FAIR',
    accent: 'text-xenon-ice',
    body: (
      <>
        Every move, chat line and WQD burn is an ECDSA-signed envelope in a tamper-evident hash
        chain. Both browsers replay and verify the full history — cheating is cryptographically
        impossible.
      </>
    ),
  },
];

export default function GuideModal({ onClose }: { onClose: () => void }): React.JSX.Element {
  const dismiss = (): void => {
    try {
      window.localStorage.setItem(GUIDE_SEEN_KEY, '1');
    } catch {
      /* private mode — the modal simply re-appears next visit */
    }
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-void/80 p-4 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-label="How to play Xenon3"
    >
      <motion.div
        initial={{ opacity: 0, y: 32, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 24, scale: 0.97 }}
        transition={{ type: 'spring', stiffness: 260, damping: 26 }}
        className="glass flex max-h-[86dvh] w-full max-w-lg flex-col overflow-hidden border-xenon-cyan/25"
      >
        {/* header */}
        <div className="border-b border-white/10 p-5 pb-4 text-center">
          <div className="font-mono text-[9px] tracking-[0.4em] text-xenon-magenta">
            FIELD MANUAL // PROTOCOL 3×3
          </div>
          <h2 className="mt-2 font-display text-2xl font-black tracking-[0.12em] text-white">
            HOW TO PLAY <span className="text-xenon-cyan">XENON3</span>
          </h2>
        </div>

        {/* scrollable body */}
        <div className="min-h-0 flex-1 overflow-y-auto p-5 pt-4">
          <ol className="space-y-4">
            {SECTIONS.map((section) => (
              <li key={section.step} className="flex gap-3">
                <span
                  className={`glass mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg font-display text-[11px] font-black ${section.accent}`}
                >
                  {section.step}
                </span>
                <div className="min-w-0">
                  <div className={`font-display text-xs font-bold tracking-[0.2em] ${section.accent}`}>
                    {section.title}
                  </div>
                  <p className="mt-1 text-[13px] leading-relaxed text-ghost">{section.body}</p>
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-5 rounded-xl border border-white/10 bg-black/30 p-3 text-center font-mono text-[10px] leading-relaxed text-ghost/80">
            WQD is an in-game utility credit from the WebQuid mining ecosystem. No purchases · no
            cash-out · no gambling.
          </div>
        </div>

        {/* footer */}
        <div className="border-t border-white/10 p-4">
          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={dismiss}
            className="w-full rounded-xl border border-xenon-cyan/60 bg-xenon-cyan/15 px-6 py-3 font-display text-sm font-bold tracking-[0.25em] text-xenon-cyan shadow-neon-c transition hover:bg-xenon-cyan/30"
          >
            GOT IT — LET&apos;S PLAY
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}
