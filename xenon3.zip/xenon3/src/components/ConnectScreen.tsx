// ─────────────────────────────────────────────────────────────────────────────
// ConnectScreen — animated landing gate. Xenon3 never mints wallets: players
// connect a REAL WebQuid wallet (imported key / same-device platform key) or
// an injected EIP-1193 wallet. The page itself teaches where to get one.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useGameStore } from '../store/useGameStore';
import { injectedProvider } from '../lib/wallet';
import { DEFAULT_TERMINAL_URL, createTabSparringKey, loadTerminalUrl } from '../lib/webquid';
import GuideModal, { GUIDE_SEEN_KEY } from './GuideModal';

// ── Animated background: drifting neon blobs + perspective grid ──────────────

function AnimatedBackdrop(): React.JSX.Element {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {/* perspective grid floor */}
      <div
        className="absolute inset-x-0 bottom-0 h-1/2 opacity-[0.13]"
        style={{
          background:
            'linear-gradient(transparent 0%, rgba(255,43,214,0.35) 100%), repeating-linear-gradient(90deg, rgba(0,240,255,0.35) 0 1px, transparent 1px 64px), repeating-linear-gradient(0deg, rgba(0,240,255,0.35) 0 1px, transparent 1px 42px)',
          transform: 'perspective(500px) rotateX(58deg) scale(1.6)',
          transformOrigin: 'bottom',
        }}
      />
      {/* cyan blob */}
      <motion.div
        className="absolute -left-24 top-1/4 h-72 w-72 rounded-full"
        style={{ background: 'radial-gradient(circle, rgba(0,240,255,0.22) 0%, transparent 70%)' }}
        animate={{ x: [0, 50, -20, 0], y: [0, -35, 25, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }}
      />
      {/* magenta blob */}
      <motion.div
        className="absolute -right-20 top-10 h-80 w-80 rounded-full"
        style={{ background: 'radial-gradient(circle, rgba(255,43,214,0.18) 0%, transparent 70%)' }}
        animate={{ x: [0, -45, 30, 0], y: [0, 40, -25, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
      />
      {/* violet blob */}
      <motion.div
        className="absolute bottom-10 left-1/3 h-64 w-64 rounded-full"
        style={{ background: 'radial-gradient(circle, rgba(123,43,255,0.16) 0%, transparent 70%)' }}
        animate={{ x: [0, 35, -30, 0], y: [0, -25, 20, 0] }}
        transition={{ duration: 26, repeat: Infinity, ease: 'easeInOut' }}
      />
      {/* rising particles */}
      {[...Array(10)].map((_, i) => (
        <motion.span
          key={i}
          className="absolute h-1 w-1 rounded-full bg-xenon-cyan/70"
          style={{ left: `${8 + i * 9}%`, bottom: '-2%' }}
          animate={{ y: [0, -420 - (i % 4) * 90], opacity: [0, 1, 0] }}
          transition={{
            duration: 7 + (i % 5) * 1.6,
            repeat: Infinity,
            delay: i * 0.9,
            ease: 'linear',
          }}
        />
      ))}
    </div>
  );
}

// ── Animated emblem: counter-rotating orbit rings around a pulsing X/O ───────

function Emblem(): React.JSX.Element {
  // Duel tease: at random moments the X and O trade places in a fast snap and
  // jump straight back — a glimpse of the fight inside the emblem. A chained
  // timeout (not an interval) keeps the rhythm unpredictable.
  const [swapped, setSwapped] = useState(false);
  useEffect(() => {
    let alive = true;
    let swapTimer = 0;
    let backTimer = 0;
    const schedule = (): void => {
      swapTimer = window.setTimeout(() => {
        if (!alive) return;
        setSwapped(true);
        backTimer = window.setTimeout(() => {
          if (!alive) return;
          setSwapped(false);
          schedule();
        }, 650);
      }, 3200 + Math.random() * 4800);
    };
    schedule();
    return () => {
      alive = false;
      window.clearTimeout(swapTimer);
      window.clearTimeout(backTimer);
    };
  }, []);

  // Position is handled by `layout` on these wrappers (flex order swap), the
  // inner spans keep their breathing pulse — one job per layer, so the two
  // animations never fight over the same transition.
  const swapSpring = { type: 'spring', stiffness: 620, damping: 32 } as const;

  return (
    <div className="relative mx-auto flex h-36 w-36 items-center justify-center">
      <motion.div
        className="absolute inset-0 rounded-full border border-dashed border-xenon-cyan/40"
        animate={{ rotate: 360 }}
        transition={{ duration: 24, repeat: Infinity, ease: 'linear' }}
      />
      <motion.div
        className="absolute inset-3 rounded-full border border-xenon-magenta/40"
        style={{ borderStyle: 'dotted' }}
        animate={{ rotate: -360 }}
        transition={{ duration: 18, repeat: Infinity, ease: 'linear' }}
      />
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{ boxShadow: '0 0 45px rgba(0,240,255,0.25), inset 0 0 35px rgba(255,43,214,0.18)' }}
        animate={{ opacity: [0.6, 1, 0.6] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.span layout transition={swapSpring} style={{ order: swapped ? 1 : 0 }} className="flex">
        <motion.span
          className="font-display text-5xl font-black text-xenon-cyan"
          style={{ textShadow: '0 0 24px rgba(0,240,255,0.9)' }}
          animate={{
            scale: [1, 1.12, 1],
            rotate: swapped ? [0, -18, 0] : 0,
          }}
          transition={{
            scale: { duration: 2.2, repeat: Infinity, ease: 'easeInOut' },
            rotate: { duration: 0.5, ease: 'easeInOut' },
          }}
        >
          X
        </motion.span>
      </motion.span>
      <motion.span layout transition={swapSpring} style={{ order: swapped ? 0 : 1 }} className="flex">
        <motion.span
          className="font-display text-5xl font-black text-xenon-magenta"
          style={{ textShadow: '0 0 24px rgba(255,43,214,0.9)' }}
          animate={{
            scale: [1.12, 1, 1.12],
            rotate: swapped ? [0, 18, 0] : 0,
          }}
          transition={{
            scale: { duration: 2.2, repeat: Infinity, ease: 'easeInOut' },
            rotate: { duration: 0.5, ease: 'easeInOut' },
          }}
        >
          O
        </motion.span>
      </motion.span>
    </div>
  );
}

// ── Section wrapper with scroll-reveal ───────────────────────────────────────

function Reveal({
  children,
  delay = 0,
  className = '',
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}): React.JSX.Element {
  return (
    <motion.div
      initial={{ opacity: 0, y: 26 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.6, delay, ease: 'easeOut' }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const stepBadge =
  'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-xenon-cyan/50 bg-xenon-cyan/10 font-display text-sm font-bold text-xenon-cyan shadow-neon-c';

export default function ConnectScreen(): React.JSX.Element {
  const walletStatus = useGameStore((s) => s.walletStatus);
  const walletError = useGameStore((s) => s.walletError);
  const connectWallet = useGameStore((s) => s.connectWallet);
  const importWalletKey = useGameStore((s) => s.importWalletKey);
  const [hasInjected, setHasInjected] = useState(false);
  const [importDraft, setImportDraft] = useState('');
  const [importBusy, setImportBusy] = useState(false);
  // The English field manual opens automatically on the very first visit.
  const [guideOpen, setGuideOpen] = useState(false);
  // Terminal address comes from webquid.config.json (editable without rebuild).
  const [terminalUrl, setTerminalUrl] = useState(DEFAULT_TERMINAL_URL);

  useEffect(() => {
    setHasInjected(injectedProvider() !== null);
    void loadTerminalUrl().then(setTerminalUrl);
    try {
      if (!window.localStorage.getItem(GUIDE_SEEN_KEY)) setGuideOpen(true);
    } catch {
      /* storage unavailable — keep the manual closed, the GUIDE button works */
    }
  }, []);

  const connecting = walletStatus === 'connecting';

  const onImport = async (): Promise<void> => {
    if (importBusy) return;
    setImportBusy(true);
    try {
      const ok = await importWalletKey(importDraft);
      if (ok) setImportDraft('');
    } finally {
      setImportBusy(false);
    }
  };

  return (
    <div className="relative z-10 min-h-dvh overflow-x-hidden">
      <AnimatedBackdrop />

      {/* reopen the field manual any time */}
      <button
        type="button"
        onClick={() => setGuideOpen(true)}
        className="glass fixed right-4 top-[max(1rem,env(safe-area-inset-top))] z-30 px-3 py-2 font-display text-[10px] font-bold tracking-[0.25em] text-ghost transition hover:border-xenon-cyan/60 hover:text-xenon-cyan"
      >
        GUIDE
      </button>

      <AnimatePresence>{guideOpen && <GuideModal onClose={() => setGuideOpen(false)} />}</AnimatePresence>

      <div className="relative mx-auto flex min-h-dvh w-full max-w-2xl flex-col items-center px-5 pb-16 pt-[max(3rem,env(safe-area-inset-top))]">
        {/* ── Hero ─────────────────────────────────────────────────────────── */}
        <Emblem />
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.6 }}
          className="mt-5 text-center"
        >
          <div className="select-none font-mono text-[11px] tracking-[0.5em] text-xenon-magenta animate-flicker">
            WEBQUID UTILITY SINK // PROTOCOL 3×3
          </div>
          <h1
            className="mt-2 select-none font-display text-[clamp(3rem,11vw,6.5rem)] font-black leading-none tracking-[0.12em] text-white"
            style={{
              textShadow:
                '0 0 18px rgba(0,240,255,0.85), 0 0 60px rgba(0,240,255,0.4), 0 0 120px rgba(255,43,214,0.35)',
            }}
          >
            XENON<span className="text-xenon-cyan">3</span>
          </h1>
          <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-ghost">
            Holographic tic-tac-toe over trustless WebRTC. Spend mined{' '}
            <span className="text-xenon-cyan">WQD</span> on quantum hacks, neon shields and time
            dilation — every move cryptographically signed.
          </p>
        </motion.div>

        {/* ── Wallet gate ──────────────────────────────────────────────────── */}
        <Reveal delay={0.1} className="mt-9 w-full max-w-md">
          <div className="glass border-xenon-cyan/25 p-5">
            <div className="text-center font-display text-[11px] font-bold tracking-[0.25em] text-white">
              LINK YOUR <span className="text-xenon-cyan">WEBQUID WALLET</span>
            </div>
            <p className="mt-1.5 text-center text-[11px] leading-relaxed text-ghost">
              Xenon3 never creates wallets — it only links an existing one. Your key never leaves
              this device.
            </p>

            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={connecting}
              onClick={() => void connectWallet('webquid')}
              className="mt-4 w-full whitespace-nowrap rounded-xl border border-xenon-cyan/60 bg-xenon-cyan/15 px-2 py-3.5 font-display text-[clamp(0.58rem,3vw,0.875rem)] font-bold tracking-[0.1em] text-xenon-cyan shadow-neon-c transition hover:bg-xenon-cyan/30 disabled:opacity-40 sm:px-8 sm:tracking-[0.25em]"
            >
              {connecting ? 'LINKING WALLET…' : 'CONNECT WEBQUID WALLET'}
            </motion.button>

            <div className="my-4 flex items-center gap-3">
              <span className="h-px flex-1 bg-white/10" />
              <span className="font-mono text-[9px] tracking-[0.25em] text-ghost/60">
                OR IMPORT YOUR KEY
              </span>
              <span className="h-px flex-1 bg-white/10" />
            </div>

            <input
              type="password"
              value={importDraft}
              onChange={(event) => setImportDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter') void onImport();
              }}
              placeholder="64 hex characters (0x optional)"
              autoComplete="off"
              spellCheck={false}
              aria-label="WebQuid wallet key"
              className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2.5 font-mono text-[11px] text-white placeholder:text-ghost/40 outline-none transition focus:border-xenon-cyan/60"
            />
            <button
              type="button"
              onClick={() => void onImport()}
              disabled={importBusy || importDraft.trim().length === 0}
              className="mt-2.5 w-full rounded-lg border border-xenon-magenta/50 bg-xenon-magenta/12 px-4 py-2.5 font-display text-[11px] font-bold tracking-[0.2em] text-xenon-pink transition hover:bg-xenon-magenta/25 disabled:cursor-not-allowed disabled:opacity-30"
            >
              {importBusy ? 'VERIFYING…' : 'IMPORT & CONNECT'}
            </button>

            {hasInjected && (
              <button
                type="button"
                disabled={connecting}
                onClick={() => void connectWallet('injected')}
                className="mt-2.5 w-full rounded-lg border border-white/15 bg-white/5 px-4 py-2.5 font-display text-[10px] font-bold tracking-[0.2em] text-ghost transition hover:border-xenon-cyan/40 hover:text-xenon-cyan disabled:opacity-30"
              >
                BROWSER WALLET (METAMASK & CO.)
              </button>
            )}

            <div className="my-4 flex items-center gap-3">
              <span className="h-px flex-1 bg-white/10" />
              <span className="font-mono text-[9px] tracking-[0.25em] text-ghost/60">
                LOCAL DUEL
              </span>
              <span className="h-px flex-1 bg-white/10" />
            </div>

            <button
              type="button"
              disabled={connecting}
              onClick={() => {
                // This tab gets its own throwaway identity (sessionStorage) so
                // it can duel the shared wallet in another tab. 0 WQD, gone
                // when the tab closes — no wallet is minted, no credit granted.
                if (createTabSparringKey()) void connectWallet('webquid');
              }}
              className="w-full rounded-lg border border-dashed border-xenon-cyan/35 bg-transparent px-4 py-2.5 font-display text-[10px] font-bold tracking-[0.18em] text-xenon-cyan/80 transition hover:border-xenon-cyan/70 hover:bg-xenon-cyan/10 hover:text-xenon-cyan disabled:opacity-30"
            >
              SPARRING KEY — THIS TAB ONLY
            </button>
            <p className="mt-1.5 text-center font-mono text-[9px] leading-relaxed text-ghost/50">
              two tabs share one wallet and can't duel — open a sparring key in ONE tab, keep the
              real wallet in the other
            </p>

            <AnimatePresence>
              {walletError && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="mt-3 rounded-lg border border-red-500/40 bg-red-950/30 px-4 py-2.5 font-mono text-[10px] leading-relaxed text-red-300">
                    {walletError}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </Reveal>

        {/* ── How to get a wallet ──────────────────────────────────────────── */}
        <Reveal delay={0.05} className="mt-8 w-full max-w-md">
          <div className="glass border-xenon-magenta/25 p-5">
            <div className="font-display text-[11px] font-bold tracking-[0.25em] text-white">
              NO WALLET YET? <span className="text-xenon-magenta">GET ONE IN 60 SECONDS</span>
            </div>
            <ol className="mt-4 space-y-4">
              <li className="flex items-start gap-3">
                <span className={stepBadge}>1</span>
                <div className="text-[12px] leading-relaxed text-ghost">
                  Open the official{' '}
                  <a
                    href={terminalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="font-bold text-xenon-cyan underline decoration-xenon-cyan/40 underline-offset-4 transition hover:text-xenon-ice"
                  >
                    WebQuid terminal
                  </a>{' '}
                  and let the node boot up.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className={stepBadge}>2</span>
                <div className="text-[12px] leading-relaxed text-ghost">
                  Go to the <span className="font-bold text-white">WALLET</span> page — your node
                  already owns a key there. Use{' '}
                  <span className="font-bold text-white">Export / Backup</span> to reveal it
                  (starts with <span className="font-mono text-xenon-ice">0x</span>).
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className={stepBadge}>3</span>
                <div className="text-[12px] leading-relaxed text-ghost">
                  Paste the key into the box above and hit{' '}
                  <span className="font-bold text-white">IMPORT &amp; CONNECT</span>. Your WQD
                  balance and ledger follow your address automatically.
                </div>
              </li>
            </ol>
            <div className="mt-4 rounded-lg border border-white/10 bg-black/20 px-3 py-2 font-mono text-[9px] leading-relaxed text-ghost/70">
              The key is stored only in this browser's local storage and is used exclusively to
              sign your moves and WQD burns. It is never transmitted anywhere.
            </div>
          </div>
        </Reveal>

        {/* ── How it plays ─────────────────────────────────────────────────── */}
        <Reveal className="mt-8 w-full max-w-md">
          <div className="grid grid-cols-2 gap-2.5">
            {[
              ['SIGNED DUELS', 'Every move, chat and burn is an ECDSA-signed envelope in a tamper-evident hash chain.'],
              ['WQD POWER-UPS', 'Quantum Hack 1 · Neon Shield 0.5 · Time Dilation 1.5 · Entangle 0.8 WQD.'],
              ['SUPERPOSITION', 'A quantum tile is both X and O until someone pays to observe — or lock — it.'],
              ['SERVERLESS P2P', 'Quick Match and room codes run on raw WebRTC. No game server, no accounts.'],
            ].map(([title, body], i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.5 }}
                className="glass px-3.5 py-3"
              >
                <div className="font-display text-[10px] font-bold tracking-[0.2em] text-xenon-cyan">
                  {title}
                </div>
                <div className="mt-1 text-[10.5px] leading-relaxed text-ghost">{body}</div>
              </motion.div>
            ))}
          </div>
        </Reveal>

        <div className="mt-10 text-center font-mono text-[9px] leading-relaxed tracking-wider text-ghost/50">
          WQD is an in-game utility credit from the WebQuid mining ecosystem.
          <br />
          No purchases · no cash-out · no gambling — signatures only prove your moves.
        </div>
      </div>
    </div>
  );
}
