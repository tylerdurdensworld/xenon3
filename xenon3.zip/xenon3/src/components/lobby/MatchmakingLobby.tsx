// ─────────────────────────────────────────────────────────────────────────────
// MatchmakingLobby — WQD sync, loadout review, and the two ways into a match:
//   • QUICK MATCH — serverless global queue (shared rendezvous peer id).
//   • PRIVATE MATCH — host a room code or dial a friend's code directly.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useGameStore } from '../../store/useGameStore';
import SoundToggle from '../SoundToggle';
import { randomRoomCode } from '../../lib/crypto';
import { POWER_UP_COST, formatWqd, formatWqdBalance, shortAddress, type PowerUpKind } from '../../types';

const ROOM_CODE_PATTERN = /^[A-Z2-9]{6}$/;

// ── WQD balance + sync ───────────────────────────────────────────────────────

function WqdSyncCard(): React.JSX.Element {
  const balance = useGameStore((s) => s.selfBalance);
  const ledgerLength = useGameStore((s) => s.ledger.length);
  const lastSyncCount = useGameStore((s) => s.lastSyncCount);
  const syncWebquid = useGameStore((s) => s.syncWebquid);
  const address = useGameStore((s) => s.address);
  const walletSource = useGameStore((s) => s.walletSource);
  const signerMode = useGameStore((s) => s.signer?.mode);
  const hasWqdIdentity = useGameStore((s) => !!s.signer?.wqdAddress);

  // Sync is automatic: on lobby entry, and again whenever the tab comes back
  // (the mining grid may have issued credits while the player was away).
  useEffect(() => {
    void syncWebquid();
    const onVisible = (): void => {
      if (document.visibilityState === 'visible') void syncWebquid();
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onVisible);
    };
  }, [syncWebquid]);

  // Which identity are we playing as — provenance matters to the player.
  const identityLabel =
    signerMode === 'injected'
      ? 'browser wallet'
      : walletSource === 'sparring'
        ? 'sparring key · this tab'
        : walletSource === 'imported'
          ? 'imported WebQuid wallet'
          : 'WebQuid wallet';

  return (
    <div className="glass border-xenon-cyan/25 p-5">
      <div className="mb-3 flex items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="h-2 w-2 shrink-0 rounded-full bg-xenon-cyan shadow-neon-c" />
          <span className="truncate font-mono text-xs text-white/90">{shortAddress(address ?? '')}</span>
        </div>
        <span className="flex shrink-0 items-center gap-1.5">
          <span className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] uppercase tracking-widest text-ghost">
            {identityLabel}
          </span>
          <SoundToggle />
        </span>
      </div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="text-[10px] uppercase tracking-[0.3em] text-ghost">WebQuid balance</div>
          <div
            className="mt-1 break-words font-display text-[clamp(1.5rem,6vw,2.25rem)] font-black leading-tight text-xenon-cyan"
            style={{ textShadow: '0 0 22px rgba(0,240,255,0.55)' }}
            title={`${formatWqd(balance)} WQD (exact)`}
          >
            {formatWqdBalance(balance)}
            <span className="ml-2 text-sm font-bold tracking-[0.2em] text-ghost">WQD</span>
          </div>
        </div>
      </div>
      {hasWqdIdentity && <SyncProgress />}
      <div className="mt-3 font-mono text-[10px] leading-relaxed text-ghost/80">
        {lastSyncCount > 0
          ? `+${lastSyncCount} signed credit${lastSyncCount > 1 ? 's' : ''} imported from the WebQuid mining grid.`
          : hasWqdIdentity
            ? 'Coins never leave your wallet: the node replays the chain and mirrors your balance automatically.'
            : ledgerLength > 0
              ? 'Ledger verified — no new attestations on the mining grid.'
              : 'Import your WebQuid wallet to mirror your on-chain balance.'}
      </div>
    </div>
  );
}

// ── Animated chain-sync progress ─────────────────────────────────────────────
// The watcher verifies every block from genesis; on a long chain this takes a
// while, so the bar keeps the three stages legible: link → verify → mirrored.

function SyncProgress(): React.JSX.Element {
  const chainBalance = useGameStore((s) => s.chainBalance);
  const networkHeight = useGameStore((s) => s.networkHeight);
  const bestKnownHeight = useGameStore((s) => s.bestKnownHeight);
  const watcherPeers = useGameStore((s) => s.watcherPeers);
  const watcherPhase = useGameStore((s) => s.watcherPhase);
  const watcherError = useGameStore((s) => s.watcherError);
  const watcherIdentity = useGameStore((s) => s.watcherIdentity);
  const watcherDialed = useGameStore((s) => s.watcherDialed);
  const watcherAnswered = useGameStore((s) => s.watcherAnswered);
  const watcherInbound = useGameStore((s) => s.watcherInbound);
  const watcherDiag = useGameStore((s) => s.watcherDiag);

  const brokerDown = watcherPhase === 'broker-error';
  const linkingRaw = !brokerDown && (watcherPeers === 0 || bestKnownHeight === 0);
  // Peer churn must not collapse a healthy bar back to "LINKING…": once any
  // link has existed this session, a brief zero-peer moment is a quiet
  // RE-LINK note while the bar holds its last value.
  const [everLinked, setEverLinked] = useState(false);
  useEffect(() => {
    if (!linkingRaw) setEverLinked(true);
  }, [linkingRaw]);
  const linking = linkingRaw && !everLinked;
  const relinking = linkingRaw && everLinked;
  const syncing = !linkingRaw && !brokerDown && networkHeight < bestKnownHeight;

  // Catch-up progress is measured from the height where THIS run started, so
  // a resumed snapshot reads 0→100 across the delta instead of snapping to a
  // misleading 99% and then jumping around. The displayed value never retreats
  // mid-run (peer tip announcements can move the denominator); it resets only
  // when a new run begins. A plain CSS transition keeps 5Hz updates smooth —
  // the old spring oscillated visibly under a constantly moving target.
  const anchorRef = React.useRef<number | null>(null);
  const [displayPct, setDisplayPct] = useState(0);
  useEffect(() => {
    if (brokerDown) {
      anchorRef.current = null;
      setDisplayPct(0);
      return;
    }
    if (linkingRaw) {
      if (!everLinked) {
        anchorRef.current = null;
        setDisplayPct(0);
      }
      return; // relinking: hold the last value
    }
    if (!syncing) {
      anchorRef.current = null;
      setDisplayPct(100);
      return;
    }
    if (anchorRef.current === null) anchorRef.current = networkHeight;
    const base = anchorRef.current;
    const pct = Math.min(
      100,
      Math.round(((networkHeight - base) / Math.max(1, bestKnownHeight - base)) * 100),
    );
    setDisplayPct((prev) => Math.max(prev, pct));
  }, [linkingRaw, everLinked, brokerDown, syncing, networkHeight, bestKnownHeight]);

  // If the sweep finds no miner at all, a bare "LINKING…" is indistinguishable
  // from a hang. After a grace period, say exactly what's missing and how to
  // fix it (the chain can only be mirrored from a live mainnet peer).
  // A broker failure skips the grace period: that hint shows immediately.
  const [showNoPeerHint, setShowNoPeerHint] = useState(false);
  useEffect(() => {
    if (!linking || watcherPeers > 0) {
      setShowNoPeerHint(false);
      return undefined;
    }
    const timer = window.setTimeout(() => setShowNoPeerHint(true), 20_000);
    return () => window.clearTimeout(timer);
  }, [linking, watcherPeers]);

  // spendable = mirrored credit − signed burns. Sum the burns straight from
  // the ledger (NOT chain−spendable — mid-sync that difference is just
  // not-yet-mirrored credit and would read as a giant fake spend).
  const ledgerEvents = useGameStore((s) => s.ledger);
  const spentInArena = ledgerEvents.reduce((sum, e) => (e.kind === 'BURN' ? sum + e.amount : sum), 0);

  return (
    <div className="mt-3 rounded-lg border border-white/10 bg-black/30 p-3">
      <div className="flex items-center justify-between font-mono text-[10px]">
        <span
          className={
            brokerDown
              ? 'text-red-300/90'
              : syncing
                ? 'text-amber-300/90'
                : linking || relinking
                  ? 'text-ghost'
                  : 'text-emerald-300/90'
          }
        >
          {brokerDown
            ? 'SIGNALING UNREACHABLE — RETRYING…'
            : linking
              ? 'LINKING TO MAINNET…'
              : relinking
                ? 'RELINKING TO MAINNET…'
                : syncing
                  ? `VERIFYING BLOCKS · #${networkHeight} / #${bestKnownHeight}`
                  : `chain verified · #${networkHeight}`}
        </span>
        <span className="text-ghost">
          {linking || relinking || brokerDown ? `${watcherPeers} peers` : `${displayPct}%`}
        </span>
      </div>

      {/* the bar itself: gradient fill + shimmer sweep, indeterminate while linking */}
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10">
        {linking ? (
          <motion.div
            className="h-full w-1/3 rounded-full bg-gradient-to-r from-xenon-cyan to-xenon-magenta"
            animate={{ x: ['-110%', '320%'] }}
            transition={{ duration: 1.3, repeat: Infinity, ease: 'easeInOut' }}
          />
        ) : (
          <div
            className="relative h-full rounded-full bg-gradient-to-r from-xenon-cyan via-xenon-ice to-xenon-magenta transition-[width] duration-500 ease-linear"
            style={{ width: `${displayPct}%` }}
          >
            {syncing && (
              <motion.span
                className="absolute inset-y-0 w-1/2 rounded-full"
                style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.45), transparent)' }}
                animate={{ x: ['-120%', '260%'] }}
                transition={{ duration: 1.1, repeat: Infinity, ease: 'linear' }}
              />
            )}
          </div>
        )}
      </div>

      {brokerDown && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-2 rounded border border-red-400/30 bg-red-400/5 px-2 py-1.5 font-mono text-[9px] leading-relaxed text-red-200/90"
        >
          cannot reach the PeerJS signaling cloud (0.peerjs.com:443)
          {watcherError ? ` — error: ${watcherError}` : ''}. check the network /
          disable ad-blocker or WebRTC-blocking extensions for this page; the
          watcher retries automatically every few seconds.
        </motion.div>
      )}

      {showNoPeerHint && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-2 rounded border border-amber-300/25 bg-amber-300/5 px-2 py-1.5 font-mono text-[9px] leading-relaxed text-amber-200/85"
        >
          no mainnet peer found yet — the chain can only be mirrored from a live node.
          keep your WebQuid terminal tab open WITH MINING RUNNING; if the terminal
          shows 0 H/s or "template idle", stop and restart mining there to wake its
          engine. the watcher speaks the terminal's full v2 handshake and meets it
          on BOTH transports (WebRTC slot ring + the public MQTT relay room the
          terminal itself uses), re-probing automatically every few seconds.
          (browser console shows [wqdWatcher] diagnostics.)
        </motion.div>
      )}

      {/* Phone-friendly diagnostics: devtools don't exist on mobile, so the
          watcher's own counters + recent events render right here — always
          available, before AND after linking. */}
      <details className="mt-2 rounded border border-white/10 bg-black/20 px-2 py-1.5 font-mono text-[9px] leading-relaxed text-ghost/80">
        <summary className="cursor-pointer select-none text-[9px] uppercase tracking-[0.2em] text-ghost">
          node diagnostics
        </summary>
        <div className="mt-1.5 space-y-0.5 break-all">
          <div>identity: {watcherIdentity ?? '— (not claimed yet)'}</div>
          <div>
            phase: {watcherPhase} · dialed: {watcherDialed} · answered: {watcherAnswered} · inbound:{' '}
            {watcherInbound} · verified: {watcherPeers}
          </div>
          {watcherDiag.length > 0 ? (
            watcherDiag.map((line) => <div key={line}>· {line}</div>)
          ) : (
            <div>· no watcher events yet</div>
          )}
        </div>
      </details>

      <div className="mt-2 flex items-center justify-between font-mono text-[10px]">
        <span className="text-ghost">on-chain · verified by full node</span>
        <motion.span
          key={chainBalance} // pulse on every mirrored increase
          initial={{ scale: 1.25, color: '#00f0ff' }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 18 }}
          className="max-w-[60%] truncate text-xenon-cyan/90"
          title={`${formatWqd(chainBalance)} WQD (exact)`}
        >
          {formatWqdBalance(chainBalance)} WQD
        </motion.span>
      </div>
      {/* Full accounting, visible at a glance: spendable = on-chain − burned.
          Burns are signed receipts every opponent verifies — the mined coins
          themselves stay in the wallet by design (utility credit, no cash-out). */}
      {spentInArena > 0 && (
        <div className="mt-1 flex items-center justify-between font-mono text-[10px]">
          <span className="text-ghost">spent in arena · signed burns</span>
          <span
            className="max-w-[60%] truncate text-xenon-magenta/90"
            title={`${formatWqd(spentInArena)} WQD burned on armory charges (exact)`}
          >
            −{formatWqdBalance(spentInArena)} WQD
          </span>
        </div>
      )}
    </div>
  );
}

// ── Power-up loadout strip ───────────────────────────────────────────────────

function InventoryStrip(): React.JSX.Element {
  const inventory = useGameStore((s) => s.selfInventory);
  const labels: Record<PowerUpKind, string> = {
    QUANTUM_HACK: 'HACK',
    NEON_SHIELD: 'SHIELD',
    TIME_DILATION: 'DILATE',
    QUANTUM_ENTANGLE: 'ENTANGLE',
  };
  return (
    <div className="grid grid-cols-4 gap-2">
      {(Object.keys(labels) as PowerUpKind[]).map((kind) => (
        <div key={kind} className="glass px-2 py-2 text-center">
          <div className="font-display text-lg font-bold text-white">{inventory[kind]}</div>
          <div className="text-[9px] tracking-[0.2em] text-ghost">{labels[kind]}</div>
          <div className="font-mono text-[9px] text-xenon-cyan/80">{formatWqd(POWER_UP_COST[kind])} WQD</div>
        </div>
      ))}
    </div>
  );
}

// ── Sync gate ────────────────────────────────────────────────────────────────
// Match buttons stay locked until the wallet mirror has FULLY caught up with
// the chain: entering a duel with a half-synced book would make both sides
// disagree on spendable WQD (and the peer audits our claims).

function useSyncReady(): boolean {
  const hasWqdIdentity = useGameStore((s) => !!s.signer?.wqdAddress);
  const watcherPeers = useGameStore((s) => s.watcherPeers);
  const bestKnownHeight = useGameStore((s) => s.bestKnownHeight);
  const networkHeight = useGameStore((s) => s.networkHeight);
  const watcherPhase = useGameStore((s) => s.watcherPhase);
  return (
    hasWqdIdentity &&
    watcherPhase !== 'broker-error' &&
    watcherPeers > 0 &&
    bestKnownHeight > 0 &&
    networkHeight >= bestKnownHeight
  );
}

function SyncGateHint(): React.JSX.Element {
  return (
    <div className="mt-2 text-center font-mono text-[9px] tracking-[0.2em] text-xenon-amber">
      WALLET SYNC INCOMPLETE — UNLOCKS AT 100%
    </div>
  );
}

// ── Quick Match: queue radar ─────────────────────────────────────────────────

function QuickMatchCard(): React.JSX.Element {
  const netApi = useGameStore((s) => s.netApi);
  const queueStatus = useGameStore((s) => s.queueStatus);
  const queueMessage = useGameStore((s) => s.queueMessage);
  const leaveMatch = useGameStore((s) => s.leaveMatch);
  const queueing = queueStatus !== 'idle';
  const ready = useSyncReady();

  return (
    <div className="glass border-xenon-magenta/25 p-5">
      <div className="flex items-center justify-between">
        <div className="font-display text-xs font-bold tracking-[0.25em] text-white">
          QUICK <span className="text-xenon-magenta">MATCH</span>
        </div>
        <span className="font-mono text-[9px] tracking-[0.2em] text-ghost">GLOBAL QUEUE</span>
      </div>

      <AnimatePresence mode="wait">
        {queueing ? (
          <motion.div
            key="queueing"
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.97 }}
            className="mt-4 text-center"
          >
            {/* radar pulse: three staggered expanding rings */}
            <div className="relative mx-auto flex h-16 w-16 items-center justify-center">
              {[0, 1, 2].map((ring) => (
                <motion.span
                  key={ring}
                  className="absolute inset-0 rounded-full border border-xenon-magenta/60"
                  initial={{ opacity: 0.8, scale: 0.35 }}
                  animate={{ opacity: 0, scale: 1.25 }}
                  transition={{ duration: 1.8, repeat: Infinity, delay: ring * 0.6, ease: 'easeOut' }}
                />
              ))}
              <span className="h-3 w-3 rounded-full bg-xenon-magenta shadow-neon-m" />
            </div>
            <div className="mt-3 min-h-[16px] font-mono text-[10px] tracking-[0.2em] text-xenon-pink">
              {queueMessage ?? 'SCANNING…'}
            </div>
            <button
              type="button"
              onClick={() => void leaveMatch()}
              className="mt-3 rounded-lg border border-white/15 bg-white/5 px-5 py-2 font-display text-[10px] font-bold tracking-[0.2em] text-ghost transition hover:border-xenon-magenta/50 hover:text-xenon-pink"
            >
              CANCEL SEARCH
            </button>
          </motion.div>
        ) : (
          <motion.button
            key="idle"
            type="button"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            disabled={!ready}
            onClick={() => netApi?.quickMatch()}
            className="mt-4 w-full rounded-xl border border-xenon-magenta/50 bg-xenon-magenta/15 px-6 py-3.5 font-display text-sm font-bold tracking-[0.25em] text-xenon-pink transition hover:bg-xenon-magenta/30 hover:shadow-neon-m disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-xenon-magenta/15 disabled:hover:shadow-none"
          >
            ENTER THE QUEUE
          </motion.button>
        )}
      </AnimatePresence>
      {!queueing && !ready && <SyncGateHint />}

      <div className="mt-3 font-mono text-[9px] leading-relaxed text-ghost/70">
        {queueing
          ? 'You are discoverable by every player in the queue right now.'
          : 'First free player online gets the link. No servers — the queue is a shared rendezvous key.'}
      </div>
    </div>
  );
}

// ── Private Match: host / join by code ───────────────────────────────────────

function PrivateMatchCard(): React.JSX.Element {
  const netApi = useGameStore((s) => s.netApi);
  const ready = useSyncReady();
  const [joinCode, setJoinCode] = useState('');

  const host = (): void => {
    netApi?.hostRoom(randomRoomCode());
  };

  const join = (): void => {
    const code = joinCode.trim().toUpperCase();
    if (!ROOM_CODE_PATTERN.test(code)) return;
    netApi?.joinRoom(code);
  };

  return (
    <div className="glass border-xenon-cyan/20 p-5">
      <div className="flex items-center justify-between">
        <div className="font-display text-xs font-bold tracking-[0.25em] text-white">
          PRIVATE <span className="text-xenon-cyan">MATCH</span>
        </div>
        <span className="font-mono text-[9px] tracking-[0.2em] text-ghost">FRIEND LINK</span>
      </div>

      <button
        type="button"
        onClick={host}
        disabled={!ready}
        className="mt-4 w-full rounded-xl border border-xenon-cyan/50 bg-xenon-cyan/15 px-6 py-3.5 font-display text-sm font-bold tracking-[0.25em] text-xenon-cyan transition hover:bg-xenon-cyan/30 hover:shadow-neon-c disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-xenon-cyan/15 disabled:hover:shadow-none"
      >
        CREATE ROOM
      </button>
      {!ready && <SyncGateHint />}

      <div className="mt-3 flex gap-2">
        <input
          value={joinCode}
          onChange={(event) =>
            setJoinCode(event.target.value.toUpperCase().replace(/[^A-Z2-9]/g, '').slice(0, 6))
          }
          onKeyDown={(event) => {
            if (event.key === 'Enter') join();
          }}
          placeholder="ROOM CODE"
          aria-label="Room code"
          className="min-w-0 flex-1 rounded-xl border border-white/15 bg-black/30 px-4 py-3 text-center font-mono text-lg tracking-[0.4em] text-white placeholder:text-ghost/40 outline-none transition focus:border-xenon-cyan/60"
        />
        <button
          type="button"
          onClick={join}
          disabled={!ready || !ROOM_CODE_PATTERN.test(joinCode)}
          className="shrink-0 rounded-xl border border-xenon-cyan/40 bg-xenon-cyan/10 px-6 font-display text-sm font-bold tracking-[0.25em] text-xenon-cyan transition hover:bg-xenon-cyan/25 disabled:cursor-not-allowed disabled:opacity-30"
        >
          JOIN
        </button>
      </div>
    </div>
  );
}

// ── Waiting / linking states ─────────────────────────────────────────────────

function WaitingCard(): React.JSX.Element {
  const roomCode = useGameStore((s) => s.roomCode);
  const role = useGameStore((s) => s.role);
  const matchmakingMode = useGameStore((s) => s.matchmakingMode);
  const leaveMatch = useGameStore((s) => s.leaveMatch);
  const quick = matchmakingMode === 'quick';
  const [copied, setCopied] = useState(false);

  // The one deliberate exception to the no-select chrome rule: tapping the
  // room code copies it straight to the clipboard.
  const copyRoomCode = (): void => {
    if (quick || !roomCode) return;
    void navigator.clipboard?.writeText(roomCode).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
    });
  };

  return (
    <motion.div
      key="waiting"
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96 }}
      className="glass p-6 text-center"
    >
      <div className="text-[10px] uppercase tracking-[0.3em] text-ghost">
        {quick
          ? 'rival linked — syncing ledgers'
          : role === 'host'
            ? 'room code — share it'
            : 'dialing host…'}
      </div>
      <button
        type="button"
        onClick={copyRoomCode}
        disabled={quick}
        title={quick ? undefined : 'Tap to copy the room code'}
        className={`mt-3 max-w-full break-all font-display font-black tracking-[0.18em] animate-pulse-glow sm:tracking-[0.3em] ${
          quick ? 'cursor-default text-2xl text-xenon-pink' : 'cursor-pointer text-[clamp(2rem,11vw,3rem)] text-xenon-ice transition hover:text-xenon-cyan'
        }`}
        style={{
          textShadow: quick
            ? '0 0 30px rgba(255,43,214,0.7)'
            : '0 0 30px rgba(0,240,255,0.7)',
        }}
      >
        {quick ? 'QUICK LINK' : copied ? 'COPIED ✓' : roomCode}
      </button>
      {!quick && (
        <div className="mt-1 font-mono text-[9px] tracking-[0.25em] text-ghost/70">
          TAP THE CODE TO COPY
        </div>
      )}
      <div className="mx-auto mt-4 h-1 w-40 overflow-hidden rounded-full bg-white/10">
        <motion.div
          className={`h-full w-1/3 rounded-full ${quick ? 'bg-xenon-magenta' : 'bg-xenon-cyan'}`}
          animate={{ x: ['-100%', '400%'] }}
          transition={{ duration: 1.4, repeat: Infinity, ease: 'easeInOut' }}
        />
      </div>
      <div className="mt-2 font-mono text-[10px] text-ghost">
        {quick
          ? 'exchanging signed handshakes…'
          : role === 'host'
            ? 'awaiting challenger…'
            : 'negotiating WebRTC handshake…'}
      </div>
      <button
        type="button"
        onClick={() => void leaveMatch()}
        className="mt-4 rounded-lg border border-white/15 bg-white/5 px-5 py-2 font-display text-[10px] font-bold tracking-[0.2em] text-ghost transition hover:border-xenon-magenta/50 hover:text-xenon-pink"
      >
        ABORT
      </button>
    </motion.div>
  );
}

// ── Root lobby ───────────────────────────────────────────────────────────────

export default function MatchmakingLobby(): React.JSX.Element {
  const netStatus = useGameStore((s) => s.netStatus);
  const netError = useGameStore((s) => s.netError);
  const phase = useGameStore((s) => s.phase);
  const queueStatus = useGameStore((s) => s.queueStatus);

  // The waiting card only replaces the action cards once a pairing handshake
  // is underway; while merely queueing, the Quick Match card owns the stage.
  const linking = phase === 'CONNECTING' && (netStatus === 'hosting' || netStatus === 'joining');

  return (
    <div className="relative z-10 flex min-h-dvh items-center justify-center overflow-x-hidden p-4 pt-[max(1rem,env(safe-area-inset-top))] pb-[max(1rem,env(safe-area-inset-bottom))]">
      <motion.div
        initial={{ opacity: 0, y: 28 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 160, damping: 22 }}
        className="w-full max-w-md space-y-4 md:max-w-4xl lg:max-w-5xl"
      >
        <div className="select-none text-center">
          <div className="font-display text-2xl font-black tracking-[0.35em] text-white md:text-3xl">
            LINK <span className="text-xenon-cyan">LOBBY</span>
          </div>
          <div className="mt-1 font-mono text-[10px] tracking-[0.25em] text-ghost">
            serverless p2p · signed envelopes · zero trust required
          </div>
        </div>

        {/* Desktop: wallet + loadout on the left, match actions on the right.
            Mobile: everything stacks in one column, unchanged. */}
        <div className="space-y-4 md:grid md:grid-cols-2 md:items-start md:gap-5 md:space-y-0">
          <div className="space-y-4">
            <WqdSyncCard />
            <InventoryStrip />
          </div>

          <div className="space-y-4">
            {/* No mode="wait" — see GameClient: rAF-frozen background tabs
                must not deadlock the waiting card swap. */}
            <AnimatePresence>
              {linking ? (
                <WaitingCard key="waiting" />
              ) : (
                <motion.div
                  key="actions"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  className="space-y-4"
                >
                  <QuickMatchCard />
                  {/* While queueing, private hosting stays visible but inert —
                      one transport, one pending handshake at a time. */}
                  <div className={queueStatus !== 'idle' ? 'pointer-events-none opacity-40' : ''}>
                    <PrivateMatchCard />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <AnimatePresence>
          {netError && !linking && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="glass border-red-500/40 bg-red-950/30 px-4 py-2.5 text-center font-mono text-[11px] text-red-300"
            >
              {netError}
            </motion.div>
          )}
        </AnimatePresence>

        <div className="text-center font-mono text-[9px] leading-relaxed text-ghost/50">
          WQD is a utility credit mined on the WebQuid platform. No wagering. No cash-out.
          <br />
          Only neon glory.
        </div>
      </motion.div>
    </div>
  );
}
