// ─────────────────────────────────────────────────────────────────────────────
// GameHUD — the glassmorphism overlay: wallet chip, WQD balance, opponent audit
// panel, turn timer, the power-up bar (buy + activate), targeting hints, cheat
// banner, and the victory / aborted overlays.
// ─────────────────────────────────────────────────────────────────────────────

'use client';

import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useGameStore } from '../../store/useGameStore';
import SoundToggle from '../SoundToggle';
import { quantumHackTarget } from '../../lib/game';
import {
  POWER_UP_COST,
  QUANTUM_LOCK_COST,
  TURN_SECONDS,
  canAfford,
  formatWqd,
  formatWqdBalance,
  shortAddress,
  type PowerUpKind,
} from '../../types';

/** 100ms wall-clock tick for timer UI (game logic uses the store's own tick). */
function useNow(intervalMs = 100): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(timer);
  }, [intervalMs]);
  return now;
}

const POWER_UP_META: Record<
  PowerUpKind,
  { name: string; blurb: string; targeted: boolean; icon: React.JSX.Element }
> = {
  QUANTUM_HACK: {
    name: 'Quantum Hack',
    blurb: "Override the opponent's last unshielded mark",
    targeted: false,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
        <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" strokeLinejoin="round" />
      </svg>
    ),
  },
  NEON_SHIELD: {
    name: 'Neon Shield',
    blurb: 'Protect one of your marks from hacks',
    targeted: true,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
        <path d="M12 3 5 6v5c0 4.5 3 7.7 7 9 4-1.3 7-4.5 7-9V6l-7-3Z" strokeLinejoin="round" />
        <path d="M12 8v5" strokeLinecap="round" />
      </svg>
    ),
  },
  TIME_DILATION: {
    name: 'Time Dilation',
    blurb: "Freeze 20s onto the opponent's clock",
    targeted: false,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-5 w-5">
        <circle cx="12" cy="13" r="7" />
        <path d="M12 9v4l3 2M9 3h6" strokeLinecap="round" />
      </svg>
    ),
  },
  QUANTUM_ENTANGLE: {
    name: 'Quantum Entangle',
    blurb: 'Drop a superposition — collapses when observed',
    targeted: true,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" className="h-5 w-5">
        <circle cx="12" cy="12" r="2.2" />
        <ellipse cx="12" cy="12" rx="9" ry="3.6" />
        <ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(60 12 12)" />
        <ellipse cx="12" cy="12" rx="9" ry="3.6" transform="rotate(120 12 12)" />
      </svg>
    ),
  },
};

const POWER_UPS: PowerUpKind[] = ['QUANTUM_HACK', 'NEON_SHIELD', 'TIME_DILATION', 'QUANTUM_ENTANGLE'];

function TurnTimer(): React.JSX.Element | null {
  const now = useNow();
  const phase = useGameStore((s) => s.phase);
  const turn = useGameStore((s) => s.turn);
  const deadlines = useGameStore((s) => s.deadlines);
  const dilationUntil = useGameStore((s) => s.dilationUntil);
  const self = useGameStore((s) => s.self);

  if (phase !== 'ACTIVE' || !self) return null;
  const remainingMs = Math.max(0, deadlines[turn] - now);
  const fraction = Math.min(1, remainingMs / (TURN_SECONDS * 1000));
  const mine = turn === self.mark;
  const frozen = dilationUntil[turn] > now;
  const urgent = remainingMs < 8_000;

  return (
    <div className="pointer-events-none absolute left-1/2 top-[calc(max(0.75rem,env(safe-area-inset-top))+5.9rem)] z-20 w-[min(420px,92vw)] -translate-x-1/2 sm:top-[max(1rem,env(safe-area-inset-top))] sm:w-[min(420px,60vw)]">
      <div className="glass px-4 py-2">
        <div className="mb-1.5 flex items-center justify-between font-display text-[11px] tracking-[0.22em]">
          <span className={mine ? 'text-xenon-cyan' : 'text-xenon-magenta'}>
            {mine ? 'YOUR MOVE' : 'OPPONENT THINKING'}
          </span>
          <span className={urgent ? 'text-xenon-amber animate-flicker' : 'text-ghost'}>
            {(remainingMs / 1000).toFixed(1)}s{frozen ? ' ❄' : ''}
          </span>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-white/5">
          <motion.div
            className="h-full rounded-full"
            style={{
              background: mine
                ? 'linear-gradient(90deg,#00f0ff,#7df9ff)'
                : 'linear-gradient(90deg,#ff2bd6,#ff5ee7)',
              boxShadow: mine ? '0 0 12px rgba(0,240,255,.8)' : '0 0 12px rgba(255,43,214,.8)',
            }}
            animate={{ width: `${fraction * 100}%` }}
            transition={{ duration: 0.12, ease: 'linear' }}
          />
        </div>
      </div>
    </div>
  );
}

function PowerUpCard({ kind }: { kind: PowerUpKind }): React.JSX.Element {
  const meta = POWER_UP_META[kind];
  const balance = useGameStore((s) => s.selfBalance);
  const inventory = useGameStore((s) => s.selfInventory[kind]);
  const selected = useGameStore((s) => s.selectedPowerUp === kind);
  const phase = useGameStore((s) => s.phase);
  const board = useGameStore((s) => s.board);
  const self = useGameStore((s) => s.self);
  const turn = useGameStore((s) => s.turn);
  const buyPowerUp = useGameStore((s) => s.buyPowerUp);
  const selectPowerUp = useGameStore((s) => s.selectPowerUp);
  const activateHack = useGameStore((s) => s.activateHack);
  const activateDilation = useGameStore((s) => s.activateDilation);

  const active = phase === 'ACTIVE' && !!self;
  const cost = POWER_UP_COST[kind];
  const myTurn = active && self?.mark === turn;

  let canActivate = false;
  if (active) {
    if (kind === 'QUANTUM_HACK') canActivate = inventory > 0 && quantumHackTarget(board, self!.mark) !== null;
    else if (kind === 'TIME_DILATION') canActivate = inventory > 0;
    else if (kind === 'NEON_SHIELD') canActivate = inventory > 0;
    else canActivate = myTurn && canAfford(balance, cost) && board.some((c) => c.kind === 'empty');
  }

  const onActivate = (): void => {
    if (!canActivate) return;
    if (kind === 'QUANTUM_HACK') void activateHack();
    else if (kind === 'TIME_DILATION') void activateDilation();
    else selectPowerUp(kind);
  };

  return (
    <motion.div
      layout
      className={`glass group relative w-[80px] px-1.5 pb-2 pt-2 transition-colors sm:w-[132px] sm:px-3 sm:pb-2.5 sm:pt-3 ${
        selected ? 'border-xenon-cyan/70 shadow-neon-c' : 'hover:border-white/25'
      }`}
      animate={selected ? { y: -6 } : { y: 0 }}
    >
      <div className="mb-1 flex items-center justify-between text-xenon-ice">
        {meta.icon}
        {kind !== 'QUANTUM_ENTANGLE' && (
          <span className="rounded bg-white/10 px-1.5 font-mono text-[10px] text-ghost">
            ×{inventory}
          </span>
        )}
      </div>
      <div className="font-display text-[10px] font-bold leading-tight tracking-wider text-white sm:text-[11px]">
        {meta.name}
      </div>
      {/* the blurb is a desktop luxury — on phones it would stretch the tray */}
      <div className="mt-0.5 hidden min-h-[26px] text-[10px] leading-tight text-ghost sm:block">
        {meta.blurb}
      </div>
      <div className="mt-1.5 flex flex-col gap-1 sm:flex-row sm:items-center">
        <button
          type="button"
          onClick={() => void buyPowerUp(kind)}
          disabled={!canAfford(balance, cost)}
          className="flex-1 whitespace-nowrap rounded-md border border-white/15 bg-white/5 px-1 py-1 font-mono text-[9px] text-ghost transition hover:border-xenon-cyan/50 hover:text-xenon-cyan disabled:cursor-not-allowed disabled:opacity-30 sm:text-[10px]"
          title="Burn WQD to stock one charge"
        >
          +{formatWqd(cost)} WQD
        </button>
        <button
          type="button"
          onClick={onActivate}
          disabled={!canActivate}
          className={`flex-1 rounded-md border px-1 py-1 font-display text-[9px] font-bold tracking-wider transition disabled:cursor-not-allowed disabled:opacity-30 sm:text-[10px] ${
            selected
              ? 'border-xenon-cyan bg-xenon-cyan/20 text-xenon-cyan'
              : 'border-xenon-magenta/40 bg-xenon-magenta/10 text-xenon-pink hover:bg-xenon-magenta/25'
          }`}
        >
          {meta.targeted ? (selected ? 'CANCEL' : 'AIM') : 'FIRE'}
        </button>
      </div>
    </motion.div>
  );
}

/** Fullscreen toggle state — tracks the browser's fullscreenchange event. */
function useFullscreen(): { active: boolean; toggle: () => void } {
  const [active, setActive] = useState(false);
  useEffect(() => {
    const sync = (): void => setActive(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', sync);
    return () => document.removeEventListener('fullscreenchange', sync);
  }, []);
  const toggle = (): void => {
    if (document.fullscreenElement) {
      void document.exitFullscreen?.().catch(() => {});
    } else {
      void document.documentElement.requestFullscreen?.().catch(() => {});
    }
  };
  return { active, toggle };
}

function TopBar(): React.JSX.Element {
  const address = useGameStore((s) => s.address);
  const balance = useGameStore((s) => s.selfBalance);
  const peer = useGameStore((s) => s.peer);
  const remoteBalance = useGameStore((s) => s.remoteBalance);
  const roomCode = useGameStore((s) => s.roomCode);
  const netStatus = useGameStore((s) => s.netStatus);
  const signerMode = useGameStore((s) => s.signer?.mode);
  const leaveMatch = useGameStore((s) => s.leaveMatch);
  const [copied, setCopied] = useState(false);
  const fullscreen = useFullscreen();

  const copyRoom = (): void => {
    if (!roomCode) return;
    void navigator.clipboard?.writeText(roomCode).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
    });
  };

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex flex-wrap items-start justify-between gap-1.5 p-3 pt-[max(0.75rem,env(safe-area-inset-top))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))] sm:gap-2 sm:p-4">
      {/* identity + balance */}
      <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
        <div className="glass flex items-center gap-2 px-2 py-1.5 sm:px-3 sm:py-2">
          <span className="h-2 w-2 rounded-full bg-xenon-cyan shadow-neon-c" />
          <span className="font-mono text-xs text-white/90">{shortAddress(address ?? '')}</span>
          <span className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] uppercase tracking-widest text-ghost">
            {signerMode === 'burner' ? 'WebQuid' : 'Wallet'}
          </span>
        </div>
        <motion.div
          key={balance}
          initial={{ scale: 1.18 }}
          animate={{ scale: 1 }}
          className="glass flex items-center gap-1.5 border-xenon-cyan/30 px-3 py-2"
        >
          <span className="max-w-[8rem] truncate font-display text-sm font-bold text-xenon-cyan" title={`${formatWqd(balance)} WQD (exact)`}>{formatWqdBalance(balance)}</span>
          <span className="text-[10px] tracking-[0.2em] text-ghost">WQD</span>
        </motion.div>
      </div>

      {/* opponent + room + leave */}
      <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
        {peer && (
          <div className="glass hidden items-center gap-2 px-3 py-2 sm:flex">
            <span className="h-2 w-2 rounded-full bg-xenon-magenta shadow-neon-m" />
            <span className="font-mono text-xs text-white/90">{shortAddress(peer.address)}</span>
            <span className="max-w-[7rem] truncate font-mono text-[10px] text-xenon-magenta" title={`${formatWqd(remoteBalance)} WQD (exact)`}>{formatWqdBalance(remoteBalance)} WQD</span>
          </div>
        )}
        {roomCode && roomCode !== 'QUICKMATCH' && (
          <button
            type="button"
            onClick={copyRoom}
            className="glass px-2 py-1.5 font-mono text-xs tracking-[0.3em] text-xenon-ice transition hover:border-xenon-cyan/50 sm:px-3 sm:py-2"
            title="Copy room code"
          >
            {copied ? 'COPIED' : roomCode}
          </button>
        )}
        {roomCode === 'QUICKMATCH' && (
          <div className="glass px-2 py-1.5 font-mono text-xs tracking-[0.3em] text-xenon-pink sm:px-3 sm:py-2">
            QUICK LINK
          </div>
        )}
        <div className="glass flex items-center gap-1.5 px-2 py-1.5 sm:px-2.5 sm:py-2">
          <span
            className={`h-1.5 w-1.5 rounded-full ${
              netStatus === 'connected' ? 'bg-emerald-400' : 'bg-xenon-amber animate-pulse'
            }`}
          />
          <span className="hidden text-[9px] uppercase tracking-widest text-ghost sm:inline">{netStatus}</span>
        </div>
        <SoundToggle />
        <button
          type="button"
          onClick={fullscreen.toggle}
          aria-label={fullscreen.active ? 'Exit fullscreen' : 'Enter fullscreen'}
          title={fullscreen.active ? 'Exit fullscreen' : 'Fullscreen'}
          className="glass px-2 py-1.5 text-ghost transition hover:border-xenon-cyan/60 hover:text-xenon-cyan sm:px-3 sm:py-2"
        >
          {fullscreen.active ? (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4">
              <path d="M8 3v5H3M16 3v5h5M8 21v-5H3m13 5v-5h5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4">
              <path d="M8 3H3v5m13-5h5v5M8 21H3v-5m13 5h5v-5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </button>
        <button
          type="button"
          onClick={() => void leaveMatch()}
          className="glass px-2 py-1.5 font-display text-[10px] font-bold tracking-widest text-ghost transition hover:border-xenon-magenta/60 hover:text-xenon-pink sm:px-3 sm:py-2"
        >
          EXIT
        </button>
      </div>
    </div>
  );
}

function TargetingHint(): React.JSX.Element | null {
  const selected = useGameStore((s) => s.selectedPowerUp);
  if (!selected) return null;
  const hint =
    selected === 'NEON_SHIELD'
      ? 'Select one of YOUR marks to shield it from hacks'
      : 'Select an EMPTY tile to drop the superposition (consumes your turn)';
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      className="pointer-events-none absolute bottom-32 left-1/2 z-20"
      style={{ x: '-50%' }} // FM-owned transform — a Tailwind -translate-x-1/2 would be overwritten
    >
      <div className="glass border-xenon-cyan/40 px-4 py-2 text-center font-display text-[11px] tracking-[0.18em] text-xenon-ice">
        {hint}
        <span className="ml-2 text-ghost">· click again to cancel</span>
      </div>
    </motion.div>
  );
}

function CheatBanner(): React.JSX.Element | null {
  const cheat = useGameStore((s) => s.cheat);
  if (!cheat.flagged) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: -12 }}
      animate={{ opacity: 1, y: 0 }}
      className="absolute left-1/2 top-20 z-30"
      style={{ x: '-50%' }} // FM-owned transform — a Tailwind -translate-x-1/2 would be overwritten
    >
      <div className="glass border-red-500/60 bg-red-950/40 px-5 py-3 text-center shadow-[0_0_30px_rgba(239,68,68,0.35)]">
        <div className="font-display text-xs font-bold tracking-[0.25em] text-red-400">
          {cheat.by === 'peer' ? '⚠ PROTOCOL VIOLATION DETECTED' : '⚠ PEER REPORTED A VIOLATION'}
        </div>
        <div className="mt-1 max-w-[420px] font-mono text-[11px] text-red-200/80">{cheat.reason}</div>
      </div>
    </motion.div>
  );
}

// ── End-of-match cinematics ────────────────────────────────────────────────
// The end screen is a two-act scene: first a full-screen outcome cinematic
// (paired with the synthesized win/defeat sting), THEN the menu card.

type EndKind = 'victory' | 'defeat' | 'draw' | 'abort';

/** How long each cinematic runs before the menu card takes the stage. */
const END_FX_MS: Record<EndKind, number> = {
  victory: 2200,
  defeat: 2400,
  draw: 1100,
  abort: 250,
};

/** Big cinematic word size — 9.5vw keeps 9-letter STALEMATE inside any phone. */
const CINEMATIC_WORD =
  'inline-block font-display text-[clamp(2rem,9.5vw,5.25rem)] font-black leading-none tracking-[0.06em]';

function VictoryCinematic(): React.JSX.Element {
  const letters = 'VICTORY'.split('');
  const sparks = React.useMemo(
    () =>
      Array.from({ length: 20 }, (_, i) => {
        const angle = (i / 20) * Math.PI * 2 + Math.random() * 0.4;
        const dist = 120 + Math.random() * 170;
        return {
          x: Math.cos(angle) * dist,
          y: Math.sin(angle) * dist,
          delay: Math.random() * 0.15,
          dur: 0.7 + Math.random() * 0.55,
          size: 3 + Math.random() * 4,
          color: i % 3 === 0 ? '#7df9ff' : i % 3 === 1 ? '#00f0ff' : '#ffffff',
        };
      }),
    [],
  );
  return (
    <motion.div
      key="vfx"
      className="absolute inset-0 flex items-center justify-center overflow-hidden"
      exit={{ opacity: 0, transition: { duration: 0.25 } }}
    >
      {/* energy flash */}
      <motion.div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 45%, rgba(0,240,255,0.5), rgba(0,240,255,0.12) 42%, transparent 70%)',
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 1, 0] }}
        transition={{ duration: 0.9, times: [0, 0.22, 1] }}
      />
      {/* shockwave rings */}
      {[0, 1, 2].map((i) => (
        <motion.div
          key={i}
          className="absolute rounded-full border-2 border-xenon-cyan"
          style={{
            width: '44vmin',
            height: '44vmin',
            boxShadow: '0 0 42px rgba(0,240,255,.45), inset 0 0 42px rgba(0,240,255,.2)',
          }}
          initial={{ scale: 0.05, opacity: 0.85 }}
          animate={{ scale: 2.5, opacity: 0 }}
          transition={{ duration: 1.2, delay: 0.08 + i * 0.2, ease: 'easeOut' }}
        />
      ))}
      {/* sparks */}
      {sparks.map((s, i) => (
        <motion.span
          key={i}
          className="absolute rounded-full"
          style={{ width: s.size, height: s.size, background: s.color, boxShadow: `0 0 9px ${s.color}` }}
          initial={{ x: 0, y: 0, opacity: 1 }}
          animate={{ x: s.x, y: s.y, opacity: 0 }}
          transition={{ duration: s.dur, delay: s.delay, ease: 'easeOut' }}
        />
      ))}
      {/* word + subline */}
      <div className="relative flex flex-col items-center gap-5 px-4">
        <div
          className="flex items-baseline justify-center text-xenon-cyan"
          style={{ textShadow: '0 0 34px rgba(0,240,255,.95), 0 0 90px rgba(0,240,255,.5)' }}
        >
          {letters.map((ch, i) => (
            <motion.span
              key={i}
              className={CINEMATIC_WORD}
              initial={{ scale: 0, y: 60, opacity: 0, rotateX: -90 }}
              animate={{ scale: 1, y: 0, opacity: 1, rotateX: 0 }}
              transition={{ type: 'spring', stiffness: 320, damping: 19, delay: 0.15 + i * 0.06 }}
            >
              {ch}
            </motion.span>
          ))}
        </div>
        <motion.div
          className="font-mono text-[10px] tracking-[0.55em] text-xenon-ice/85"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.85, duration: 0.4 }}
        >
          GRID SECURED
        </motion.div>
      </div>
    </motion.div>
  );
}

function DefeatCinematic(): React.JSX.Element {
  const letters = 'DEFEAT'.split('');
  return (
    <motion.div
      key="dfx"
      className="absolute inset-0 overflow-hidden"
      initial={{ x: 0 }}
      animate={{ x: [0, -16, 12, -8, 4, 0] }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      exit={{ opacity: 0, transition: { duration: 0.25 } }}
    >
      {/* vignette closing in */}
      <motion.div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 45%, transparent 18%, rgba(46,0,20,0.78) 62%, rgba(12,0,7,0.94) 100%)',
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      />
      {/* red pulse */}
      <motion.div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(circle at 50% 50%, rgba(255,43,99,0.3), transparent 60%)' }}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 1, 0.35, 0] }}
        transition={{ duration: 1.5, times: [0, 0.18, 0.5, 1] }}
      />
      {/* scan sweep — the signal collapsing downwards */}
      <motion.div
        className="absolute inset-x-0 h-28"
        style={{ background: 'linear-gradient(180deg, transparent, rgba(255,43,214,0.2), transparent)' }}
        initial={{ top: '-15%' }}
        animate={{ top: '115%' }}
        transition={{ duration: 1.05, ease: 'easeIn', delay: 0.1 }}
      />
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 px-4">
        {/* glitch flicker on the whole word */}
        <motion.div
          className="flex items-baseline justify-center text-xenon-magenta"
          style={{ textShadow: '0 0 32px rgba(255,43,214,.9), 0 0 85px rgba(255,43,214,.45)' }}
          animate={{ opacity: [1, 0.35, 1, 0.6, 1] }}
          transition={{ duration: 0.5, delay: 0.55, times: [0, 0.2, 0.45, 0.7, 1] }}
        >
          {letters.map((ch, i) => (
            <motion.span
              key={i}
              className={CINEMATIC_WORD}
              initial={{ y: -150, opacity: 0, rotate: i % 2 === 0 ? -9 : 9 }}
              animate={{ y: 0, opacity: 1, rotate: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 16, delay: 0.1 + i * 0.07 }}
            >
              {ch}
            </motion.span>
          ))}
        </motion.div>
        <motion.div
          className="font-mono text-[10px] tracking-[0.55em] text-xenon-pink/75"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.95, duration: 0.4 }}
        >
          SIGNAL LOST
        </motion.div>
      </div>
    </motion.div>
  );
}

function DrawCinematic(): React.JSX.Element {
  const letters = 'STALEMATE'.split('');
  return (
    <motion.div
      key="xfx"
      className="absolute inset-0 flex items-center justify-center overflow-hidden"
      exit={{ opacity: 0, transition: { duration: 0.25 } }}
    >
      {/* single soft pulse */}
      <motion.div
        className="absolute rounded-full border border-xenon-ice/70"
        style={{ width: '40vmin', height: '40vmin', boxShadow: '0 0 36px rgba(125,249,255,.3)' }}
        initial={{ scale: 0.1, opacity: 0.7 }}
        animate={{ scale: 2, opacity: 0 }}
        transition={{ duration: 0.9, ease: 'easeOut' }}
      />
      <div
        className="relative flex items-baseline justify-center px-4 text-xenon-ice"
        style={{ textShadow: '0 0 28px rgba(125,249,255,.8)' }}
      >
        {letters.map((ch, i) => (
          <motion.span
            key={i}
            className={CINEMATIC_WORD}
            initial={{ x: i % 2 === 0 ? -70 : 70, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 300, damping: 22, delay: 0.05 + i * 0.035 }}
          >
            {ch}
          </motion.span>
        ))}
      </div>
    </motion.div>
  );
}

function EndOverlay(): React.JSX.Element | null {
  const phase = useGameStore((s) => s.phase);
  const winner = useGameStore((s) => s.winner);
  const self = useGameStore((s) => s.self);
  const netError = useGameStore((s) => s.netError);
  const rematchRequested = useGameStore((s) => s.rematchRequested);
  const requestRematch = useGameStore((s) => s.requestRematch);
  const leaveMatch = useGameStore((s) => s.leaveMatch);

  const show = phase === 'FINISHED' || phase === 'ABORTED';
  const kind: EndKind =
    phase === 'ABORTED' || !winner
      ? 'abort'
      : winner.winner === 'DRAW'
        ? 'draw'
        : self && winner.winner === self.mark
          ? 'victory'
          : 'defeat';

  // Act one (cinematic) runs for END_FX_MS[kind], then act two (menu) enters.
  const [stage, setStage] = useState<'fx' | 'menu'>('fx');
  useEffect(() => {
    if (!show) {
      setStage('fx'); // re-arm for the next match
      return;
    }
    const timer = window.setTimeout(() => setStage('menu'), END_FX_MS[kind]);
    return () => window.clearTimeout(timer);
  }, [show, kind]);

  let headline = '';
  let tone = '';
  if (phase === 'FINISHED' && winner) {
    if (winner.winner === 'DRAW') {
      headline = 'STALEMATE';
      tone = 'text-xenon-ice';
    } else if (self && winner.winner === self.mark) {
      headline = 'VICTORY';
      tone = 'text-xenon-cyan';
    } else {
      headline = 'DEFEAT';
      tone = 'text-xenon-magenta';
    }
  } else if (phase === 'ABORTED') {
    headline = 'LINK SEVERED';
    tone = 'text-red-400';
  }

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="pointer-events-auto absolute inset-0 z-30 overflow-hidden bg-void/70 backdrop-blur-md"
        >
          <AnimatePresence mode="wait">
            {stage === 'fx' ? (
              kind === 'victory' ? (
                <VictoryCinematic key="vfx" />
              ) : kind === 'defeat' ? (
                <DefeatCinematic key="dfx" />
              ) : kind === 'draw' ? (
                <DrawCinematic key="xfx" />
              ) : (
                <motion.div key="afx" className="absolute inset-0" exit={{ opacity: 0 }} />
              )
            ) : (
              <motion.div
                key="menu"
                className="absolute inset-0 flex items-center justify-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <motion.div
                  initial={{ scale: 0.85, y: 24 }}
                  animate={{ scale: 1, y: 0 }}
                  transition={{ type: 'spring', stiffness: 220, damping: 20 }}
                  className="glass mx-4 max-w-[94vw] px-6 py-8 text-center sm:px-10"
                >
                  {/* clamp + tight tracking: STALEMATE can never overflow a phone */}
                  <div
                    className={`whitespace-nowrap font-display text-[clamp(1.5rem,7vw,2.6rem)] font-black tracking-[0.12em] sm:tracking-[0.3em] ${tone}`}
                    style={{ textShadow: '0 0 24px currentColor' }}
                  >
                    {headline}
                  </div>
                  {phase === 'ABORTED' && (
                    <div className="mt-2 font-mono text-xs text-ghost">{netError ?? 'connection interrupted'}</div>
                  )}
                  <div className="mt-6 flex items-center justify-center gap-3">
                    {phase === 'FINISHED' && (
                      <button
                        type="button"
                        onClick={() => void requestRematch()}
                        disabled={rematchRequested}
                        className="rounded-lg border border-xenon-cyan/50 bg-xenon-cyan/15 px-6 py-2.5 font-display text-xs font-bold tracking-[0.2em] text-xenon-cyan transition hover:bg-xenon-cyan/30 disabled:opacity-40"
                      >
                        {rematchRequested ? 'AWAITING PEER…' : 'REMATCH'}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => void leaveMatch()}
                      className="rounded-lg border border-white/15 bg-white/5 px-6 py-2.5 font-display text-xs font-bold tracking-[0.2em] text-ghost transition hover:border-xenon-magenta/50 hover:text-xenon-pink"
                    >
                      LOBBY
                    </button>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/** Frost vignette while YOUR clock is frozen by the opponent's Time Dilation. */
/** Full-screen breach flash for QUANTUM_HACK. The store emits the impulse on
 *  BOTH sides (local activation and remote application), so attacker and
 *  victim always see the same hijack flash. The board's own particle burst
 *  and shake (FxRig) mark the targeted tile underneath this overlay. */
function HackGlitch(): React.JSX.Element | null {
  const [active, setActive] = useState(0); // fx nonce currently on screen
  const lastNonce = useRef(0);
  useEffect(() => {
    let hideTimer = 0;
    const unsubscribe = useGameStore.subscribe((state) => {
      const fx = state.fx;
      if (fx.nonce === lastNonce.current) return;
      lastNonce.current = fx.nonce;
      if (fx.kind !== 'hack') return;
      setActive(fx.nonce);
      window.clearTimeout(hideTimer);
      hideTimer = window.setTimeout(() => setActive(0), 1150);
    });
    return () => {
      window.clearTimeout(hideTimer);
      unsubscribe();
    };
  }, []);

  return (
    <AnimatePresence>
      {active !== 0 && (
        <motion.div
          key={active}
          className="pointer-events-none absolute inset-0 z-30 overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.22 } }}
        >
          {/* breach veil — a quick magenta/cyan wash, not a blackout */}
          <motion.div
            className="absolute inset-0"
            style={{
              background:
                'radial-gradient(ellipse at center, rgba(255,43,214,0.16) 0%, rgba(5,2,16,0.55) 100%)',
            }}
            animate={{ opacity: [0, 1, 0.7, 1] }}
            transition={{ duration: 0.9, times: [0, 0.15, 0.6, 1] }}
          />

          {/* horizontal glitch slices tearing the frame */}
          {[12, 30, 47, 63, 81].map((top, i) => (
            <motion.div
              key={top}
              className={`absolute left-0 h-[3px] w-full ${
                i % 2 === 0 ? 'bg-xenon-magenta/50' : 'bg-xenon-cyan/40'
              }`}
              style={{ top: `${top}%` }}
              animate={{ x: [0, i % 2 === 0 ? 26 : -26, i % 2 === 0 ? -14 : 14, 0], opacity: [0, 1, 1, 0] }}
              transition={{ duration: 0.55, delay: 0.08 + i * 0.07, ease: 'easeOut' }}
            />
          ))}

          {/* corrupted data tokens flickering across the veil */}
          {HACK_TOKENS.map((token, i) => (
            <motion.span
              key={token.text}
              className="absolute font-mono text-[10px] tracking-[0.2em] text-xenon-cyan/70"
              style={{ left: token.left, top: token.top }}
              animate={{ opacity: [0, 1, 0, 1, 0] }}
              transition={{ duration: 0.6, delay: 0.05 + i * 0.06 }}
            >
              {token.text}
            </motion.span>
          ))}

          {/* scanline sweep */}
          <motion.div
            className="absolute inset-x-0 h-20"
            style={{
              background:
                'linear-gradient(to bottom, transparent, rgba(0,240,255,0.14), rgba(255,43,214,0.12), transparent)',
            }}
            initial={{ top: '-12%' }}
            animate={{ top: '108%' }}
            transition={{ duration: 0.85, ease: 'easeInOut' }}
          />

          {/* RGB-split headline with an electrical jitter */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <motion.div
              className="font-display text-[clamp(1.7rem,7.5vw,3.6rem)] font-black tracking-[0.14em] text-white"
              style={{
                textShadow: '3px 0 0 rgba(255,43,214,0.85), -3px 0 0 rgba(0,240,255,0.85)',
              }}
              animate={{ x: [0, -5, 4, -2, 0], opacity: [0, 1, 0.65, 1, 1] }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
            >
              QUANTUM HACK
            </motion.div>
            <motion.div
              className="mt-2 font-mono text-[10px] uppercase tracking-[0.45em] text-xenon-magenta"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 0.4, 1] }}
              transition={{ duration: 0.7, delay: 0.18 }}
            >
              signal hijacked
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/** Deterministic corruption tokens — precomputed so re-renders never reshuffle. */
const HACK_TOKENS = [
  { text: '0xF3A9::BREACH', left: '12%', top: '22%' },
  { text: 'SIG_OVERRIDE', left: '68%', top: '18%' },
  { text: '10110100 11100010', left: '8%', top: '58%' },
  { text: 'PAYLOAD_INJECT', left: '64%', top: '70%' },
  { text: '0x9E::ROOT', left: '20%', top: '80%' },
  { text: 'KEYSTREAM_LOST', left: '58%', top: '38%' },
  { text: '01101111 01011000', left: '30%', top: '10%' },
  { text: 'TLS_FATAL::0x42', left: '70%', top: '86%' },
];

function DilationFrost(): React.JSX.Element | null {
  const now = useNow(200);
  const self = useGameStore((s) => s.self);
  const dilationUntil = useGameStore((s) => s.dilationUntil);
  if (!self || dilationUntil[self.mark] <= now) return null;
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pointer-events-none absolute inset-0 z-10"
      style={{
        boxShadow: 'inset 0 0 120px rgba(125,249,255,0.28)',
        background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,240,255,0.10) 100%)',
      }}
    >
      <div className="absolute bottom-40 left-1/2 -translate-x-1/2 rounded-full border border-xenon-ice/40 bg-void/60 px-4 py-1 font-display text-[10px] tracking-[0.3em] text-xenon-ice">
        TIME DILATION FIELD ACTIVE
      </div>
    </motion.div>
  );
}

export default function GameHUD(): React.JSX.Element {
  const phase = useGameStore((s) => s.phase);
  const inventory = useGameStore((s) => s.selfInventory);
  // Armory lives in the store so the chat tab can lift itself clear of it.
  // Mobile: starts COLLAPSED so it never covers the board's bottom row;
  // desktop keeps the full bar.
  const armoryOpen = useGameStore((s) => s.armoryOpen);
  const setArmoryOpen = useGameStore((s) => s.setArmoryOpen);
  useEffect(() => {
    setArmoryOpen(window.innerWidth >= 640);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const totalCharges = POWER_UPS.reduce((sum, kind) => sum + inventory[kind], 0);

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none">
      <TopBar />
      <TurnTimer />
      <CheatBanner />
      <DilationFrost />
      <HackGlitch />
      <AnimatePresence>
        {phase === 'ACTIVE' && !armoryOpen && (
          <motion.button
            key="armory-tab"
            type="button"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 24 }}
            onClick={() => setArmoryOpen(true)}
            className="glass pointer-events-auto absolute bottom-[max(1rem,env(safe-area-inset-bottom))] right-[max(1rem,env(safe-area-inset-right))] z-20 flex items-center gap-2 px-5 py-2.5 font-display text-[11px] font-bold tracking-[0.2em] text-xenon-cyan transition hover:border-xenon-cyan/60"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-4 w-4">
              <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" strokeLinejoin="round" />
            </svg>
            ARMORY
            {totalCharges > 0 && (
              <span className="rounded-full bg-xenon-magenta px-1.5 font-mono text-[10px] font-bold text-white shadow-neon-m">
                {totalCharges}
              </span>
            )}
          </motion.button>
        )}
        {phase === 'ACTIVE' && armoryOpen && (
          // Centering MUST come from flex, not a Tailwind translate: framer-motion
          // writes an inline transform that silently cancels -translate-x-1/2,
          // which is exactly how the tray used to spill past the right edge.
          <motion.div
            key="armory-bar"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 24 }}
            className="pointer-events-none absolute inset-x-0 bottom-[max(0.5rem,env(safe-area-inset-bottom))] z-20 flex justify-center px-1"
          >
            <div className="pointer-events-auto flex max-w-full items-end gap-1 overflow-x-auto pb-1 sm:gap-2 sm:px-1">
              {POWER_UPS.map((kind) => (
                <div key={kind} className="shrink-0">
                  <PowerUpCard kind={kind} />
                </div>
              ))}
              <div className="glass hidden px-3 py-2 text-center md:block">
                <div className="font-mono text-[9px] uppercase tracking-widest text-ghost">Decohere</div>
                <div className="font-display text-[10px] font-bold text-xenon-ice">
                  {formatWqd(QUANTUM_LOCK_COST)} WQD
                </div>
                <div className="mt-0.5 max-w-[90px] text-[9px] leading-tight text-ghost">
                  click your own superposition to lock it
                </div>
              </div>
              {/* mobile-only collapse handle: give the board back after firing */}
              <button
                type="button"
                onClick={() => setArmoryOpen(false)}
                aria-label="Collapse armory"
                className="glass shrink-0 self-center px-2.5 py-2 text-ghost transition hover:text-xenon-cyan sm:hidden"
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4">
                  <path d="m6 9 6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <TargetingHint />
      <EndOverlay />
    </div>
  );
}
