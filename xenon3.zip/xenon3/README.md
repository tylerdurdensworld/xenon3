# XENON3 — WebQuid Utility Arena

Holographic neon 3D tic-tac-toe played over trustless, serverless WebRTC
(P2P — there is no game server). **WQD** utility credits earned in the
WebQuid browser-mining ecosystem are burned on quantum power-ups.

> WQD is strictly an in-game utility credit. No gambling, no real-money
> cash-out, no betting.

---

## What's in xenon3.zip

```
xenon3/
├── site/          ready-to-serve static build — no compilation needed
├── src/           full TypeScript source (Next.js 14 static export)
├── public/        PWA assets, service worker, webquid.config.json
├── .github/       GitHub Pages deployment workflow
├── package.json   …and the rest of the buildable project
└── GITHUB-SETUP.md
```

## Quick start (local)

No build tools required — serve the ready-made folder:

```bash
unzip xenon3.zip
cd xenon3/site
python -m http.server 8080
```

Open **http://127.0.0.1:8080** in your browser.
(127.0.0.1 is required — wallet signing needs a secure context, and LAN
addresses like `192.168.x.x` do not count as one.)

On Android, the same three lines work inside Termux.

## Publish on GitHub (browser only, no PC)

See **[GITHUB-SETUP.md](GITHUB-SETUP.md)** — upload `xenon3.zip` to a fresh
repository, add the included workflow file, flip Pages to "GitHub Actions",
and the game goes live at `https://<your-username>.github.io/<repo-name>/`.
Any repository name works; asset paths are relative.

## Wallet

Xenon3 never mints wallets. To play you need an existing WebQuid wallet:

1. Open the WebQuid terminal (see the config file below for its address).
2. In the terminal, **WALLET → Export / Backup** → copy the 64-character
   hex key.
3. Paste it into the box on the Xenon3 home screen → **IMPORT & CONNECT**
   (the `0x` prefix is optional).

The key stays in your browser's local storage and is never transmitted
anywhere; all signing happens locally.

### Two tabs on one machine

Two tabs share one local storage, so they share one wallet — and one wallet
cannot duel itself. Press **"SPARRING KEY — THIS TAB ONLY"** on the connect
screen in *one* tab to mint a temporary, zero-balance key that lives only in
that tab, then keep your real wallet in the other. The sparring key vanishes
when the tab closes.

## Configuration: changing the terminal address

The terminal address is read from `webquid.config.json` — no rebuild needed:

```json
{
  "terminalUrl": "https://tylerdurdensworld.github.io/Webquid/"
}
```

Edit it in the shipped build (`site/webquid.config.json`) or in the source
(`public/webquid.config.json`) and reload the page. If the file is missing
or malformed, the default address above is used.

## Building from source

```bash
npm install
npm run build      # static site is emitted to out/
npx serve out      # or: cd out && python -m http.server 8080
```

`npm run typecheck` runs the TypeScript checker with no emit.
