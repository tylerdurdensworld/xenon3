import type { Config } from 'tailwindcss';

/**
 * Xenon3 cyberpunk design tokens.
 * Palette is anchored on xenon-gas discharge hues: electric cyan for player X,
 * hot magenta for player O, deep void blues for the glassmorphism shells.
 */
const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        void: '#05060f',
        abyss: '#080b18',
        panel: '#0a0e1e',
        edge: '#11162e',
        xenon: {
          cyan: '#00f0ff',
          ice: '#7df9ff',
          magenta: '#ff2bd6',
          pink: '#ff5ee7',
          violet: '#7b2bff',
          amber: '#ffc857',
        },
        ghost: '#8b93b8',
      },
      fontFamily: {
        display: ['Orbitron', 'Rajdhani', 'system-ui', 'sans-serif'],
        body: ['Rajdhani', 'Segoe UI', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
      boxShadow: {
        'neon-c': '0 0 6px rgba(0,240,255,0.65), 0 0 24px rgba(0,240,255,0.28)',
        'neon-m': '0 0 6px rgba(255,43,214,0.65), 0 0 24px rgba(255,43,214,0.28)',
        'glass-inset': 'inset 0 1px 0 rgba(255,255,255,0.08), inset 0 -1px 0 rgba(0,0,0,0.4)',
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '1', filter: 'brightness(1)' },
          '50%': { opacity: '0.72', filter: 'brightness(1.35)' },
        },
        scanline: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
        flicker: {
          '0%, 19%, 21%, 62%, 64%, 100%': { opacity: '1' },
          '20%, 63%': { opacity: '0.35' },
        },
        floaty: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-6px)' },
        },
      },
      animation: {
        'pulse-glow': 'pulseGlow 2.4s ease-in-out infinite',
        scanline: 'scanline 7s linear infinite',
        flicker: 'flicker 4s linear infinite',
        floaty: 'floaty 5s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
